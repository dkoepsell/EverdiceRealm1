
// server/lib/buildPrompt.ts

import { DMContext } from "./openai";
import { storage } from '../storage';

interface Session {
  id: number;
  title: string;
  narrative: string;
  location: string;
  themes?: string;
  unresolvedHooks?: string[];
  npcs?: string[];
  playerActions?: string[];
  createdAt: string;
}

// Utility Functions
export function parseModifier(modifier: string): number {
  const match = modifier.trim().match(/([-+]?\d+)/);
  return match ? parseInt(match[1], 10) : 0;
}

export function checkForStalling(narrative: string): boolean {
  const lines = narrative.split(/\n|\.\s/).map(l => l.trim()).filter(Boolean);
  const unique = new Set(lines);
  const repetitionRatio = (lines.length - unique.size) / lines.length;
  return repetitionRatio > 0.4 || narrative.toLowerCase().includes("you find yourself where you started");
}

// Simplified and fixed buildPrompt with safe sessionHistory access
export function buildEnhancedPrompt({ sessionHistory }) {
  const recentSessions = (sessionHistory || []).slice(-5);
  let prompt = "You are a DM. Summarize recent sessions:\n";
  for (const session of recentSessions) {
    prompt += `Session ${session.session_number}: ${session.narrative}\n`;
  }
  return prompt;
}

// Legacy function for backward compatibility
export async function buildPrompt(context: DMContext): Promise<string> {
  return buildEnhancedPrompt(context);
}
