
import { storage } from '../storage';

interface StoryArc {
  id: string;
  title: string;
  phases: StoryPhase[];
  currentPhase: number;
  isComplete: boolean;
  rewards: StoryRewards;
}

interface StoryPhase {
  id: number;
  title: string;
  description: string;
  objectives: string[];
  completionCriteria: string[];
  isComplete: boolean;
  sessionCount: number;
  maxSessions: number;
}

interface StoryRewards {
  xp: number;
  gold: number;
  items: Array<{
    name: string;
    description: string;
    rarity: 'common' | 'uncommon' | 'rare' | 'epic' | 'legendary';
    type: string;
  }>;
  achievements: string[];
}

export class StoryArcManager {
  
  static getDefaultStoryArc(): StoryArc {
    return {
      id: 'enchanted-grove-corruption',
      title: 'The Corruption of the Enchanted Grove',
      currentPhase: 0,
      isComplete: false,
      phases: [
        {
          id: 0,
          title: 'Discovery',
          description: 'Explore the grove and uncover the source of corruption',
          objectives: ['Enter the Enchanted Grove', 'Meet Elowen', 'Discover corruption signs'],
          completionCriteria: ['corruption_discovered', 'npc_met', 'location_explored'],
          isComplete: false,
          sessionCount: 0,
          maxSessions: 5
        },
        {
          id: 1,
          title: 'Investigation',
          description: 'Investigate the corruption and gather allies',
          objectives: ['Examine corrupted areas', 'Gain creature trust', 'Uncover ritual sites'],
          completionCriteria: ['investigation_complete', 'ally_gained', 'ritual_site_found'],
          isComplete: false,
          sessionCount: 0,
          maxSessions: 7
        },
        {
          id: 2,
          title: 'Confrontation',
          description: 'Face the source of corruption in climactic encounters',
          objectives: ['Confront corrupted guardian', 'Cleanse corruption', 'Restore balance'],
          completionCriteria: ['guardian_defeated', 'corruption_cleansed', 'balance_restored'],
          isComplete: false,
          sessionCount: 0,
          maxSessions: 5
        }
      ],
      rewards: {
        xp: 2000,
        gold: 500,
        items: [
          {
            name: 'Grove Guardian\'s Blessing',
            description: 'A magical amulet that grants protection from corruption',
            rarity: 'rare',
            type: 'amulet'
          },
          {
            name: 'Seed of the World Tree',
            description: 'A seed that can grow into a powerful nature ally',
            rarity: 'epic',
            type: 'consumable'
          }
        ],
        achievements: ['Grove Protector', 'Corruption Cleanser', 'Nature\'s Champion']
      }
    };
  }

  static async getCampaignStoryArc(campaignId: number): Promise<StoryArc> {
    try {
      // Try to get existing story arc from campaign metadata
      const campaign = await storage.getCampaign(campaignId);
      if (campaign?.metadata?.storyArc) {
        return JSON.parse(campaign.metadata.storyArc);
      }
      
      // Create default story arc for new campaigns
      const defaultArc = this.getDefaultStoryArc();
      await this.saveStoryArc(campaignId, defaultArc);
      return defaultArc;
    } catch (error) {
      console.error('Error getting story arc:', error);
      return this.getDefaultStoryArc();
    }
  }

  static async saveStoryArc(campaignId: number, storyArc: StoryArc): Promise<void> {
    try {
      await storage.updateCampaignMetadata(campaignId, {
        storyArc: JSON.stringify(storyArc)
      });
    } catch (error) {
      console.error('Error saving story arc:', error);
    }
  }

  static async updatePhaseProgress(campaignId: number, context: string, action: string, skillCheckResult?: any): Promise<{ phaseComplete: boolean; arcComplete: boolean; rewards?: StoryRewards; shouldApproachEnding: boolean }> {
    const storyArc = await this.getCampaignStoryArc(campaignId);
    const currentPhase = storyArc.phases[storyArc.currentPhase];
    
    if (!currentPhase || currentPhase.isComplete) {
      return { phaseComplete: false, arcComplete: storyArc.isComplete, shouldApproachEnding: storyArc.isComplete };
    }

    // Increment session count for current phase
    currentPhase.sessionCount++;
    
    // Calculate total campaign sessions
    const totalSessions = storyArc.phases.reduce((sum, phase) => sum + phase.sessionCount, 0);

    // Check completion criteria based on context and actions
    const completedCriteria = this.checkCompletionCriteria(currentPhase, context, action, skillCheckResult);
    
    // Force completion if max sessions reached or total campaign is getting long
    const forceComplete = currentPhase.sessionCount >= currentPhase.maxSessions || totalSessions > 15;
    const phaseComplete = completedCriteria.length >= currentPhase.completionCriteria.length || forceComplete;

    // Determine if we should approach ending
    const shouldApproachEnding = storyArc.currentPhase >= storyArc.phases.length - 1 || totalSessions > 12;

    if (phaseComplete) {
      currentPhase.isComplete = true;
      
      // Advance to next phase or complete arc
      if (storyArc.currentPhase < storyArc.phases.length - 1) {
        storyArc.currentPhase++;
        
        // If entering final phase, ensure it's designed for quick resolution
        if (storyArc.currentPhase === storyArc.phases.length - 1) {
          storyArc.phases[storyArc.currentPhase].maxSessions = Math.min(3, storyArc.phases[storyArc.currentPhase].maxSessions);
        }
      } else {
        storyArc.isComplete = true;
      }
    }

    await this.saveStoryArc(campaignId, storyArc);

    return {
      phaseComplete,
      arcComplete: storyArc.isComplete,
      rewards: storyArc.isComplete ? storyArc.rewards : undefined,
      shouldApproachEnding
    };
  }

  private static checkCompletionCriteria(phase: StoryPhase, context: string, action: string, skillCheckResult?: any): string[] {
    const completed: string[] = [];
    const contextLower = context.toLowerCase();
    const actionLower = action.toLowerCase();

    phase.completionCriteria.forEach(criteria => {
      switch (criteria) {
        case 'corruption_discovered':
          if (contextLower.includes('corrupt') || contextLower.includes('taint') || contextLower.includes('dark')) {
            completed.push(criteria);
          }
          break;
        case 'npc_met':
          if (contextLower.includes('elowen') || contextLower.includes('druid') || actionLower.includes('talk') || actionLower.includes('speak')) {
            completed.push(criteria);
          }
          break;
        case 'location_explored':
          if (actionLower.includes('explore') || actionLower.includes('investigate') || actionLower.includes('examine')) {
            completed.push(criteria);
          }
          break;
        case 'investigation_complete':
          if (skillCheckResult?.success && (skillCheckResult.abilityType === 'investigation' || skillCheckResult.abilityType === 'arcana')) {
            completed.push(criteria);
          }
          break;
        case 'ally_gained':
          if (skillCheckResult?.success && skillCheckResult.abilityType === 'animal_handling') {
            completed.push(criteria);
          }
          break;
        case 'ritual_site_found':
          if (contextLower.includes('altar') || contextLower.includes('ritual') || contextLower.includes('sacred')) {
            completed.push(criteria);
          }
          break;
        case 'guardian_defeated':
          if (actionLower.includes('combat') || actionLower.includes('defeat') || actionLower.includes('victory')) {
            completed.push(criteria);
          }
          break;
        case 'corruption_cleansed':
          if (actionLower.includes('cleanse') || actionLower.includes('purify') || actionLower.includes('restore')) {
            completed.push(criteria);
          }
          break;
        case 'balance_restored':
          if (contextLower.includes('restored') || contextLower.includes('balance') || contextLower.includes('harmony')) {
            completed.push(criteria);
          }
          break;
      }
    });

    return completed;
  }

  static async generateClosureNarrative(campaignId: number): Promise<string> {
    const storyArc = await this.getCampaignStoryArc(campaignId);
    
    if (!storyArc.isComplete) {
      return '';
    }

    return `
## Quest Complete: ${storyArc.title}

The corruption that once threatened the Enchanted Grove has been vanquished through your heroic efforts. The ancient trees whisper songs of gratitude as natural harmony is restored to this sacred place.

**Your Achievements:**
${storyArc.rewards.achievements.map(achievement => `- ${achievement}`).join('\n')}

**Rewards Earned:**
- Experience Points: ${storyArc.rewards.xp} XP
- Gold: ${storyArc.rewards.gold} gold pieces
- Magic Items: ${storyArc.rewards.items.map(item => `${item.name} (${item.rarity})`).join(', ')}

The grove's guardian spirits smile upon you, and your deeds will be remembered in the annals of legend. Though this chapter of your adventure has concluded, greater challenges and mysteries await beyond the horizon.
    `;
  }

  // Check all active campaigns for story arc completion
  static async checkAllCampaignsForClosure(): Promise<void> {
    try {
      const activeCampaigns = await storage.getActiveCampaigns();
      
      for (const campaign of activeCampaigns) {
        const storyArc = await this.getCampaignStoryArc(campaign.id);
        const currentPhase = storyArc.phases[storyArc.currentPhase];
        
        // Force closure if campaign has been running too long
        if (currentPhase && currentPhase.sessionCount >= currentPhase.maxSessions) {
          await this.forcePhaseCompletion(campaign.id);
        }
      }
    } catch (error) {
      console.error('Error checking campaigns for closure:', error);
    }
  }

  private static async forcePhaseCompletion(campaignId: number): Promise<void> {
    const storyArc = await this.getCampaignStoryArc(campaignId);
    const currentPhase = storyArc.phases[storyArc.currentPhase];
    
    if (currentPhase && !currentPhase.isComplete) {
      currentPhase.isComplete = true;
      
      if (storyArc.currentPhase < storyArc.phases.length - 1) {
        storyArc.currentPhase++;
      } else {
        storyArc.isComplete = true;
        
        // Apply completion rewards
        try {
          await storage.applyCampaignRewards(campaignId, storyArc.rewards);
        } catch (error) {
          console.error('Error applying rewards:', error);
        }
      }
      
      await this.saveStoryArc(campaignId, storyArc);
    }
  }
}
