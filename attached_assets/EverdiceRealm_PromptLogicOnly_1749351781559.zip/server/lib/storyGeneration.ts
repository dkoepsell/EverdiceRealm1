import { OpenAIApi } from 'openai';
import { openai } from './openai';
import { getCampaignMemory, getRecentSessionLogs, updateCampaignMemory } from './sessionMemory';
import { summarizeScene, extractUnresolvedThreads, determineNarrativePhase } from './nlpUtils';
import { pushSessionLog } from './sessionLogger';
import { StoryArcManager } from './storyArcManager';

interface GameState {
  players: Array<{
    name: string;
    class: string;
    abilities: Record<string, number>;
    skills: Record<string, number>;
    inventory: string[];
    hp: number;
    maxHp: number;
  }>;
  location: {
    name: string;
    description: string;
    flags: string[];
    connections: Array<{
      name: string;
      direction: string;
      requirements?: string[];
    }>;
  };
  encounter?: {
    type: string;
    mood: string;
    canBePacified: boolean;
    state: string;
  };
  narrativeFlags: string[];
  storyProgress: {
    mainObjective: string;
    completedMilestones: string[];
    currentPhase: 'discovery' | 'investigation' | 'confrontation' | 'resolution';
    estimatedSessionsRemaining: number;
  };
}

interface StoryRequest {
  campaignId: number;
  sessionId?: number;
  action?: string;
  currentLocation?: string;
  narrativeStyle?: string;
  difficulty?: string;
  context?: string;
  gameState?: GameState;
  skillCheckResult?: {
    abilityType: string;
    roll: number;
    success: boolean;
    dc: number;
    actionContext: string;
    modifiers?: Record<string, number>;
  };
  previousChoices?: Array<{
    action: string;
    outcome: string;
    timestamp: string;
    consequences?: string[];
  }>;
}

interface Choice {
  action: string;
  description: string;
  requiresDiceRoll?: boolean;
  diceType?: string;
  rollDC?: number;
  abilityType?: string;
  rollModifier?: number;
  storyImpact?: 'minor' | 'moderate' | 'major';
  progressionType?: 'advance' | 'explore' | 'resolve';
}

// Enhanced story progression tracking
let campaignProgressions = new Map<number, {
  totalSessions: number;
  currentAct: number;
  maxActs: number;
  lastLocationChain: string[];
  unresolvedPlotThreads: string[];
  characterArcs: Map<string, string>;
  narrativeMomentum: number;
  endingApproaching: boolean;
}>();

// Geographic and narrative connectivity functions
function buildLocationGraph(context: string, sessionHistory: any[]): Map<string, string[]> {
  const locationGraph = new Map<string, string[]>();

  // Extract locations from session history
  const locations = sessionHistory.map(s => s.location).filter(Boolean);

  // Build connections based on narrative context
  if (context?.includes('grove')) {
    locationGraph.set('Enchanted Grove', ['Ancient Clearing', 'Moonlit Path', 'Corrupted Depths']);
    locationGraph.set('Ancient Clearing', ['Enchanted Grove', 'Temple Entrance', 'Sacred Pool']);
    locationGraph.set('Temple Entrance', ['Ancient Clearing', 'Temple Interior', 'Underground Passages']);
  }

  return locationGraph;
}

function determineNextLogicalLocation(currentLocation: string, action: string, sessionCount: number, locationGraph: Map<string, string[]>): string {
  const connections = locationGraph.get(currentLocation) || [];

  // Force progression after too many sessions in same location
  if (sessionCount > 8) {
    const progressionLocations = ['Temple of the Ancient Guardians', 'The Corruption\'s Source', 'Final Sanctum'];
    return progressionLocations[Math.min(Math.floor(sessionCount / 10), progressionLocations.length - 1)];
  }

  // Choose location based on action type
  if (action?.toLowerCase().includes('investigate') || action?.toLowerCase().includes('examine')) {
    return connections.find(loc => loc.includes('Temple') || loc.includes('Sacred')) || currentLocation;
  }

  if (action?.toLowerCase().includes('confront') || action?.toLowerCase().includes('combat')) {
    return connections.find(loc => loc.includes('Depths') || loc.includes('Source')) || currentLocation;
  }

  return connections[0] || currentLocation;
}

function calculateNarrativeProgress(campaignId: number, sessionHistory: any[], skillCheckResult?: any): {
  currentProgress: number;
  estimatedSessionsRemaining: number;
  shouldApproachEnding: boolean;
} {
  const totalSessions = sessionHistory.length;
  const successfulActions = sessionHistory.filter(s => 
    s.skillChecks?.some((sc: any) => sc.success) || s.combatOutcome === 'victory'
  ).length;

  // Calculate progress as percentage
  const progressPercentage = Math.min((successfulActions / 15) * 100, 90); // Cap at 90% until final resolution

  // Determine if we should approach ending
  const shouldApproachEnding = totalSessions > 12 || progressPercentage > 70;

  // Estimate remaining sessions
  const remainingSessions = shouldApproachEnding ? Math.max(2, 5 - Math.floor(progressPercentage / 20)) : 8;

  return {
    currentProgress: progressPercentage,
    estimatedSessionsRemaining: remainingSessions,
    shouldApproachEnding
  };
}

function generateSceneTransition(previousLocation: string, newLocation: string, action: string, skillCheckResult?: any): string {
  if (previousLocation === newLocation) {
    return skillCheckResult?.success 
      ? "Your success reveals new aspects of your current surroundings..."
      : "Despite the setback, you notice details previously hidden...";
  }

  const transitions = {
    'grove_to_temple': "A hidden pathway, revealed by your actions, leads deeper into sacred ground...",
    'clearing_to_depths': "The corruption's influence grows stronger as you descend into darker realms...",
    'temple_to_sanctum': "Ancient mechanisms respond to your presence, opening the way to the heart of the mystery..."
  };

  const transitionKey = `${previousLocation.toLowerCase().split(' ')[0]}_to_${newLocation.toLowerCase().split(' ')[0]}`;
  return transitions[transitionKey as keyof typeof transitions] || "Your journey continues as the path ahead becomes clearer...";
}

function buildContinuityPrompt(request: StoryRequest, progressInfo: any, locationGraph: Map<string, string[]>): string {
  const { campaignId, action, currentLocation, context, skillCheckResult, previousChoices } = request;

  return `You are an expert D&D Dungeon Master creating a cohesive narrative that builds meaningfully from previous events.

=== CRITICAL CONTINUITY REQUIREMENTS ===
CURRENT STORY PROGRESS: ${progressInfo.currentProgress}% complete
ESTIMATED SESSIONS REMAINING: ${progressInfo.estimatedSessionsRemaining}
SHOULD APPROACH ENDING: ${progressInfo.shouldApproachEnding ? 'YES - Begin building toward climax' : 'NO - Continue development'}

=== SCENE CONNECTIVITY RULES ===
1. GEOGRAPHIC LOGIC: Every location change must be geographically sensible
2. NARRATIVE CAUSALITY: Show clear cause-and-effect from previous player actions
3. MOMENTUM BUILDING: Each scene must advance the main story toward resolution
4. CHARACTER AGENCY: Player choices must have visible, lasting consequences

=== CURRENT SITUATION ===
Previous Location: ${getPreviousLocation(previousChoices)}
Current Location: ${currentLocation}
Player Action: ${action}
${skillCheckResult ? `Skill Check: ${skillCheckResult.abilityType} - ${skillCheckResult.success ? 'SUCCESS' : 'FAILURE'} (${skillCheckResult.roll} vs DC ${skillCheckResult.dc})` : ''}

=== AVAILABLE LOCATION CONNECTIONS ===
${Array.from(locationGraph.get(currentLocation || '') || []).map(loc => `- ${loc}`).join('\n')}

=== MANDATORY STORY ELEMENTS TO ADDRESS ===
${progressInfo.shouldApproachEnding ? `
- CLIMAX PREPARATION: Begin introducing final challenges and revelations
- STAKES ESCALATION: Raise the consequences of failure significantly  
- RESOLUTION SETUP: Start laying groundwork for campaign conclusion
` : `
- PLOT ADVANCEMENT: Move core mystery/conflict forward substantially
- CHARACTER DEVELOPMENT: Show growth based on recent successes/failures
- WORLD BUILDING: Expand the setting while maintaining focus
`}

=== SCENE TRANSITION REQUIREMENTS ===
If changing locations, you MUST:
1. Provide clear geographic/narrative reason for the change
2. Reference how previous actions led to this opportunity
3. Maintain visual and thematic continuity
4. Show progression toward main objective

=== CHOICE DESIGN PRINCIPLES ===
Provide 2-3 choices that:
1. Have clear, different consequences for story progression
2. Advance different aspects of the main plot
3. Offer meaningful risk/reward ratios
4. Include at least one choice that could advance toward ending

${progressInfo.shouldApproachEnding ? `
=== ENDING APPROACH PROTOCOL ===
Since the campaign should approach its climax:
- Introduce the final antagonist or challenge
- Reveal major plot secrets or twists  
- Create high-stakes scenarios with permanent consequences
- Offer paths toward definitive resolution of the main conflict
` : ''}

Respond in JSON format with:
{
  "narrative": "Rich, connected storytelling that clearly builds from previous events and shows action consequences",
  "location": "Current location (may change based on player actions and story needs)",
  "sceneTransition": "If location changed, explain the geographic/narrative connection",
  "storyProgression": {
    "mainPlotAdvancement": "How this scene moves the core story forward",
    "consequencesShown": "Visible results of player actions",
    "foreshadowing": "Hints about upcoming challenges or revelations"
  },
  "choices": [
    {
      "action": "Specific action description",
      "description": "What this represents and potential consequences",
      "requiresDiceRoll": boolean,
      "diceType": "d20",
      "rollDC": number,
      "abilityType": "specific D&D ability",
      "rollModifier": number,
      "storyImpact": "minor/moderate/major",
      "progressionType": "advance/explore/resolve"
    }
  ]
}`;
}

function getPreviousLocation(previousChoices?: any[]): string {
  if (!previousChoices || previousChoices.length === 0) return 'Unknown';

  // Try to extract location from previous choice context
  const lastChoice = previousChoices[previousChoices.length - 1];
  return lastChoice?.location || 'Previous area';
}

export async function generateStory(request: StoryRequest) {
  const { campaignId, sessionId, action, currentLocation, context, skillCheckResult, previousChoices } = request;

  try {
    // Get campaign memory and recent context
    const campaignMemory = await getCampaignMemory(campaignId);
    const recentLogs = await getRecentSessionLogs(campaignId);
    const storyArc = await StoryArcManager.getCampaignStoryArc(campaignId);

    // Calculate narrative progress
    const progressInfo = calculateNarrativeProgress(campaignId, recentLogs, skillCheckResult);

    // Build location connectivity graph
    const locationGraph = buildLocationGraph(context || '', recentLogs);

    // Determine next logical location if progression is needed
    const shouldChangeLocation = progressInfo.shouldApproachEnding || recentLogs.length > 8;
    const nextLocation = shouldChangeLocation 
      ? determineNextLogicalLocation(currentLocation || '', action || '', recentLogs.length, locationGraph)
      : currentLocation;

    // Build enhanced prompt with continuity focus
    const prompt = buildContinuityPrompt(request, progressInfo, locationGraph);

    // Generate story with OpenAI
    const completion = await openai.createChatCompletion({
      model: "gpt-3.5-turbo",
      messages: [
        {
          role: "system",
          content: `You are an expert D&D Dungeon Master specializing in narrative continuity and progressive storytelling. Your primary goals are:
1. Create seamless connections between scenes
2. Show clear consequences of player actions
3. Build toward satisfying story conclusions
4. Maintain geographic and narrative logic`
        },
        {
          role: "user",
          content: prompt
        }
      ],
      temperature: 0.7,
      max_tokens: 1200
    });

    const response = completion.data.choices[0]?.message?.content;
    if (!response) {
      throw new Error("Failed to generate story content");
    }

    const parsed = JSON.parse(response);

    // Update campaign progression tracking
    const progression = campaignProgressions.get(campaignId) || {
      totalSessions: 0,
      currentAct: 1,
      maxActs: 3,
      lastLocationChain: [],
      unresolvedPlotThreads: [],
      characterArcs: new Map(),
      narrativeMomentum: 0,
      endingApproaching: false
    };

    progression.totalSessions++;
    progression.endingApproaching = progressInfo.shouldApproachEnding;
    progression.lastLocationChain.push(parsed.location);

    // Keep only last 5 locations for tracking
    if (progression.lastLocationChain.length > 5) {
      progression.lastLocationChain.shift();
    }

    campaignProgressions.set(campaignId, progression);

    // Update story arc progress
    await StoryArcManager.updatePhaseProgress(campaignId, context || '', action || '', skillCheckResult);

    // Log session with enhanced tracking
    if (sessionId) {
      await pushSessionLog(campaignId, {
        sessionId,
        action: action || '',
        narrative: parsed.narrative,
        location: parsed.location,
        storyProgression: parsed.storyProgression,
        continuityElements: {
          sceneTransition: parsed.sceneTransition,
          progressPercentage: progressInfo.currentProgress,
          estimatedRemaining: progressInfo.estimatedSessionsRemaining
        }
      });
    }

    return {
      narrative: parsed.narrative,
      location: parsed.location,
      choices: parsed.choices,
      storyProgression: parsed.storyProgression,
      sceneTransition: parsed.sceneTransition,
      continuityMetrics: {
        progressPercentage: progressInfo.currentProgress,
        estimatedSessionsRemaining: progressInfo.estimatedSessionsRemaining,
        endingApproaching: progressInfo.shouldApproachEnding
      }
    };

  } catch (error) {
    console.error("Error generating story:", error);
    throw error;
  }
}

// Enhanced buildPrompt function with continuity focus
export async function buildPrompt({ campaignId, lastScene, playerAction, sessionHistory = [] }: {
  campaignId: number;
  lastScene: string;
  playerAction: string;
  sessionHistory?: any[];
}): Promise<string> {
  const memory = await getCampaignMemory(campaignId);
  const storyArc = await StoryArcManager.getCampaignStoryArc(campaignId);
  const progressInfo = calculateNarrativeProgress(campaignId, sessionHistory);

  return `You are a D&D DM focused on narrative continuity and progression toward a satisfying conclusion.

CAMPAIGN MEMORY: ${memory}

STORY ARC: ${storyArc.title} - Phase ${storyArc.currentPhase + 1}/${storyArc.phases.length}
CURRENT PHASE: ${storyArc.phases[storyArc.currentPhase]?.title}
PROGRESS: ${progressInfo.currentProgress}% complete

LAST SCENE: ${lastScene}
PLAYER ACTION: ${playerAction}

RECENT SESSION CHAIN: ${sessionHistory.slice(-3).map(s => `${s.location}: ${s.narrative?.substring(0, 100)}...`).join(' → ')}

CONTINUITY REQUIREMENTS:
1. Show clear results of the player action
2. Advance the main story meaningfully
3. Maintain geographic/narrative logic
4. ${progressInfo.shouldApproachEnding ? 'BUILD TOWARD CLIMACTIC RESOLUTION' : 'DEVELOP PLOT AND CHARACTERS'}

ESTIMATED SESSIONS REMAINING: ${progressInfo.estimatedSessionsRemaining}

Respond with a narrative that clearly connects to previous events and advances toward conclusion.`;
}

import { storage } from './storage';
// Track major campaign elements and plot thread
interface StoryThread {
  mainQuest?: string;
  currentLocation: string;
  keyNPCs: string[];
  activeThreats: string[];
  plotStatus: {
    groveCorruption?: boolean;
    altarActivated?: boolean;
    guardianState?: 'corrupted' | 'purified' | 'dormant';
  }
}

// Extract and maintain story thread from context
const extractStoryThread = (context: string): StoryThread => {
  return {
    currentLocation: context?.match(/Location: ([^\.]+)/)?.[1] || currentLocation,
    keyNPCs: context?.match(/([A-Z][a-z]+(?:\s[A-Z][a-z]+)*)\s+(?:the\s+)?(?:druid|wizard|warrior|ranger|priest|guardian)/g) || [],
    activeThreats: context?.match(/(shadow wolf|corrupted guardian|twisted spirits|dark force)/gi) || [],
    plotStatus: {
      groveCorruption: context?.toLowerCase().includes('corrupted') || context?.toLowerCase().includes('darkness'),
      altarActivated: context?.toLowerCase().includes('altar glows') || context?.toLowerCase().includes('ritual complete'),
      guardianState: context?.toLowerCase().includes('corrupted guardian') ? 'corrupted' : 'dormant'
    }
  };
};

// Check for combat-related actions and transitions while maintaining narrative
const isCombatAction = (action?.toLowerCase().includes('attack') || 
                      action?.toLowerCase().includes('fight') ||
                      action?.toLowerCase().includes('strike')) ||
                      (skillCheckResult && !skillCheckResult.success && 
                       context?.toLowerCase().includes('hostile') &&
                       context?.toLowerCase().includes('creature'));

// Force combat to trigger when appropriate
if (isCombatAction) {
  console.log("Combat trigger activated:", { action, context, skillCheckResult });
  return {
    narrative: `The situation turns violent as combat begins!`,
    location: currentLocation,
    combatInitiated: true,
    monster: {
      name: context?.match(/(shadow wolf|treant|corrupted guardian|beast)/i)?.[0] || 'Hostile Creature',
      type: 'beast',
      challengeRating: 3
    }
  };
}

const storyThread = extractStoryThread(context);

if (isCombatAction && !context?.includes('combat initiated')) {
  // Generate combat encounter that maintains narrative continuity
  // Generate combat encounter
  const monster = {
    name: context?.match(/shadow wolf|treant|corrupted guardian|beast/i)?.[0] || 'Unknown Creature',
    type: 'beast',
    size: 'Large',
    armorClass: 15,
    hitPoints: 45,
    currentHitPoints: 45,
    strength: 16,
    dexterity: 14,
    constitution: 14,
    intelligence: 6,
    wisdom: 12,
    charisma: 8,
    challengeRating: 3,
    abilities: ['Keen Hearing and Smell', 'Pack Tactics'],
    actions: [
      {
        name: 'Bite',
        description: 'Melee Weapon Attack: +5 to hit, reach 5 ft., one target. Hit: 10 (2d6 + 3) piercing damage.',
        toHit: 5,
        damage: '2d6+3'
      }
    ]
  };

  await storage.createCombatEncounter(campaignId, {
    title: `Battle with ${monster.name}`,
    description: `A fierce battle with ${monster.name} begins!`,
    location: currentLocation,
    monsters: [monster]
  });

  // Generate narrative-appropriate combat description
  const combatContext = `The ${monster.name} emerges from ${storyThread.plotStatus.groveCorruption ? 'the corrupted shadows' : 'the grove'}, its presence a manifestation of the darkness plaguing this sacred place. ${storyThread.keyNPCs[0] || 'Elowen'} readies their defenses as the battle begins.`;

  return {
    narrative: combatContext,
    location: currentLocation,
    combatInitiated: true,
    storyThread: storyThread, // Preserve story context
    choices: []
  };
}

// Enhanced combat and encounter detection
const isCombatAction2 = (action?.toLowerCase().includes('attack') || 
                      action?.toLowerCase().includes('fight') ||
                      action?.toLowerCase().includes('strike') ||
                      action?.toLowerCase().includes('confront')) ||
                      (skillCheckResult && !skillCheckResult.success && 
                       context?.toLowerCase().includes('hostile') &&
                       context?.toLowerCase().includes('creature'));

// Check for NPC interaction triggers
const isNPCInteraction = action?.toLowerCase().includes('talk') ||
                        action?.toLowerCase().includes('speak') ||
                        action?.toLowerCase().includes('ask') ||
                        action?.toLowerCase().includes('persuade') ||
                        context?.toLowerCase().includes('npc') ||
                        context?.toLowerCase().includes('character');

// Force combat encounter when appropriate
if (isCombatAction2 && !context?.includes('combat initiated')) {
  // Determine monster based on current story context
  const monsterName = context?.match(/(dark sprites|corrupted guardian|shadow wolf|treant|beast)/i)?.[0] || 'Hostile Creature';
  
  return {
    narrative: `The situation turns dangerous as combat begins! ${monsterName} emerge to challenge you, their forms crackling with dark energy.`,
    location: currentLocation,
    combatInitiated: true,
    monster: {
      name: monsterName,
      type: monsterName.toLowerCase().includes('sprite') ? 'fey' : 'beast',
      challengeRating: monsterName.toLowerCase().includes('sprite') ? 2 : 3
    },
    choices: []
  };
}

// Handle successful combat resolution and force story progression
if (context?.includes('combat') && skillCheckResult?.success && 
    (action?.toLowerCase().includes('attack') || action?.toLowerCase().includes('engage'))) {
  
  // Check session count to determine if location change is needed
  const sessionCount = previousChoices?.length || 0;
  const shouldAdvanceLocation = sessionCount > 15;
  
  let newLocation = currentLocation;
  let progressionNarrative = '';
  
  if (shouldAdvanceLocation && currentLocation?.toLowerCase().includes('grove')) {
    newLocation = 'Temple of the Ancient Guardians';
    progressionNarrative = ` As the last dark sprite falls, a hidden passage opens in the ancient stone, revealing stairs descending into a mystical temple where the true source of the corruption awaits.`;
  }
  
  return {
    narrative: `Your attack strikes true! The ${context?.match(/(dark sprites|creature)/i)?.[0] || 'enemy'} staggers under the blow, dark energy dissipating from its form.${progressionNarrative}`,
    location: newLocation,
    combatInProgress: true,
    choices: [
      {
        action: "Continue the assault",
        description: "Press your advantage with another attack",
        requiresDiceRoll: true,
        diceType: "d20",
        rollDC: 14,
        abilityType: "attack",
        rollModifier: 2
      },
      {
        action: "Cast a protective spell",
        description: "Use magic to shield yourself or allies",
        requiresDiceRoll: true,
        diceType: "d20",
        rollDC: 13,
        abilityType: "arcana",
        rollModifier: 1
      },
      ...(shouldAdvanceLocation ? [{
        action: "Investigate the revealed passage",
        description: "Explore the mysterious temple entrance",
        requiresDiceRoll: true,
        diceType: "d20",
        rollDC: 12,
        abilityType: "investigation",
        rollModifier: 0
      }] : [])
    ]
  };
}

// Handle NPC interactions
if (isNPCInteraction && !context?.includes('npc dialog active')) {
  return {
    narrative: `${context} A conversation begins...`,
    location: currentLocation,
    npcInteraction: true,
    choices: []
  };
}

// Check if combat is over (all monsters defeated)
const updatedEncounter = await storage.getActiveEncounter(campaignId);
const allMonstersDefeated = updatedEncounter?.monsters.every((m: any) => m.currentHitPoints <= 0) ?? true;

// Add new functions for mechanics tracking
async function getCharacterProgression(campaignId: number): Promise<any> {
  // Placeholder: replace with actual data retrieval logic
  return {
    levels: 3,
    skillsLearned: ['Animal Handling', 'Perception']
  };
}

async function getActiveStoryArcs(campaignId: number): Promise<any[]> {
  // Placeholder: replace with actual data retrieval logic
  return [
    {
      title: 'The Corruption of the Grove',
      status: 'active',
      stage: 'investigation'
    }
  ];
}

async function buildConsequencesTracker(sessionHistory: any[]): Promise<any> {
  // Placeholder: replace with actual data processing logic
  return {
    failedChecks: sessionHistory.filter(s => s.skillChecks?.some(sc => !sc.success)).length,
    alliesLost: 0
  };
}

async function updateStoryArcsFromAction(campaignId: number, action: string, lastChoice: any, storyUpdate: any): Promise<void> {
  // Placeholder: replace with actual arc update logic
  console.log('Updating story arcs based on action:', action);
}

function parseStoryResponseWithContinuity(response: string, context: any): any {
  try {
    const parsed = JSON.parse(response);

    // Enhance with story progression
    parsed.storyProgression = {
      corruptionLevel: context.mechanicsContext.consequencesTracker.failedChecks > 3 ? 'worsening' : 'stable',
      npcTrust: 'unchanged'
    };

    return parsed;
  } catch (error) {
    console.error("Failed to parse enhanced story response:", error);
    return { narrative: "Story parsing failed", location: context.location, choices: [] };
  }
}

// New buildEnhancedPrompt function
function buildEnhancedPrompt(data: any): any {
  const { action, campaign, sessionHistory, location, narrative, characters, lastChoice, antiRepetition, currentSession, mechanicsContext } = data;

  const systemPrompt = `You are a D&D Dungeon Master expert in mechanics integration.

CAMPAIGN MEMORY:
${campaign.description}

SESSION HISTORY:
${sessionHistory.map(s => `- ${s.location}: ${s.narrative}`).join('\n')}

MECHANICS CONTEXT:
Recent Skill Checks: ${mechanicsContext.recentSkillChecks.length}
Combat History: ${mechanicsContext.combatHistory.length}
Character Progression: ${JSON.stringify(mechanicsContext.characterProgression)}
Story Arcs: ${JSON.stringify(mechanicsContext.storyArcs)}
Consequences Tracker: ${JSON.stringify(mechanicsContext.consequencesTracker)}

INSTRUCTIONS:
1. Show concrete consequences of player actions, dice rolls, and skill checks.
2. Advance story arcs based on player choices.
3. Reflect character progression in the narrative.
4. Meaningfully integrate mechanics into the story.
5. Do not repeat identical descriptions.

Output in JSON format:
{
  "narrative": "...",
  "location": "...",
  "choices": []
}
`;

  const userPrompt = `The player is at ${location}. Last action: ${action}.  ${narrative}`;

  return { systemPrompt, userPrompt };
}

// Replace the old handleDMResponseStream function with the new one
export async function handleDMResponseStream(req: Request, res: Response) {
  try {
    const {
      action,
      campaignId,
      sessionHistory = [],
      location,
      narrative,
      characters,
      lastChoice,
      antiRepetition = {}
    } = req.body;

    if (!action || !campaignId) {
      return res.status(400).json({ error: 'Missing required fields' });
    }

    // Get campaign and session data
    const campaign = await storage.getCampaign(campaignId);
    if (!campaign) {
      return res.status(404).json({ error: 'Campaign not found' });
    }

    const sessions = await storage.getCampaignSessions(campaignId);
    const currentSession = sessions[sessions.length - 1];

    // Track mechanics and outcomes from previous actions
    const mechanicsContext = {
      recentSkillChecks: sessionHistory.slice(-5).filter(h => h.skillChecks?.length > 0),
      combatHistory: sessionHistory.slice(-3).filter(h => h.combatOutcome),
      characterProgression: await getCharacterProgression(campaignId),
      storyArcs: await getActiveStoryArcs(campaignId),
      consequencesTracker: await buildConsequencesTracker(sessionHistory)
    };

    // Build enhanced context with mechanics tracking
    const context = buildEnhancedPrompt({
      action,
      campaign,
      sessionHistory,
      location,
      narrative,
      characters,
      lastChoice,
      antiRepetition,
      currentSession,
      mechanicsContext
    });

    console.log('🎲 Generated DM context with enhanced mechanics integration');

    // Use OpenAI for story generation
    const completion = await openai.chat.completions.create({
      model: "gpt-3.5-turbo",
      messages: [
        {
          role: "system",
          content: context.systemPrompt
        },
        {
          role: "user",
          content: context.userPrompt
        }
      ],
      temperature: 0.8,
      max_tokens: 1200,
      stream: false
    });

    const response = completion.choices[0]?.message?.content;
    if (!response) {
      throw new Error('No response from OpenAI');
    }

    // Parse and structure the response with better continuity
    const storyUpdate = parseStoryResponseWithContinuity(response, {
      location,
      sessionHistory,
      lastChoice,
      mechanicsContext
    });

    // Update story arcs based on player actions
    await updateStoryArcsFromAction(campaignId, action, lastChoice, storyUpdate);

    // Log the session with detailed mechanics tracking
    if (currentSession) {
      await logSessionUpdate(currentSession.id, {
        action,
        narrative: storyUpdate.narrative,
        location: storyUpdate.location,
        skillChecks: lastChoice?.skillCheckResult ? [lastChoice.skillCheckResult] : [],
        combatOutcome: lastChoice?.combatOutcome,
        rewards: lastChoice?.rewards,
        storyProgression: storyUpdate.storyProgression
      });
    }

    // Check for special encounters
    const encounterType = detectEncounterType(storyUpdate.narrative);
    if (encounterType === 'combat') {
      await handleCombatEncounter(campaignId, storyUpdate);
    } else if (encounterType === 'npc') {
      await handleNPCEncounter(campaignId, storyUpdate);
    }

    res.json(storyUpdate);

  } catch (error) {
    console.error('🛑 DM Response Stream Error:', error);
    res.status(500).json({ 
      error: 'Failed to generate story response',
      details: error instanceof Error ? error.message : 'Unknown error'
    });
  }
}