import { Router } from 'express';
import { handleDMResponseStream } from '../lib/openai';
import { storage } from '../storage';

const router = Router();

router.post('/dm', async (req, res) => {
  try {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Not authenticated" });
    }

    res.setHeader('Content-Type', 'text/plain');
    res.setHeader('Cache-Control', 'no-cache');
    res.setHeader('Connection', 'keep-alive');
    res.setHeader('Transfer-Encoding', 'chunked');

    const campaignId = req.body.campaignId;

    // Get last session summary
    const lastSession = await storage.getLastSession(campaignId);
    const lastSummary = lastSession?.summary || '';

    await handleDMResponseStream(
      req.body.action,
      {
        sessionHistory: req.body.sessionHistory || [],
        location: req.body.location,
        narrative: req.body.narrative,
        characters: req.body.characters,
        lastChoice: req.body.lastChoice,
        lastSessionSummary: lastSummary
      },
      (chunk: string) => {
        res.write(chunk);
      }
    );

    res.end();
  } catch (error) {
    console.error('DM API error:', error);
    res.status(500).json({ message: 'Failed to get DM response' });
  }
});

export default router;