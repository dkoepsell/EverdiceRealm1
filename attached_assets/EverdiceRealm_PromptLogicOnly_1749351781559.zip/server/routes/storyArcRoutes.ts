
import express, { Request, Response } from 'express';
import { StoryArcManager } from '../lib/storyArcManager';
import { requireAuth } from '../auth';

const router = express.Router();

// Get story arc for a campaign
router.get('/campaigns/:campaignId/story-arc', requireAuth, async (req: Request, res: Response) => {
  try {
    const campaignId = parseInt(req.params.campaignId);
    if (isNaN(campaignId)) {
      return res.status(400).json({ message: "Invalid campaign ID" });
    }

    const storyArc = await StoryArcManager.getCampaignStoryArc(campaignId);
    res.json(storyArc);
  } catch (error) {
    console.error("Error fetching story arc:", error);
    res.status(500).json({ message: "Failed to fetch story arc" });
  }
});

// Force story arc phase completion (DM tool)
router.post('/campaigns/:campaignId/story-arc/complete-phase', requireAuth, async (req: Request, res: Response) => {
  try {
    const campaignId = parseInt(req.params.campaignId);
    if (isNaN(campaignId)) {
      return res.status(400).json({ message: "Invalid campaign ID" });
    }

    const result = await StoryArcManager.updatePhaseProgress(
      campaignId, 
      'forced completion', 
      'complete phase'
    );
    
    res.json({ 
      success: true, 
      phaseComplete: result.phaseComplete,
      arcComplete: result.arcComplete,
      rewards: result.rewards
    });
  } catch (error) {
    console.error("Error completing phase:", error);
    res.status(500).json({ message: "Failed to complete phase" });
  }
});

// Check all campaigns for closure (admin endpoint)
router.post('/story-arcs/check-closure', requireAuth, async (req: Request, res: Response) => {
  try {
    await StoryArcManager.checkAllCampaignsForClosure();
    res.json({ success: true, message: "Checked all campaigns for story arc closure" });
  } catch (error) {
    console.error("Error checking campaigns:", error);
    res.status(500).json({ message: "Failed to check campaigns" });
  }
});

export default router;
