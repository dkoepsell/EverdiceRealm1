import { Router } from "express";
import { storage } from "../storage";

const router = Router();

router.post("/roll", async (req, res) => {
  try {
    console.log("Dice roll request body:", req.body);

    const { diceType, count, modifier, purpose, characterId, campaignId } = req.body;
    const userId = req.user?.id;

    if (!userId) {
      return res.status(401).json({ message: "User not authenticated" });
    }

    // Validate required fields
    if (!campaignId) {
      return res.status(400).json({ 
        message: "Campaign ID is required for dice rolls" 
      });
    }

    // Generate the dice roll result
    const sides = parseInt(diceType.replace('d', ''));
    let total = 0;
    const rolls = [];

    for (let i = 0; i < (count || 1); i++) {
      const roll = Math.floor(Math.random() * sides) + 1;
      rolls.push(roll);
      total += roll;
    }

    const finalTotal = total + (modifier || 0);

    // Create dice roll record
    const diceRoll = {
      userId,
      characterId: characterId || null, // Allow null for DM rolls
      campaignId,
      diceType,
      result: finalTotal,
      modifier: modifier || 0,
      count: count || 1,
      purpose: purpose || "General roll",
      rolls,
      total: finalTotal
    };

    // Store the dice roll if storage method exists
    let savedRoll = null;
    try {
      if (storage.createDiceRoll) {
        savedRoll = await storage.createDiceRoll(diceRoll);
      }
    } catch (storageError) {
      console.warn("Failed to save dice roll to storage:", storageError);
      // Continue without saving to storage
    }

    res.json({
      success: true,
      roll: {
        ...diceRoll,
        id: savedRoll?.id || Date.now()
      }
    });
  } catch (error) {
    console.error("Dice roll error:", error);
    res.status(500).json({ 
      message: "Failed to process dice roll", 
      error: error instanceof Error ? error.message : "Unknown error"
    });
  }
});

router.get("/history/:userId", async (req, res) => {
  try {
    const userId = parseInt(req.params.userId);
    const limit = parseInt(req.query.limit as string) || 10;

    if (!userId || isNaN(userId)) {
      return res.status(400).json({ message: "Valid user ID is required" });
    }

    let history = [];
    try {
      if (storage.getDiceRollHistory) {
        history = await storage.getDiceRollHistory(userId, limit);
      }
    } catch (storageError) {
      console.warn("Failed to fetch dice roll history:", storageError);
      // Return empty history instead of error
    }

    res.json(history);
  } catch (error) {
    console.error("Error fetching dice roll history:", error);
    res.status(500).json({ message: "Failed to fetch dice roll history" });
  }
});

export default router;