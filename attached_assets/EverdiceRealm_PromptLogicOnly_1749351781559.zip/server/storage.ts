import { 
  users, type User, type InsertUser,
  characters, type Character, type InsertCharacter,
  campaigns, type Campaign, type InsertCampaign,
  campaignSessions, type CampaignSession, type InsertCampaignSession,
  diceRolls, type DiceRoll, type InsertDiceRoll,
  userSessions, type UserSession, type InsertUserSession,
  adventureCompletions, type AdventureCompletion, type InsertAdventureCompletion,
  campaignParticipants, type CampaignParticipant, type InsertCampaignParticipant,
  // New schema imports for DM tools and learning content
  learningContent, type LearningContent, type InsertLearningContent,
  adventureTemplates, type AdventureTemplate, type InsertAdventureTemplate,
  encounters, type Encounter, type InsertEncounter,
  adventureElements, type AdventureElement, type InsertAdventureElement,
  // NPC companion imports
  npcs, type Npc, type InsertNpc,
  campaignNpcs, type CampaignNpc, type InsertCampaignNpc,
  // Live Campaign Management imports
  campaignInvitations, type CampaignInvitation, type InsertCampaignInvitation,
  dmNotes, type DmNote, type InsertDmNote,
  inventory, type Inventory, type InsertInventory
} from "@shared/schema";
import { db } from "./db";
import { eq, and, desc, sql, asc, or } from "drizzle-orm";
import * as schema from "@shared/schema";

// modify the interface with any CRUD methods
// you might need

export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUserLastLogin(userId: number): Promise<void>;

  // User Session operations
  createUserSession(session: InsertUserSession): Promise<UserSession>;
  getUserSession(token: string): Promise<UserSession | undefined>;
  deleteUserSession(token: string): Promise<boolean>;
  deleteUserSessionsForUser(userId: number): Promise<boolean>;

  // Character operations
  getAllCharacters(): Promise<Character[]>;
  getCharacter(id: number): Promise<Character | undefined>;
  createCharacter(character: InsertCharacter): Promise<Character>;
  updateCharacter(id: number, character: Partial<Character>): Promise<Character | undefined>;
  deleteCharacter(id: number): Promise<boolean>;

  // Campaign operations
  getAllCampaigns(): Promise<Campaign[]>;
  getArchivedCampaigns(): Promise<Campaign[]>;
  getCampaign(id: number): Promise<Campaign | undefined>;
  createCampaign(campaign: InsertCampaign): Promise<Campaign>;
  updateCampaign(id: number, campaign: Partial<Campaign>): Promise<Campaign | undefined>;
  updateCampaignSession(id: number, sessionNumber: number): Promise<Campaign | undefined>;
  archiveCampaign(id: number): Promise<Campaign | undefined>;
  completeCampaign(id: number): Promise<Campaign | undefined>;
  deleteCampaign(id: number): Promise<boolean>;

  // Campaign Participant operations
  getCampaignParticipants(campaignId: number): Promise<CampaignParticipant[]>;
  getCampaignParticipant(campaignId: number, userId: number): Promise<CampaignParticipant | undefined>;
  addCampaignParticipant(participant: InsertCampaignParticipant): Promise<CampaignParticipant>;
  updateCampaignParticipant(id: number, updates: Partial<CampaignParticipant>): Promise<CampaignParticipant | undefined>;
  removeCampaignParticipant(campaignId: number, userId: number): Promise<boolean>;

  // Turn-based campaign operations
  getCurrentTurn(campaignId: number): Promise<{ userId: number; startedAt: string } | undefined>;
  startNextTurn(campaignId: number): Promise<{ userId: number; startedAt: string } | undefined>;
  endCurrentTurn(campaignId: number): Promise<boolean>;

  // Campaign Session operations
  getCampaignSession(campaignId: number, sessionNumber: number): Promise<CampaignSession | undefined>;
  getCampaignSessions(campaignId: number): Promise<CampaignSession[]>;
  createCampaignSession(session: InsertCampaignSession): Promise<CampaignSession>;

  // Dice Roll operations
  createDiceRoll(diceRoll: InsertDiceRoll): Promise<DiceRoll>;
  getDiceRollHistory(userId: number, limit?: number): Promise<DiceRoll[]>;

  // Adventure Completion operations
  createAdventureCompletion(completion: InsertAdventureCompletion): Promise<AdventureCompletion>;
  getCompletionsForUser(userId: number): Promise<AdventureCompletion[]>;
  getCompletionsForCharacter(characterId: number): Promise<AdventureCompletion[]>;

  // XP Management operations
  awardXPToCharacter(characterId: number, xpAmount: number): Promise<Character | undefined>;

  // Learning Content operations
  getAllLearningContent(): Promise<LearningContent[]>;
  getLearningContentByCategory(category: string): Promise<LearningContent[]>;
  getLearningContent(id: number): Promise<LearningContent | undefined>;
  createLearningContent(content: InsertLearningContent): Promise<LearningContent>;
  updateLearningContent(id: number, content: Partial<LearningContent>): Promise<LearningContent | undefined>;
  deleteLearningContent(id: number): Promise<boolean>;

  // Adventure Template operations
  getAllAdventureTemplates(): Promise<AdventureTemplate[]>;
  getPublicAdventureTemplates(): Promise<AdventureTemplate[]>;
  getUserAdventureTemplates(userId: number): Promise<AdventureTemplate[]>;
  getAdventureTemplate(id: number): Promise<AdventureTemplate | undefined>;
  createAdventureTemplate(template: InsertAdventureTemplate): Promise<AdventureTemplate>;
  updateAdventureTemplate(id: number, template: Partial<AdventureTemplate>): Promise<AdventureTemplate | undefined>;
  deleteAdventureTemplate(id: number): Promise<boolean>;

  // Encounter operations
  getEncountersByCampaign(campaignId: number): Promise<Encounter[]>;
  getUserEncounters(userId: number): Promise<Encounter[]>;
  getEncounter(id: number): Promise<Encounter | undefined>;
  createEncounter(encounter: InsertEncounter): Promise<Encounter>;
  updateEncounter(id: number, encounter: Partial<Encounter>): Promise<Encounter | undefined>;
  deleteEncounter(id: number): Promise<boolean>;

  // Adventure Elements operations 
  getAdventureElementsByType(elementType: string): Promise<AdventureElement[]>;
  getUserAdventureElements(userId: number): Promise<AdventureElement[]>;
  getPublicAdventureElements(): Promise<AdventureElement[]>;
  getAdventureElement(id: number): Promise<AdventureElement | undefined>;
  createAdventureElement(element: InsertAdventureElement): Promise<AdventureElement>;
  updateAdventureElement(id: number, element: Partial<AdventureElement>): Promise<AdventureElement | undefined>;
  deleteAdventureElement(id: number): Promise<boolean>;

  // NPC operations
  getAllNpcs(): Promise<Npc[]>;
  getUserNpcs(userId: number): Promise<Npc[]>;
  getCompanionNpcs(userId: number): Promise<Npc[]>;
  getNpc(id: number): Promise<Npc | undefined>;
  createNpc(npc: InsertNpc): Promise<Npc>;
  updateNpc(id: number, npc: Partial<Npc>): Promise<Npc | undefined>;
  deleteNpc(id: number): Promise<boolean>;

  // Campaign NPC operations
  getCampaignNpcs(campaignId: number): Promise<CampaignNpc[]>;
  getCampaignNpc(campaignId: number, npcId: number): Promise<CampaignNpc | undefined>;
  addNpcToCampaign(campaignNpc: InsertCampaignNpc): Promise<CampaignNpc>;
  updateCampaignNpc(id: number, updates: Partial<CampaignNpc>): Promise<CampaignNpc | undefined>;
  removeNpcFromCampaign(campaignId: number, npcId: number): Promise<boolean>;

  // NPC Turn operations
  getNpcTurn(campaignId: number, npcId: number): Promise<{ action: string; target?: number; details?: any } | undefined>;
  simulateNpcTurn(campaignId: number, npcId: number): Promise<{ action: string; target?: number; details?: any; message: string }>;

  // Campaign Invitation operations
  createCampaignInvitation(invitation: InsertCampaignInvitation): Promise<CampaignInvitation>;
  getCampaignInvitations(campaignId: number): Promise<CampaignInvitation[]>;
  getCampaignInvitationByCode(inviteCode: string): Promise<CampaignInvitation | undefined>;
  updateCampaignInvitation(id: number, updates: Partial<CampaignInvitation>): Promise<CampaignInvitation | undefined>;
  useInvitation(inviteCode: string): Promise<CampaignInvitation | undefined>;
  deleteCampaignInvitation(id: number): Promise<boolean>;

  // DM Notes operations
  createDmNote(note: InsertDmNote): Promise<DmNote>;
  getDmNotes(campaignId: number, createdBy: number): Promise<DmNote[]>;
  getDmNote(id: number): Promise<DmNote | undefined>;
  updateDmNote(id: number, updates: Partial<DmNote>): Promise<DmNote | undefined>;
  deleteDmNote(id: number): Promise<boolean>;

  //Campaign metadata and rewards
  updateCampaignMetadata(campaignId: number, metadata: any): Promise<void>;
  getActiveCampaigns(): Promise<Campaign[]>;
  applyCampaignRewards(campaignId: number, rewards: any): Promise<void>;

  // User statistics
  getTotalRegisteredUsers(): Promise<number>;
  getOnlineUsersCount(): Promise<number>;

  // Inventory operations
  getCharacterInventory(characterId: number): Promise<Inventory[]>;
  addItemToInventory(item: InsertInventory): Promise<Inventory>;
  updateInventoryItem(id: number, updates: Partial<Inventory>): Promise<Inventory | undefined>;
  removeItemFromInventory(id: number): Promise<boolean>;

  // Locations operations
  getUserLocations(userId: number): Promise<any[]>;
  createLocation(locationData: any): Promise<any>;
  updateLocation(locationId: number, userId: number, locationData: any): Promise<any>;
  deleteLocation(locationId: number, userId: number): Promise<void>;

  // Magic Items operations
  getUserMagicItems(userId: number): Promise<any[]>;
  createMagicItem(itemData: any): Promise<any>;
  updateMagicItem(itemId: number, userId: number, itemData: any): Promise<any>;
  deleteMagicItem(itemId: number, userId: number): Promise<void>;

  // Monsters operations
  getUserMonsters(userId: number): Promise<any[]>;
  createMonster(monsterData: any): Promise<any>;
  updateMonster(monsterId: number, userId: number, monsterData: any): Promise<any>;
  deleteMonster(monsterId: number, userId: number): Promise<void>;

  // Quests operations
  getUserQuests(userId: number): Promise<any[]>;
  createQuest(questData: any): Promise<any>;
  updateQuest(questId: number, userId: number, questData: any): Promise<any>;
  deleteQuest(questId: number, userId: number): Promise<void>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private characterStore: Map<number, Character>;
  private campaignStore: Map<number, Campaign>;
  private sessionStore: Map<string, CampaignSession>; // key is campaignId:sessionNumber
  private diceRollStore: Map<number, DiceRoll>;

  private userIdCounter: number;
  private characterIdCounter: number;
  private campaignIdCounter: number;
  private sessionIdCounter: number;
  private diceRollIdCounter: number;

  constructor() {
    this.users = new Map();
    this.characterStore = new Map();
    this.campaignStore = new Map();
    this.sessionStore = new Map();
    this.diceRollStore = new Map();

    this.userIdCounter = 1;
    this.characterIdCounter = 1;
    this.campaignIdCounter = 1;
    this.sessionIdCounter = 1;
    this.diceRollIdCounter = 1;

    // Add sample data for demonstration
    this.initializeSampleData();
  }

  // User operations
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userIdCounter++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  // Character operations
  async getAllCharacters(): Promise<Character[]> {
    return Array.from(this.characterStore.values());
  }

  async getCharacter(id: number): Promise<Character | undefined> {
    return this.characterStore.get(id);
  }

  async createCharacter(insertCharacter: InsertCharacter): Promise<Character> {
    const id = this.characterIdCounter++;
    const character: Character = { ...insertCharacter, id };
    this.characterStore.set(id, character);
    return character;
  }

  async updateCharacter(id: number, characterUpdate: Partial<Character>): Promise<Character | undefined> {
    const character = this.characterStore.get(id);
    if (!character) return undefined;

    const updatedCharacter = { ...character, ...characterUpdate };
    this.characterStore.set(id, updatedCharacter);
    return updatedCharacter;
  }

  async deleteCharacter(id: number): Promise<boolean> {
    return this.characterStore.delete(id);
  }

  // Campaign operations
  async getAllCampaigns(): Promise<Campaign[]> {
    return Array.from(this.campaignStore.values());
  }

  async getCampaign(id: number): Promise<Campaign | undefined> {
    return this.campaignStore.get(id);
  }

  async createCampaign(insertCampaign: InsertCampaign): Promise<Campaign> {
    const id = this.campaignIdCounter++;
    const campaign: Campaign = { ...insertCampaign, id };
    this.campaignStore.set(id, campaign);
    return campaign;
  }

  async updateCampaign(id: number, campaignUpdate: Partial<Campaign>): Promise<Campaign | undefined> {
    const campaign = this.campaignStore.get(id);
    if (!campaign) return undefined;

    const updatedCampaign = { ...campaign, ...campaignUpdate };
    this.campaignStore.set(id, updatedCampaign);
    return updatedCampaign;
  }

  async updateCampaignSession(id: number, sessionNumber: number): Promise<Campaign | undefined> {
    const campaign = this.campaignStore.get(id);
    if (!campaign) return undefined;

    const updatedCampaign = { 
      ...campaign, 
      currentSession: sessionNumber 
    };
    this.campaignStore.set(id, updatedCampaign);
    return updatedCampaign;
  }

  async deleteCampaign(id: number): Promise<boolean> {
    return this.campaignStore.delete(id);
  }

  // Campaign Session operations
  async getCampaignSession(campaignId: number, sessionNumber: number): Promise<CampaignSession | undefined> {
    const key = `${campaignId}:${sessionNumber}`;
    return this.sessionStore.get(key);
  }

  async getCampaignSessions(campaignId: number): Promise<CampaignSession[]> {
    const sessions: CampaignSession[] = [];
    for (const session of this.sessionStore.values()) {
      if (session.campaignId === campaignId) {
        sessions.push(session);
      }
    }
    return sessions.sort((a, b) => a.sessionNumber - b.sessionNumber);
  }

  async createCampaignSession(insertSession: InsertCampaignSession): Promise<CampaignSession> {
    const id = this.sessionIdCounter++;
    const session: CampaignSession = { ...insertSession, id };
    const key = `${session.campaignId}:${session.sessionNumber}`;
    this.sessionStore.set(key, session);
    return session;
  }

  // Dice Roll operations
  async createDiceRoll(insertDiceRoll: InsertDiceRoll): Promise<DiceRoll> {
    const id = this.diceRollIdCounter++;
    const diceRoll: DiceRoll = { ...insertDiceRoll, id };
    this.diceRollStore.set(id, diceRoll);
    return diceRoll;
  }

  async getDiceRollHistory(userId: number, limit: number = 10): Promise<DiceRoll[]> {
    const userRolls = Array.from(this.diceRollStore.values())
      .filter(roll => roll.userId === userId)
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());

    return userRolls.slice(0, limit);
  }

  //Campaign metadata and rewards
  async updateCampaignMetadata(campaignId: number, metadata: any): Promise<void> {
    const campaign = this.campaignStore.get(campaignId);
    if(campaign) {
      campaign.metadata = metadata;
    }
  }
  async getActiveCampaigns(): Promise<Campaign[]> {
    return Array.from(this.campaignStore.values()).filter(campaign => !campaign.isCompleted && !campaign.isArchived);
  }
  async applyCampaignRewards(campaignId: number, rewards: any): Promise<void> {
    // For MemStorage this is a placeholder and doesn't actually do anything.
    // In a real implementation, it would update the characters in the campaign.
    const campaign = this.campaignStore.get(campaignId);
    if(campaign) {
      campaign.rewards = rewards;
    }
  }

   async getTotalRegisteredUsers(): Promise<number> {
     return this.users.size;
   }

   async getOnlineUsersCount(): Promise<number> {
     return 1; // Placeholder for file storage
   }

    async getUserLocations(userId: number): Promise<any[]> {
        // TODO: Implement in memstorage
        return [];
    }
    async createLocation(locationData: any): Promise<any> {
        throw new Error("Method not implemented.");
    }
    async updateLocation(locationId: number, userId: number, locationData: any): Promise<any> {
        throw new Error("Method not implemented.");
    }
    async deleteLocation(locationId: number, userId: number): Promise<void> {
        throw new Error("Method not implemented.");
    }

  // Initialize sample data for demonstration
  private async initializeSampleData() {
    // Create sample user
    const user = await this.createUser({
      username: "demo_user",
      password: "password123"
    });

    // Create sample character
    const character = await this.createCharacter({
      userId: user.id,
      name: "Thorne Ironfist",
      race: "Dwarf",
      class: "Fighter",
      level: 5,
      background: "Soldier",
      alignment: "Lawful Good",
      strength: 16,
      dexterity: 12,
      constitution: 15,
      intelligence: 10,
      wisdom: 13,
      charisma: 8,
      hitPoints: 45,
      maxHitPoints: 45,
      armorClass: 17,
      skills: ["Athletics", "Perception", "Intimidation", "Survival"],
      equipment: ["Battleaxe", "Chain Mail", "Shield", "Adventurer's Pack"],
      createdAt: new Date().toISOString()
    });

    // Create sample campaign
    const campaign = await this.createCampaign({
      userId: user.id,
      title: "The Forgotten Crypts",
      description: "An adventure into ancient crypts filled with undead and forgotten treasures.",
      difficulty: "Normal - Balanced Challenge",
      narrativeStyle: "Descriptive",
      currentSession: 1,
      characters: [character.id],
      createdAt: new Date().toISOString()
    });

    // Create sample campaign session
    await this.createCampaignSession({
      campaignId: campaign.id,
      sessionNumber: 1,
      title: "The Ancient Chamber",
      narrative: "The stone door grinds open, revealing a vast chamber bathed in an eerie blue light. Ancient pillars stretch upward to a ceiling lost in shadow, and at the center of the room sits a stone altar.\n\nAs Thorne steps forward, the dust of centuries swirls around his boots. The air feels heavy with magic and danger. The runes etched into the altar begin to glow with increasing intensity.\n\n\"I've seen this before,\" whispers Elyndra, the elven mage in your party. \"This is a binding circle. Something powerful was imprisoned here.\"\n\nA low rumble shakes the chamber, and small stones begin to fall from the ceiling. Whatever was bound here seems to be awakening.",
      choices: [
        {
          action: "Inspect the altar more closely",
          description: "Make an Investigation check to learn more about the altar and its purpose.",
          icon: "search"
        },
        {
          action: "Cast Detect Magic",
          description: "Identify magical auras and their schools of magic within 30 feet.",
          icon: "hand-sparkles"
        },
        {
          action: "Retreat back to the hallway",
          description: "Move away from potential danger to reassess the situation.",
          icon: "running"
        },
        {
          action: "Ready your weapon",
          description: "Prepare for potential combat as the binding weakens.",
          icon: "sword"
        }
      ],
      createdAt: new Date().toISOString()
    });

    // Create sample dice rolls
    await this.createDiceRoll({
      userId: user.id,
      characterId: character.id,
      diceType: "d20",
      result: 20,
      modifier: 0,
      purpose: "Attack Roll",
      createdAt: new Date().toISOString()
    });

    await this.createDiceRoll({
      userId: user.id,
      characterId: character.id,
      diceType: "d8",
      result: 6,
      modifier: 3,
      purpose: "Damage",
      createdAt: new Date().toISOString()
    });
  }
}

export class DatabaseStorage implements IStorage {
  db: any;

  constructor() {
    this.db = db;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }

  async updateUserLastLogin(userId: number): Promise<void> {
    await db
      .update(users)
      .set({ lastLogin: new Date().toISOString() })
      .where(eq(users.id, userId));
  }

  async createUser(userData: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values({
      ...userData,
      createdAt: new Date().toISOString()
    }).returning();
    return user;
  }

  // Get all adventure completions for a user
  async getAdventureCompletions(userId: number) {
    return db.select().from(adventureCompletions).where(eq(adventureCompletions.userId, userId));
  }

  // User Session operations  
  async createUserSession(session: InsertUserSession): Promise<UserSession> {
    const [userSession] = await db.insert(userSessions).values(session).returning();
    return userSession;
  }

  async getUserSession(token: string): Promise<UserSession | undefined> {
    const [session] = await db.select().from(userSessions).where(eq(userSessions.sessionToken, token));
    return session;
  }

  async deleteUserSession(token: string): Promise<boolean> {
    const result = await db.delete(userSessions).where(eq(userSessions.sessionToken, token));
    return result.rowCount > 0;
  }

  async deleteUserSessionsForUser(userId: number): Promise<boolean> {
    const result = await db.delete(userSessions).where(eq(userSessions.userId, userId));
    return result.rowCount > 0;
  }

  // Character operations
  async getAllCharacters(): Promise<Character[]> {
    return await db.select().from(characters).orderBy(desc(characters.createdAt));
  }

  async getCharacter(id: number): Promise<Character | undefined> {
    const [character] = await db.select().from(characters).where(eq(characters.id, id));
    return character;
  }

  async createCharacter(character: InsertCharacter): Promise<Character> {
    const [newCharacter] = await db.insert(characters).values(character).returning();
    return newCharacter;
  }

  async updateCharacter(id: number, character: Partial<Character>): Promise<Character | undefined> {
    const [updatedCharacter] = await db
      .update(characters)
      .set({ ...character, updatedAt: new Date().toISOString() })
      .where(eq(characters.id, id))
      .returning();
    return updatedCharacter;
  }

  async deleteCharacter(id: number): Promise<boolean> {
    const result = await db.delete(characters).where(eq(characters.id, id));
    return result.rowCount > 0;
  }

  // Campaign operations
  async getCampaign(id: number): Promise<Campaign | undefined> {
    const [campaign] = await db.select().from(campaigns).where(eq(campaigns.id, id));
    return campaign;
  }

  async getArchivedCampaigns(): Promise<Campaign[]> {
    return await db.select().from(campaigns)
      .where(eq(campaigns.isArchived, true))
      .orderBy(desc(campaigns.createdAt));
  }

  async createCampaign(campaign: InsertCampaign): Promise<Campaign> {
    const [newCampaign] = await db.insert(campaigns).values(campaign).returning();
    return newCampaign;
  }

  async updateCampaign(id: number, campaign: Partial<Campaign>): Promise<Campaign | undefined> {
    const [updatedCampaign] = await db
      .update(campaigns)
      .set({ ...campaign, updatedAt: new Date().toISOString() })
      .where(eq(campaigns.id, id))
      .returning();
    return updatedCampaign;
  }

  async updateCampaignSession(id: number, sessionNumber: number): Promise<Campaign | undefined> {
    const [updatedCampaign] = await db
      .update(campaigns)
      .set({ currentSession: sessionNumber, updatedAt: new Date().toISOString() })
      .where(eq(campaigns.id, id))
      .returning();
    return updatedCampaign;
  }

  async archiveCampaign(id: number): Promise<Campaign | undefined> {
    const [archivedCampaign] = await db
      .update(campaigns)
      .set({ isArchived: true, updatedAt: new Date().toISOString() })
      .where(eq(campaigns.id, id))
      .returning();
    return archivedCampaign;
  }

  async completeCampaign(id: number): Promise<Campaign | undefined> {
    const [completedCampaign] = await db
      .update(campaigns)
      .set({ isCompleted: true, updatedAt: new Date().toISOString() })
      .where(eq(campaigns.id, id))
      .returning();
    return completedCampaign;
  }

  async deleteCampaign(id: number): Promise<boolean> {
    const result = await db.delete(campaigns).where(eq(campaigns.id, id));
    return result.rowCount > 0;
  }

  // Campaign Session operations
  async getCampaignSession(campaignId: number, sessionNumber: number): Promise<CampaignSession | undefined> {
    const [session] = await db.select().from(campaignSessions)
      .where(and(
        eq(campaignSessions.campaignId, campaignId),
        eq(campaignSessions.sessionNumber, sessionNumber)
      ));
    return session;
  }

  async getCampaignSessions(campaignId: number): Promise<CampaignSession[]> {
    return await db.select().from(campaignSessions)
      .where(eq(campaignSessions.campaignId, campaignId))
      .orderBy(asc(campaignSessions.sessionNumber));
  }

  async createCampaignSession(session: InsertCampaignSession): Promise<CampaignSession> {
    const [newSession] = await db.insert(campaignSessions).values(session).returning();
    return newSession;
  }

  // Dice Roll operations
  async createDiceRoll(diceRoll: InsertDiceRoll): Promise<DiceRoll> {
    const [newRoll] = await db.insert(diceRolls).values(diceRoll).returning();
    return newRoll;
  }

  async getDiceRollHistory(userId: number, limit?: number): Promise<DiceRoll[]> {
    let query = db.select().from(diceRolls)
      .where(eq(diceRolls.userId, userId))
      .orderBy(desc(diceRolls.createdAt));

    if (limit) {
      query = query.limit(limit);
    }

    return await query;
  }

  // Adventure Completion operations
  async createAdventureCompletion(completion: InsertAdventureCompletion): Promise<AdventureCompletion> {
    const [newCompletion] = await db.insert(adventureCompletions).values(completion).returning();
    return newCompletion;
  }

  async getCompletionsForUser(userId: number): Promise<AdventureCompletion[]> {
    return await db.select().from(adventureCompletions).where(eq(adventureCompletions.userId, userId));
  }

  async getCompletionsForCharacter(characterId: number): Promise<AdventureCompletion[]> {
    return await db.select().from(adventureCompletions).where(eq(adventureCompletions.characterId, characterId));
  }

  // XP Management operations
  async awardXPToCharacter(characterId: number, xpAmount: number): Promise<Character | undefined> {
    // First get the character
    const character = await this.getCharacter(characterId);
    if (!character) return undefined;

    // Calculate new XP and level
    const newXP = (character.experiencePoints || 0) + xpAmount;
    const newLevel = this.calculateLevelFromXP(newXP);

    // Update character
    return await this.updateCharacter(characterId, {
      experiencePoints: newXP,
      level: Math.max(character.level, newLevel)
    });
  }

  private calculateLevelFromXP(xp: number): number {
    // D&D 5e XP progression
    const xpThresholds = [0, 300, 900, 2700, 6500, 14000, 23000, 34000, 48000, 64000, 85000, 100000, 120000, 140000, 165000, 195000, 225000, 265000, 305000, 355000];

    for (let i = xpThresholds.length - 1; i >= 0; i--) {
      if (xp >= xpThresholds[i]) {
        return i + 1;
      }
    }
    return 1;
  }

  // Campaign Participant operations
  async getCampaignParticipant(campaignId: number, userId: number): Promise<CampaignParticipant | undefined> {
    const [participant] = await db.select().from(campaignParticipants)
      .where(and(
        eq(campaignParticipants.campaignId, campaignId),
        eq(campaignParticipants.userId, userId)
      ));
    return participant;
  }

  async addCampaignParticipant(participant: InsertCampaignParticipant): Promise<CampaignParticipant> {
    const [newParticipant] = await db.insert(campaignParticipants).values(participant).returning();
    return newParticipant;
  }

  async updateCampaignParticipant(id: number, updates: Partial<CampaignParticipant>): Promise<CampaignParticipant | undefined> {
    const [updatedParticipant] = await db
      .update(campaignParticipants)
      .set(updates)
      .where(eq(campaignParticipants.id, id))
      .returning();
    return updatedParticipant;
  }

  async removeCampaignParticipant(campaignId: number, userId: number): Promise<boolean> {
    const result = await db.delete(campaignParticipants)
      .where(and(
        eq(campaignParticipants.campaignId, campaignId),
        eq(campaignParticipants.userId, userId)
      ));
    return result.rowCount > 0;
  }

  // Turn-based campaign operations
  async getCurrentTurn(campaignId: number): Promise<{ userId: number; startedAt: string } | undefined> {
    // This would typically be stored in a separate turns table
    // For now, return undefined as placeholder
    return undefined;
  }

  async startNextTurn(campaignId: number): Promise<{ userId: number; startedAt: string } | undefined> {
    // Implementation would manage turn order and timing
    return undefined;
  }

  async endCurrentTurn(campaignId: number): Promise<boolean> {
    // Implementation would end the current turn
    return true;
  }

  // Learning Content operations
  async getAllLearningContent(): Promise<LearningContent[]> {
    return await db.select().from(learningContent).orderBy(desc(learningContent.createdAt));
  }

  async getLearningContentByCategory(category: string): Promise<LearningContent[]> {
    return await db.select().from(learningContent)
      .where(eq(learningContent.category, category))
      .orderBy(desc(learningContent.createdAt));
  }

  async getLearningContent(id: number): Promise<LearningContent | undefined> {
    const [content] = await db.select().from(learningContent).where(eq(learningContent.id, id));
    return content;
  }

  async createLearningContent(content: InsertLearningContent): Promise<LearningContent> {
    const [newContent] = await db.insert(learningContent).values(content).returning();
    return newContent;
  }

  async updateLearningContent(id: number, content: Partial<LearningContent>): Promise<LearningContent | undefined> {
    const [updatedContent] = await db
      .update(learningContent)
      .set({ ...content, updatedAt: new Date().toISOString() })
      .where(eq(learningContent.id, id))
      .returning();
    return updatedContent;
  }

  async deleteLearningContent(id: number): Promise<boolean> {
    const result = await db.delete(learningContent).where(eq(learningContent.id, id));
    return result.rowCount > 0;
  }

  // Adventure Template operations
  async getAllAdventureTemplates(): Promise<AdventureTemplate[]> {
    return await db.select().from(adventureTemplates).orderBy(desc(adventureTemplates.createdAt));
  }

  async getPublicAdventureTemplates(): Promise<AdventureTemplate[]> {
    return await db.select().from(adventureTemplates)
      .where(eq(adventureTemplates.isPublic, true))
      .orderBy(desc(adventureTemplates.createdAt));
  }

  async getUserAdventureTemplates(userId: number): Promise<AdventureTemplate[]> {
    return await db.select().from(adventureTemplates)
      .where(eq(adventureTemplates.createdBy, userId))
      .orderBy(desc(adventureTemplates.createdAt));
  }

  async getAdventureTemplate(id: number): Promise<AdventureTemplate | undefined> {
    const [template] = await db.select().from(adventureTemplates).where(eq(adventureTemplates.id, id));
    return template;
  }

  async createAdventureTemplate(template: InsertAdventureTemplate): Promise<AdventureTemplate> {
    const [newTemplate] = await db.insert(adventureTemplates).values(template).returning();
    return newTemplate;
  }

  async updateAdventureTemplate(id: number, template: Partial<AdventureTemplate>): Promise<AdventureTemplate | undefined> {
    const [updatedTemplate] = await db
      .update(adventureTemplates)
      .set({ ...template, updatedAt: new Date().toISOString() })
      .where(eq(adventureTemplates.id, id))
      .returning();
    return updatedTemplate;
  }

  async deleteAdventureTemplate(id: number): Promise<boolean> {
    const result = await db.delete(adventureTemplates).where(eq(adventureTemplates.id, id));
    return result.rowCount > 0;
  }

  // Encounter operations
  async getEncountersByCampaign(campaignId: number): Promise<Encounter[]> {
    return await db.select().from(encounters).where(eq(encounters.campaignId, campaignId));
  }

  async getEncounter(id: number): Promise<Encounter | undefined> {
    const [encounter] = await db.select().from(encounters).where(eq(encounters.id, id));
    return encounter;
  }

  async createEncounter(encounter: InsertEncounter): Promise<Encounter> {
    const [newEncounter] = await db.insert(encounters).values(encounter).returning();
    return newEncounter;
  }

  async updateEncounter(id: number, encounter: Partial<Encounter>): Promise<Encounter | undefined> {
    const [updatedEncounter] = await db
      .update(encounters)
      .set({ ...encounter, updatedAt: new Date().toISOString() })
      .where(eq(encounters.id, id))
      .returning();
    return updatedEncounter;
  }

  async deleteEncounter(id: number): Promise<boolean> {
    const result = await db.delete(encounters).where(eq(encounters.id, id));
    return result.rowCount > 0;
  }

  // Adventure Elements operations
  async getAdventureElementsByType(elementType: string): Promise<AdventureElement[]> {
    return await db.select().from(adventureElements)
      .where(eq(adventureElements.elementType, elementType))
      .orderBy(desc(adventureElements.createdAt));
  }

  async getUserAdventureElements(userId: number): Promise<AdventureElement[]> {
    return await db.select().from(adventureElements)
      .where(eq(adventureElements.createdBy, userId))
      .orderBy(desc(adventureElements.createdAt));
  }

  async getPublicAdventureElements(): Promise<AdventureElement[]> {
    return await db.select().from(adventureElements)
      .where(eq(adventureElements.isPublic, true))
      .orderBy(desc(adventureElements.createdAt));
  }

  async getAdventureElement(id: number): Promise<AdventureElement | undefined> {
    const [element] = await db.select().from(adventureElements).where(eq(adventureElements.id, id));
    return element;
  }

  async createAdventureElement(element: InsertAdventureElement): Promise<AdventureElement> {
    const [newElement] = await db.insert(adventureElements).values(element).returning();
    return newElement;
  }

  async updateAdventureElement(id: number, element: Partial<AdventureElement>): Promise<AdventureElement | undefined> {
    const [updatedElement] = await db
      .update(adventureElements)
      .set({ ...element, updatedAt: new Date().toISOString() })
      .where(eq(adventureElements.id, id))
      .returning();
    return updatedElement;
  }

  async deleteAdventureElement(id: number): Promise<boolean> {
    const result = await db.delete(adventureElements).where(eq(adventureElements.id, id));
    return result.rowCount > 0;
  }

  // User statistics
  async getTotalRegisteredUsers(): Promise<number> {
    const result = await db.select({ count: sql`count(*)` }).from(users);
    return result[0]?.count || 0;
  }

  async getOnlineUsersCount(): Promise<number> {
    // This would typically check active sessions
    // For now return a placeholder
    return 1;
  }

  // Inventory operations
  async getCharacterInventory(characterId: number): Promise<Inventory[]> {
    return await db.select().from(inventory).where(eq(inventory.characterId, characterId));
  }

  async addItemToInventory(item: InsertInventory): Promise<Inventory> {
    const [newItem] = await db.insert(inventory).values(item).returning();
    return newItem;
  }

  async updateInventoryItem(id: number, updates: Partial<Inventory>): Promise<Inventory | undefined> {
    const [updatedItem] = await db
      .update(inventory)
      .set(updates)
      .where(eq(inventory.id, id))
      .returning();
    return updatedItem;
  }

  async removeItemFromInventory(id: number): Promise<boolean> {
    const result = await db.delete(inventory).where(eq(inventory.id, id));
    return result.rowCount > 0;
  }

  // Campaign metadata and rewards
  async updateCampaignMetadata(campaignId: number, metadata: any): Promise<void> {
    await db
      .update(campaigns)
      .set({ metadata: JSON.stringify(metadata), updatedAt: new Date().toISOString() })
      .where(eq(campaigns.id, campaignId));
  }

  async getActiveCampaigns(): Promise<Campaign[]> {
    return await db.select().from(campaigns)
      .where(and(
        eq(campaigns.isCompleted, false),
        eq(campaigns.isArchived, false)
      ))
      .orderBy(desc(campaigns.createdAt));
  }

  // NPCs operations for DM Toolkit
  async getUserNPCs(userId: number): Promise<any[]> {
    const npcs = await this.db
      .select()
      .from(adventureElements)
      .where(
        and(
          eq(adventureElements.createdBy, userId),
          eq(adventureElements.elementType, 'npc')
        )
      );

    return npcs.map(npc => ({
      id: npc.id,
      name: npc.title,
      description: npc.description,
      ...JSON.parse(npc.details || '{}')
    }));
  }

  async createNPC(npcData: any): Promise<any> {
    const details = {
      race: npcData.race || 'Human',
      occupation: npcData.occupation || 'Commoner',
      personality: npcData.personality || '',
      appearance: npcData.appearance || '',
      motivation: npcData.motivation || '',
      backstory: npcData.backstory || '',
      quirks: npcData.quirks || [],
      voice: npcData.voice || '',
      relationships: npcData.relationships || []
    };

    const [npc] = await this.db
      .insert(adventureElements)
      .values({
        elementType: 'npc',
        title: npcData.name,
        description: npcData.description,
        details: JSON.stringify(details),
        isPublic: npcData.isPublic || false,
        createdBy: npcData.createdBy,
        createdAt: new Date().toISOString()
      })
      .returning();

    return {
      id: npc.id,
      title: npc.title,
      description: npc.description,
      details: npc.details
    };
  }

  // Encounters operations
  async getUserEncounters(userId: number): Promise<any[]> {
    const encounters = await this.db
      .select()
      .from(encounters)
      .where(eq(encounters.createdBy, userId));

    return encounters;
  }

  async createEncounter(encounterData: any): Promise<any> {
    const [encounter] = await this.db
      .insert(encounters)
      .values(encounterData)
      .returning();

    return encounter;
  }

  async getAllNpcs(): Promise<Npc[]> {
    return await db.select().from(npcs).orderBy(desc(npcs.createdAt));
  }

  async getCompanionNpcs(userId: number): Promise<Npc[]> {
    return await db.select().from(npcs)
      .where(and(
        eq(npcs.createdBy, userId),
        eq(npcs.isCompanion, true)
      ))
      .orderBy(desc(npcs.createdAt));
  }

  async getNpc(id: number): Promise<Npc | undefined> {
    const [npc] = await db.select().from(npcs).where(eq(npcs.id, id));
    return npc;
  }

  async updateNpc(id: number, npcUpdate: Partial<Npc>): Promise<Npc | undefined> {
    const [updatedNpc] = await db
      .update(npcs)
      .set({ ...npcUpdate, updatedAt: new Date().toISOString() })
      .where(eq(npcs.id, id))
      .returning();
    return updatedNpc;
  }

  async deleteNpc(id: number): Promise<boolean> {
    const result = await db.delete(npcs).where(eq(npcs.id, id));
    return result.rowCount > 0;
  }

  // Campaign NPC operations
  async getCampaignNpcs(campaignId: number): Promise<CampaignNpc[]> {
    return await db.select().from(campaignNpcs).where(eq(campaignNpcs.campaignId, campaignId));
  }

  async getCampaignNpc(campaignId: number, npcId: number): Promise<CampaignNpc | undefined> {
    const [campaignNpc] = await db.select().from(campaignNpcs)
      .where(and(
        eq(campaignNpcs.campaignId, campaignId),
        eq(campaignNpcs.npcId, npcId)
      ));
    return campaignNpc;
  }

  async addNpcToCampaign(campaignNpcData: InsertCampaignNpc): Promise<CampaignNpc> {
    const [campaignNpc] = await db.insert(campaignNpcs).values(campaignNpcData).returning();
    return campaignNpc;
  }

  async updateCampaignNpc(id: number, updates: Partial<CampaignNpc>): Promise<CampaignNpc | undefined> {
    const [updatedCampaignNpc] = await db
      .update(campaignNpcs)
      .set(updates)
      .where(eq(campaignNpcs.id, id))
      .returning();
    return updatedCampaignNpc;
  }

  async removeNpcFromCampaign(campaignId: number, npcId: number): Promise<boolean> {
    const result = await db.delete(campaignNpcs)
      .where(and(
        eq(campaignNpcs.campaignId, campaignId),
        eq(campaignNpcs.npcId, npcId)
      ));
    return result.rowCount > 0;
  }

  // NPC Turn operations
  async getNpcTurn(campaignId: number, npcId: number): Promise<{ action: string; target?: number; details?: any } | undefined> {
    // In a real implementation, this would fetch the last turn action for this NPC
    // For now, return a simple placeholder
    return { action: "wait", details: { reason: "Waiting for the right moment" } };
  }

  async simulateNpcTurn(campaignId: number, npcId: number): Promise<{ action: string; target?: number; details?: any; message: string }> {
    // This would use the NPC's AI persona to determine their next action
    // In a real implementation, this would be much more sophisticated
    const [npc] = await db.select().from(npcs).where(eq(npcs.id, npcId));

    if (!npc) {
      return { 
        action: "error", 
        message: "NPC not found" 
      };
    }

    // Simple behavior based on companion type
    let action: string;
    let details: any = {};
    let message: string;

    if (npc.companionType === "combat") {
      action = "attack";
      details = { 
        ability: npc.combatAbilities?.[0] || "Basic Attack",
        damage: Math.floor(Math.random() * 10) + 1 + Math.floor((npc.strength - 10) / 2)
      };
      message = `${npc.name} uses ${details.ability} for ${details.damage} damage!`;
    } 
    else if (npc.companionType === "support") {
      action = "heal";
      details = { 
        ability: npc.supportAbilities?.[0] || "Healing Touch",
        healing: Math.floor(Math.random() * 8) + 1 + Math.floor((npc.wisdom - 10) / 2)
      };
      message = `${npc.name} uses ${details.ability} to heal for ${details.healing} hit points!`;
    }
    else if (npc.companionType === "utility") {
      action = "utility";
      details = { 
        ability: "Search",
        result: Math.random() > 0.7 ? "success" : "failure"
      };
      message = `${npc.name} ${details.result === "success" ? "successfully searches the area and finds something useful" : "searches but finds nothing of interest"}`;
    }
    else {
      action = "social";
      details = { 
        ability: "Gather Information",
        result: Math.random() > 0.5 ? "success" : "failure"
      };
      message = `${npc.name} ${details.result === "success" ? "successfully gathers some useful information" : "tries to gather information but learns nothing new"}`;
    }

    // Update the NPC's last active timestamp in the campaign
    await db
      .update(campaignNpcs)
      .set({ lastActiveAt: new Date().toISOString() })
      .where(
        and(
          eq(campaignNpcs.campaignId, campaignId),
          eq(campaignNpcs.npcId, npcId)
        )
      );

    return { action, details, message };
  }

  // Campaign Invitation operations
  async createCampaignInvitation(invitation: InsertCampaignInvitation): Promise<CampaignInvitation> {
    // Generate a unique invite code if one isn't provided
    if (!invitation.inviteCode) {
      invitation.inviteCode = Math.random().toString(36).substring(2, 10).toUpperCase();
    }

    const [createdInvitation] = await db.insert(campaignInvitations).values(invitation).returning();
    return createdInvitation;
  }

  async getCampaignInvitations(campaignId: number): Promise<CampaignInvitation[]> {
    return await db.select().from(campaignInvitations)
      .where(eq(campaignInvitations.campaignId, campaignId))
      .orderBy(desc(campaignInvitations.createdAt));
  }

  async getCampaignInvitationByCode(inviteCode: string): Promise<CampaignInvitation | undefined> {
    const [invitation] = await db.select().from(campaignInvitations)
      .where(eq(campaignInvitations.inviteCode, inviteCode));
    return invitation;
  }

  async updateCampaignInvitation(id: number, updates: Partial<CampaignInvitation>): Promise<CampaignInvitation | undefined> {
    const [updatedInvitation] = await db
      .update(campaignInvitations)
      .set(updates)
      .where(eq(campaignInvitations.id, id))
      .returning();
    return updatedInvitation;
  }

  async useInvitation(inviteCode: string): Promise<CampaignInvitation | undefined> {
    // Get the invitation
    const invitation = await this.getCampaignInvitationByCode(inviteCode);

    if (!invitation) {
      return undefined;
    }

    // Check if the invitation is valid
    if (invitation.status !== 'pending') {
      return undefined;
    }

    // Check if the invitation has reached max uses
    if (invitation.maxUses && invitation.useCount >= invitation.maxUses) {
      // Update status to expired
      await this.updateCampaignInvitation(invitation.id, { status: 'expired' });
      return undefined;
    }

    // Update use count and timestamp
    const now = new Date().toISOString();
    const [updatedInvitation] = await db
      .update(campaignInvitations)
      .set({ 
        useCount: (invitation.useCount || 0) + 1,
        usedAt: now,
        // If this was the last use, mark as used
        status: invitation.maxUses && invitation.useCount + 1 >= invitation.maxUses ? 'used' : 'pending'
      })
      .where(eq(campaignInvitations.id, invitation.id))
      .returning();

    return updatedInvitation;
  }

  async deleteCampaignInvitation(id: number): Promise<boolean> {
    const result = await db.delete(campaignInvitations).where(eq(campaignInvitations.id, id));
    return result.rowCount > 0;
  }

  // DM Notes operations
  async createDmNote(note: InsertDmNote): Promise<DmNote> {
    const [createdNote] = await db.insert(dmNotes).values(note).returning();
    return createdNote;
  }

  async getDmNotes(campaignId: number, createdBy: number): Promise<DmNote[]> {
    return await db.select().from(dmNotes)
      .where(and(
        eq(dmNotes.campaignId, campaignId),
        eq(dmNotes.createdBy, createdBy)
      ))
      .orderBy(desc(dmNotes.createdAt));
  }

  async getDmNote(id: number): Promise<DmNote | undefined> {
    const [note] = await db.select().from(dmNotes).where(eq(dmNotes.id, id));
    return note;
  }

  async updateDmNote(id: number, updates: Partial<DmNote>): Promise<DmNote | undefined> {
    const now = new Date().toISOString();
    const [updatedNote] = await db
      .update(dmNotes)
      .set({ 
        ...updates,
        updatedAt: now 
      })
      .where(eq(dmNotes.id, id))
      .returning();
    return updatedNote;
  }

  async deleteDmNote(id: number): Promise<boolean> {
    const result = await db.delete(dmNotes).where(eq(dmNotes.id, id));
    return result.rowCount > 0;
  }

  // Magic Items - Adventure Elements functionality
  async getUserMagicItems(userId: number) {
    return await this.db
      .select()
      .from(adventureElements)
      .where(and(
        eq(adventureElements.elementType, 'magic_item'),
        eq(adventureElements.createdBy, userId)
      ));
  }

  // Locations functionality
  async getUserLocations(userId: number) {
    try {
      const locations = await this.db
        .select()
        .from(adventureElements)
        .where(
          and(
            eq(adventureElements.elementType, "location"),
            eq(adventureElements.createdBy, userId)
          )
        )
        .orderBy(desc(adventureElements.createdAt));

      return locations.map(location => {
        let parsedDetails = {};
        try {
          parsedDetails = typeof location.details === 'string' 
            ? JSON.parse(location.details) 
            : location.details || {};
        } catch (parseError) {
          console.error('Error parsing location details:', parseError);
          parsedDetails = {};
        }

        return {
          id: location.id.toString(),
          name: location.title,
          type: parsedDetails.type || 'city',
          description: location.description,
          inhabitants: parsedDetails.inhabitants || '',
          dangers: parsedDetails.dangers || '',
          treasures: parsedDetails.treasures || '',
          secrets: parsedDetails.secrets || '',
          atmosphere: parsedDetails.atmosphere || '',
          difficulty: parsedDetails.difficulty || 'easy',
          connections: parsedDetails.connections || [],
          createdAt: location.createdAt
        };
      });
    } catch (error) {
      console.error('Error fetching user locations:', error);
      throw error;
    }
  }

  async createLocation(locationData: any) {
    const details = {
      type: locationData.type || 'city',
      inhabitants: locationData.inhabitants || '',
      dangers: locationData.dangers || '',
      treasures: locationData.treasures || '',
      connections: locationData.connections || [],
      secrets: locationData.secrets || '',
      atmosphere: locationData.atmosphere || '',
      difficulty: locationData.difficulty || 'easy'
    };

    const [location] = await this.db
      .insert(adventureElements)
      .values({
        elementType: 'location',
        title: locationData.name,
        description: locationData.description,
        details: JSON.stringify(details),
        isPublic: locationData.isPublic || false,
        createdBy: locationData.createdBy,
        createdAt: locationData.createdAt || new Date().toISOString()
      })
      .returning();

    return {
      id: location.id.toString(),
      name: location.title,
      type: details.type,
      description: location.description,
      inhabitants: details.inhabitants,
      dangers: details.dangers,
      treasures: details.treasures,
      connections: details.connections,
      secrets: details.secrets,
      atmosphere: details.atmosphere,
      difficulty: details.difficulty,
      createdAt: location.createdAt
    };
  }

  async updateLocation(locationId: number, userId: number, locationData: any) {
    const details = {
      type: locationData.type,
      inhabitants: locationData.inhabitants,
      dangers: locationData.dangers,
      treasures: locationData.treasures,
      connections: locationData.connections,
      secrets: locationData.secrets,
      atmosphere: locationData.atmosphere,
      difficulty: locationData.difficulty
    };

    const [location] = await this.db
      .update(adventureElements)
      .set({
        title: locationData.name,
        description: locationData.description,
        details: JSON.stringify(details),
        updatedAt: new Date().toISOString()
      })
      .where(and(
        eq(adventureElements.id, locationId),
        eq(adventureElements.createdBy, userId),
        eq(adventureElements.elementType, 'location')
      ))
      .returning();

    if (!location) {
      throw new Error('Location not found or unauthorized');
    }

    return {
      id: location.id.toString(),
      name: location.title,
      type: details.type,
      description: location.description,
      inhabitants: details.inhabitants,
      dangers: details.dangers,
      treasures: details.treasures,
      connections: details.connections,
      secrets: details.secrets,
      atmosphere: details.atmosphere,
      difficulty: details.difficulty
    };
  }

  async deleteLocation(locationId: number, userId: number) {
    await this.db
      .delete(adventureElements)
      .where(
        and(
          eq(adventureElements.id, locationId),
          eq(adventureElements.createdBy, userId),
          eq(adventureElements.elementType, 'location')
        )
      );
  }

  // Magic Items operations
  async getUserMagicItems(userId: number): Promise<any[]> {
    const items = await this.db
      .select()
      .from(adventureElements)
      .where(
        and(
          eq(adventureElements.createdBy, userId),
          eq(adventureElements.elementType, 'magic_item')
        )
      )
      .orderBy(desc(adventureElements.createdAt));

    return items.map(item => {
      let parsedDetails = {};
      try {
        parsedDetails = typeof item.details === 'string' 
          ? JSON.parse(item.details) 
          : item.details || {};
      } catch (parseError) {
        console.error('Error parsing item details:', parseError);
        parsedDetails = {};
      }

      return {
        id: item.id.toString(),
        name: item.title,
        description: item.description,
        ...parsedDetails,
        createdAt: item.createdAt
      };
    });
  }

  async createMagicItem(itemData: any): Promise<any> {
    const details = {
      type: itemData.type || 'wondrous',
      rarity: itemData.rarity || 'uncommon',
      properties: itemData.properties || [],
      attunement: itemData.attunement || false,
      charges: itemData.charges,
      value: itemData.value || 0,
      weight: itemData.weight || 0,
      mechanics: itemData.mechanics || '',
      lore: itemData.lore || ''
    };

    const [item] = await this.db
      .insert(adventureElements)
      .values({
        elementType: 'magic_item',
        title: itemData.name,
        description: itemData.description,
        details: JSON.stringify(details),
        isPublic: itemData.isPublic || false,
        createdBy: itemData.createdBy,
        createdAt: new Date().toISOString()
      })
      .returning();

    return {
      id: item.id.toString(),
      name: item.title,
      description: item.description,
      type: details.type,
      rarity: details.rarity,
      properties: details.properties,
      attunement: details.attunement,
      charges: details.charges,
      value: details.value,
      weight: details.weight,
      mechanics: details.mechanics,
      lore: details.lore,
      createdAt: item.createdAt
    };
  }

  async updateMagicItem(itemId: number, userId: number, itemData: any): Promise<any> {
    const details = {
      type: itemData.type,
      rarity: itemData.rarity,
      properties: itemData.properties,
      attunement: itemData.attunement,
      charges: itemData.charges,
      value: itemData.value,
      weight: itemData.weight,
      mechanics: itemData.mechanics,
      lore: itemData.lore
    };

    const [updatedItem] = await this.db
      .update(adventureElements)
      .set({
        title: itemData.name,
        description: itemData.description,
        details: JSON.stringify(details),
        updatedAt: new Date().toISOString()
      })
      .where(
        and(
          eq(adventureElements.id, itemId),
          eq(adventureElements.createdBy, userId),
          eq(adventureElements.elementType, 'magic_item')
        )
      )
      .returning();

    return {
      id: updatedItem.id,
      title: updatedItem.title,
      description: updatedItem.description,
      details: updatedItem.details
    };
  }

  async deleteMagicItem(itemId: number, userId: number): Promise<void> {
    await this.db
      .delete(adventureElements)
      .where(
        and(
          eq(adventureElements.id, itemId),
          eq(adventureElements.createdBy, userId),
          eq(adventureElements.elementType, 'magic_item')
        )
      );
  }

  // Monsters operations
  async getUserMonsters(userId: number): Promise<any[]> {
    const monsters = await this.db
      .select()
      .from(adventureElements)
      .where(
        and(
          eq(adventureElements.createdBy, userId),
          eq(adventureElements.elementType, 'monster')
        )
      );

    return monsters.map(monster => ({
      id: monster.id,
      name: monster.title,
      description: monster.description,
      ...JSON.parse(monster.details || '{}')
    }));
  }

  async createMonster(monsterData: any): Promise<any> {
    const details = {
      type: monsterData.type || 'beast',
      size: monsterData.size || 'medium',
      challengeRating: monsterData.challengeRating || '1',
      armorClass: monsterData.armorClass || 12,
      hitPoints: monsterData.hitPoints || 20,
      speed: monsterData.speed || '30 ft',
      stats: monsterData.stats || {
        strength: 10, dexterity: 10, constitution: 10,
        intelligence: 10, wisdom: 10, charisma: 10
      },
      skills: monsterData.skills || [],
      resistances: monsterData.resistances || [],
      immunities: monsterData.immunities || [],
      senses: monsterData.senses || [],
      languages: monsterData.languages || [],
      abilities: monsterData.abilities || [],
      actions: monsterData.actions || [],
      environment: monsterData.environment || [],
      lore: monsterData.lore || ''
    };

    const [monster] = await this.db
      .insert(adventureElements)
      .values({
        elementType: 'monster',
        title: monsterData.name,
        description: monsterData.description,
        details: JSON.stringify(details),
        isPublic: monsterData.isPublic || false,
        createdBy: monsterData.createdBy,
      })
      .returning();

    return {
      id: monster.id,
      title: monster.title,
      description: monster.description,
      details: monster.details
    };
  }

  async updateMonster(monsterId: number, userId: number, monsterData: any): Promise<any> {
    const details = {
      type: monsterData.type,
      size: monsterData.size,
      challengeRating: monsterData.challengeRating,
      armorClass: monsterData.armorClass,
      hitPoints: monsterData.hitPoints,
      speed: monsterData.speed,
      stats: monsterData.stats,
      skills: monsterData.skills,
      resistances: monsterData.resistances,
      immunities: monsterData.immunities,
      senses: monsterData.senses,
      languages: monsterData.languages,
      abilities: monsterData.abilities,
      actions: monsterData.actions,
      environment: monsterData.environment,
      lore: monsterData.lore
    };

    const [updatedMonster] = await this.db
      .update(adventureElements)
      .set({
        title: monsterData.name,
        description: monsterData.description,
        details: JSON.stringify(details),
        updatedAt: new Date().toISOString()
      })
      .where(
        and(
          eq(adventureElements.id, monsterId),
          eq(adventureElements.createdBy, userId),
          eq(adventureElements.elementType, 'monster')
        )
      )
      .returning();

    return {
      id: updatedMonster.id,
      title: updatedMonster.title,
      description: updatedMonster.description,
      details: updatedMonster.details
    };
  }

  async deleteMonster(monsterId: number, userId: number): Promise<void> {
    await this.db
      .delete(adventureElements)
      .where(
        and(
          eq(adventureElements.id, monsterId),
          eq(adventureElements.createdBy, userId),
          eq(adventureElements.elementType, 'monster')
        )
      );
  }

  // Quests operations
  async getUserQuests(userId: number) {
    try {
      const quests = await this.db
        .select()
        .from(adventureElements)
        .where(
          and(
            eq(adventureElements.createdBy, userId),
            eq(adventureElements.elementType, 'quest')
          )
        );

      return quests.map(quest => {
        let details = {};
        try {
          if (typeof quest.details === 'string') {
            details = JSON.parse(quest.details || '{}');
          } else if (quest.details && typeof quest.details === 'object') {
            details = quest.details;
          }
        } catch (parseError) {
          console.warn(`Failed to parse quest details for quest ${quest.id}:`, parseError);
          details = {};
        }

        return {
          ...quest,
          details
        };
      });
    } catch (error) {
      console.error('Error fetching user quests:', error);
      throw new Error('Failed to fetch quests from database');
    }
  }

  async createQuest(questData: any) {
    const { title, description, ...details } = questData;

    try {
      const [quest] = await this.db
        .insert(adventureElements)
        .values({
          elementType: 'quest',
          title: title || 'Untitled Quest',
          description: description || '',
          details: JSON.stringify(details),
          isPublic: questData.isPublic || false,
          createdBy: questData.createdBy,
          createdAt: new Date().toISOString()
        })
        .returning();

      return {
        ...quest,
        details: typeof quest.details === 'string' 
          ? JSON.parse(quest.details) 
          : quest.details
      };
    } catch (error) {
      console.error('Error creating quest:', error);
      throw new Error('Failed to create quest in database');
    }
  }

  async updateQuest(questId: number, userId: number, questData: any): Promise<any> {
    const details = {
      type: questData.type,
      objectives: questData.objectives,
      rewards: questData.rewards,
      difficulty: questData.difficulty,
      status: questData.status,
      location: questData.location,
      npcGiver: questData.npcGiver,
      timeLimit: questData.timeLimit,
      prerequisites: questData.prerequisites,
      consequences: questData.consequences
    };

    const [updatedQuest] = await this.db
      .update(adventureElements)
      .set({
        title: questData.title,
        description: questData.description,
        details: JSON.stringify(details),
        updatedAt: new Date().toISOString()
      })
      .where(
        and(
          eq(adventureElements.id, questId),
          eq(adventureElements.createdBy, userId),
          eq(adventureElements.elementType, 'quest')
        )
      )
      .returning();

    return {
      id: updatedQuest.id,
      title: updatedQuest.title,
      description: updatedQuest.description,
      details: updatedQuest.details
    };
  }

  async deleteQuest(questId: number, userId: number): Promise<void> {
    await this.db
      .delete(adventureElements)
      .where(
        and(
          eq(adventureElements.id, questId),
          eq(adventureElements.createdBy, userId),
          eq(adventureElements.elementType, 'quest')
        )
      );
  }

  async getUser(id: number): Promise<User | undefined> {
      const [user] = await db.select().from(users).where(eq(users.id, id));
      return user;
  }

  async getAllCampaigns(): Promise<Campaign[]> {
    try {
      const campaigns = await db.select().from(schema.campaigns);
      return campaigns;
    } catch (error) {
      console.error("Error fetching all campaigns:", error);
      throw new Error("Failed to fetch campaigns");
    }
  }

  async getCampaignParticipants(campaignId: number) {
    try {
      const participants = await this.db
        .select({
          id: users.id,
          username: users.username,
          displayName: users.displayName,
          joinedAt: campaignParticipants.joinedAt,
          role: campaignParticipants.role,
          isActive: campaignParticipants.isActive
        })
        .from(campaignParticipants)
        .innerJoin(users, eq(campaignParticipants.userId, users.id))
        .where(eq(campaignParticipants.campaignId, campaignId));

      return participants;
    } catch (error) {
      console.error("Error fetching campaign participants:", error);
      throw new Error("Failed to fetch participants");
    }
  }

  // Initialize sample data for demonstration
  async initializeSampleData(): Promise<void> {
    try {
      // Check if sample data already exists
      const existingUsers = await this.db.select().from(users).limit(1);
      if (existingUsers.length > 0) {
        console.log('Sample data already exists, skipping initialization');
        return;
      }

      // Create sample user
      const [user] = await this.db.insert(users).values({
        username: "demo_user",
        password: "password123"
      }).returning();

      // Create sample character
      const [character] = await this.db.insert(characters).values({
        userId: user.id,
        name: "Thorne Ironfist",
        race: "Dwarf",
        class: "Fighter",
        level: 5,
        background: "Soldier",
        alignment: "Lawful Good",
        strength: 16,
        dexterity: 12,
        constitution: 15,
        intelligence: 10,
        wisdom: 13,
        charisma: 8,
        hitPoints: 45,
        maxHitPoints: 45,
        armorClass: 17,
        skills: ["Athletics", "Perception", "Intimidation", "Survival"],
        equipment: ["Battleaxe", "Chain Mail", "Shield", "Adventurer's Pack"],
        createdAt: new Date().toISOString()
      }).returning();

      // Create sample campaign
      const [campaign] = await this.db.insert(campaigns).values({
        userId: user.id,
        title: "The Forgotten Crypts",
        description: "An adventure into ancient crypts filled with undead and forgotten treasures.",
        difficulty: "Normal - Balanced Challenge",
        narrativeStyle: "Descriptive",
        currentSession: 1,
        characters: [character.id],
        createdAt: new Date().toISOString()
      }).returning();

      // Create sample campaign session
      await this.db.insert(campaignSessions).values({
        campaignId: campaign.id,
        sessionNumber: 1,
        title: "The Ancient Chamber",
        narrative: "The stone door grinds open, revealing a vast chamber bathed in an eerie blue light. Ancient pillars stretch upward to a ceiling lost in shadow, and at the center of the room sits a stone altar.\n\nAs Thorne steps forward, the dust of centuries swirls around his boots. The air feels heavy with magic and danger. The runes etched into the altar begin to glow with increasing intensity.\n\n\"I've seen this before,\" whispers Elyndra, the elven mage in your party. \"This is a binding circle. Something powerful was imprisoned here.\"\n\nA low rumble shakes the chamber, and small stones begin to fall from the ceiling. Whatever was bound here seems to be awakening.",
        choices: JSON.stringify([
          {
            action: "Inspect the altar more closely",
            description: "Make an Investigation check to learn more about the altar and its purpose.",
            icon: "search"
          },
          {
            action: "Cast Detect Magic",
            description: "Identify magical auras and their schools of magic within 30 feet.",
            icon: "hand-sparkles"
          },
          {
            action: "Retreat back to the hallway",
            description: "Move away from potential danger to reassess the situation.",
            icon: "running"
          },
          {
            action: "Ready your weapon",
            description: "Prepare for potential combat as the binding weakens.",
            icon: "sword"
          }
        ]),
        createdAt: new Date().toISOString()
      });

      // Create sample stock NPCs
      await this.db.insert(npcs).values([
        {
          name: "Gareth the Bold",
          race: "Human",
          occupation: "Warrior",
          personality: "Brave and loyal, always ready to protect allies",
          appearance: "Tall and muscular with short brown hair and steel armor",
          motivation: "To prove his worth as a true knight",
          isCompanion: true,
          isStockCompanion: true,
          companionType: "combat",
          aiPersonality: "Protective and honorable",
          combatAbilities: ["Shield Bash", "Sword Strike", "Defensive Stance"],
          level: 3,
          hitPoints: 35,
          maxHitPoints: 35,
          armorClass: 16,
          strength: 16,
          dexterity: 12,
          constitution: 14,
          intelligence: 10,
          wisdom: 12,
          charisma: 13,
          skills: ["Athletics", "Intimidation"],
          equipment: ["Longsword", "Shield", "Chain Mail"],
          isPublic: true,
          createdBy: user.id,
          createdAt: new Date().toISOString()
        },
        {
          name: "Lysa Brightleaf",
          race: "Elf",
          occupation: "Healer",
          personality: "Kind and wise, devoted to helping others",
          appearance: "Graceful elf with long silver hair and flowing robes",
          motivation: "To heal the wounded and preserve life",
          isCompanion: true,
          isStockCompanion: true,
          companionType: "support",
          aiPersonality: "Compassionate and wise",
          supportAbilities: ["Healing Touch", "Cure Disease", "Restoration"],
          level: 3,
          hitPoints: 22,
          maxHitPoints: 22,
          armorClass: 12,
          strength: 8,
          dexterity: 14,
          constitution: 12,
          intelligence: 13,
          wisdom: 16,
          charisma: 15,
          skills: ["Medicine", "Nature"],
          equipment: ["Quarterstaff", "Healer's Kit", "Herbalism Kit"],
          isPublic: true,
          createdBy: user.id,
          createdAt: new Date().toISOString()
        }
      ]);

      console.log('Sample data initialized successfully');
    } catch (error) {
      console.error('Error initializing sample data:', error);
      throw error;
    }
  }

  // Campaign rewards implementation
  async applyCampaignRewards(campaignId: number, rewards: any): Promise<void> {
    try {
      // Fetch campaign participants
      const participants = await this.getCampaignParticipants(campaignId);

      // Loop through participants and apply rewards
      for (const participant of participants) {
        const characterId = participant.characterId;

        // Award XP to character
        if (rewards.xp) {
          await this.awardXPToCharacter(characterId, rewards.xp);
        }

        // Add items to character inventory
        if (rewards.items && rewards.items.length > 0) {
          for (const item of rewards.items) {
            const newItem = {
              characterId: characterId,
              name: item.name,
              description: item.description,
              quantity: item.quantity || 1,
              weight: item.weight || 0,
              value: item.value || 0
            };
            await this.addItemToInventory(newItem);
          }
        }

        // Update character attributes
        if (rewards.attributes) {
          await this.updateCharacter(characterId, rewards.attributes);
        }
      }

      console.log(`Rewards applied to campaign ${campaignId}`);
    } catch (error) {
      console.error("Error applying campaign rewards:", error);
      throw error;
    }
  }
}

// Create and export the storage instance
export const storage: IStorage = new DatabaseStorage();