import { db } from "../db";
import {
  campaigns,
  characters,
  users,
  sessions,
  campaignParticipants,
  invitations,
  notes,
  locations,
  monsters,
  adventureElements,
  npcs,
  encounters,
  quests,
  inventory
} from "@shared/schema";
import { eq, desc } from "drizzle-orm";
import {
  InsertMonster,
  InsertQuest,
  InsertInventory
} from "@shared/schema/types";

export const dmStorage = {
  createMonster: async (data: InsertMonster) => {
    const [monster] = await db.insert(monsters).values(data).returning();
    return monster;
  },
  getAllMonsters: async () => db.select().from(monsters),

  createQuest: async (data: InsertQuest) => {
    const [quest] = await db.insert(quests).values(data).returning();
    return quest;
  },
  getAllQuests: async () => db.select().from(quests),

  createItem: async (data: InsertInventory) => {
    const [item] = await db.insert(inventory).values(data).returning();
    return item;
  },
  getAllItems: async () => db.select().from(inventory),

  // User-specific monster functions
  getUserMonsters: async (userId: number) => {
    try {
      const result = await db.select().from(monsters).where(eq(monsters.createdBy, userId));
      return result;
    } catch (error) {
      console.error('Error fetching user monsters:', error);
      return [];
    }
  },

  // User-specific quest functions
  getUserQuests: async (userId: number) => {
    try {
      const result = await db.select().from(quests).where(eq(quests.campaignId, userId));
      return result;
    } catch (error) {
      console.error('Error fetching user quests:', error);
      return [];
    }
  },

  // User-specific magic items functions
  getUserMagicItems: async (userId: number) => {
    try {
      const result = await db.select().from(inventory).where(eq(inventory.characterId, userId));
      return result;
    } catch (error) {
      console.error('Error fetching user magic items:', error);
      return [];
    }
  },

  // Main storage functions
  getCampaign: async (id: number) => {
    const result = await db.select().from(campaigns).where(eq(campaigns.id, id));
    return result[0];
  },

  getCampaignParticipants: async (campaignId: number) => {
    return await db
      .select({
        id: campaignParticipants.id,
        character: characters
      })
      .from(campaignParticipants)
      .leftJoin(characters, eq(campaignParticipants.characterId, characters.id))
      .where(eq(campaignParticipants.campaignId, campaignId));
  },

  getCampaignSessions: async (campaignId: number) => {
    return await db
      .select()
      .from(sessions)
      .where(eq(sessions.campaignId, campaignId))
      .orderBy(desc(sessions.createdAt));
  },

  getCampaignNPCs: async (campaignId: number) => {
    return await dmStorage.getUserNPCs(campaignId);
  },

  // Character functions
  getCharacter: async (id: number) => {
    const result = await db.select().from(characters).where(eq(characters.id, id));
    return result[0];
  },

  // Dice roll functions
  createDiceRoll: async (rollData: any) => {
    console.log("Dice roll recorded:", rollData);
    return { id: Date.now(), ...rollData };
  },

  getDiceRollHistory: async (userId: number, limit: number = 10) => {
    return [];
  },

  getLocations: async (userId: number) => {
    try {
      const result = await db.select().from(locations).where(eq(locations.createdBy, userId));
      return result;
    } catch (error) {
      console.error('Error fetching locations:', error);
      return [];
    }
  },

  createLocation: async (locationData: any) => {
    try {
      const [location] = await db.insert(locations).values({
        name: locationData.name,
        description: locationData.description,
        type: locationData.type,
        size: locationData.size || 'medium',
        population: locationData.population || 0,
        government: locationData.government || 'unknown',
        economy: locationData.economy || 'mixed',
        defenses: locationData.defenses || 'minimal',
        features: JSON.stringify(locationData.features || []),
        npcs: JSON.stringify(locationData.npcs || []),
        quests: JSON.stringify(locationData.quests || []),
        secrets: locationData.secrets || '',
        atmosphere: locationData.atmosphere || '',
        createdBy: locationData.createdBy,
        isPublic: locationData.isPublic || false
      }).returning();
      return location;
    } catch (error) {
      console.error('Error creating location:', error);
      throw error;
    }
  },

  // NPC functions
  getUserNPCs: async (userId: number) => {
    try {
      const result = await db.select().from(npcs).where(eq(npcs.createdBy, userId));
      return result;
    } catch (error) {
      console.error('Error fetching user NPCs:', error);
      return [];
    }
  },

  createNPC: async (npcData: any) => {
    try {
      const [npc] = await db.insert(npcs).values({
        name: npcData.name,
        race: npcData.race,
        occupation: npcData.occupation,
        personality: npcData.personality,
        appearance: npcData.appearance,
        motivation: npcData.motivation,
        isCompanion: npcData.isCompanion || false,
        isStockCompanion: npcData.isStockCompanion || false,
        companionType: npcData.companionType,
        aiPersonality: npcData.aiPersonality,
        combatAbilities: JSON.stringify(npcData.combatAbilities || []),
        supportAbilities: JSON.stringify(npcData.supportAbilities || []),
        decisionMakingRules: JSON.stringify(npcData.decisionMakingRules || {}),
        level: npcData.level || 1,
        hitPoints: npcData.hitPoints,
        maxHitPoints: npcData.maxHitPoints,
        armorClass: npcData.armorClass,
        strength: npcData.strength,
        dexterity: npcData.dexterity,
        constitution: npcData.constitution,
        intelligence: npcData.intelligence,
        wisdom: npcData.wisdom,
        charisma: npcData.charisma,
        skills: npcData.skills || [],
        equipment: npcData.equipment || [],
        portraitUrl: npcData.portraitUrl,
        isPublic: npcData.isPublic || false,
        createdBy: npcData.createdBy
      }).returning();
      return npc;
    } catch (error) {
      console.error('Error creating NPC:', error);
      throw error;
    }
  },

  // Get user's magic items
  async getUserMagicItems(userId: number) {
    try {
      const userItems = await db.query(`
        SELECT ae.* FROM adventure_elements ae 
        WHERE ae.created_by = $1 AND ae.element_type = 'item'
        ORDER BY ae.created_at DESC
      `, [userId]);

      return userItems.rows;
    } catch (error) {
      console.error("Error fetching user magic items:", error);
      throw error;
    }
  },

  // Create monster
  async createMonster(monsterData: any) {
    try {
      const result = await db.query(`
        INSERT INTO monsters (
          name, type, size, challenge_rating, armor_class, hit_points, speed, stats,
          skills, resistances, immunities, senses, languages, abilities, actions,
          description, environment, lore, created_by, is_public
        ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16, $17, $18, $19, $20)
        RETURNING *
      `, [
        monsterData.name,
        monsterData.type,
        monsterData.size,
        monsterData.challengeRating,
        monsterData.armorClass,
        monsterData.hitPoints,
        monsterData.speed,
        monsterData.stats,
        monsterData.skills || [],
        monsterData.resistances || [],
        monsterData.immunities || [],
        monsterData.senses || [],
        monsterData.languages || [],
        monsterData.abilities || [],
        monsterData.actions || [],
        monsterData.description,
        monsterData.environment || [],
        monsterData.lore || '',
        monsterData.createdBy,
        monsterData.isPublic || false
      ]);

      return result.rows[0];
    } catch (error) {
      console.error("Error creating monster:", error);
      throw error;
    }
  },

  // Create quest
  async createQuest(questData: any) {
    try {
      const result = await db.query(`
        INSERT INTO quests (campaign_id, title, description, rewards, status)
        VALUES ($1, $2, $3, $4, $5)
        RETURNING *
      `, [
        questData.campaignId,
        questData.title,
        questData.description,
        JSON.stringify(questData.rewards || {}),
        questData.status || 'available'
      ]);

      return result.rows[0];
    } catch (error) {
      console.error("Error creating quest:", error);
      throw error;
    }
  },

  // Create item
  async createItem(itemData: any) {
    try {
      const result = await db.query(`
        INSERT INTO adventure_elements (element_type, title, description, details, is_public, created_by)
        VALUES ('item', $1, $2, $3, $4, $5)
        RETURNING *
      `, [
        itemData.name || itemData.title,
        itemData.description,
        JSON.stringify(itemData),
        itemData.isPublic || false,
        itemData.createdBy
      ]);

      return result.rows[0];
    } catch (error) {
      console.error("Error creating item:", error);
      throw error;
    }
  },

  // Get user's monsters
  async getUserMonsters(userId: number) {
    try {
      const result = await db.query(`
        SELECT * FROM monsters 
        WHERE created_by = $1 
        ORDER BY created_at DESC
      `, [userId]);

      return result.rows;
    } catch (error) {
      console.error("Error fetching user monsters:", error);
      throw error;
    }
  },

  // Get user's quests
  async getUserQuests(userId: number) {
    try {
      const result = await db.query(`
        SELECT q.* FROM quests q
        JOIN campaigns c ON q.campaign_id = c.id
        WHERE c.user_id = $1
        ORDER BY q.created_at DESC
      `, [userId]);

      return result.rows;
    } catch (error) {
      console.error("Error fetching user quests:", error);
      throw error;
    }
  }
};

// Export storage as the main interface for backwards compatibility
export const storage = {
  dmStorage,
  ...dmStorage
};

// Also export as default for flexibility
export default dmStorage;