
// routes/combat.ts
import express from 'express';
import { db } from '../server/db';
import { combatEncounters, combatEntities } from '../drizzle-schema/combat';
import { eq } from 'drizzle-orm';

const router = express.Router();

router.post("/combat/start", async (req, res) => {
  const { campaignId, entities } = req.body;
  const [encounter] = await db.insert(combatEncounters).values({ campaignId }).returning();
  await Promise.all(entities.map((e: any) =>
    db.insert(combatEntities).values({ ...e, encounterId: encounter.id })
  ));
  res.json({ encounterId: encounter.id });
});

router.patch("/combat/next-turn", async (req, res) => {
  const { encounterId } = req.body;
  const [encounter] = await db.select().from(combatEncounters).where(eq(combatEncounters.id, encounterId));
  const updated = await db.update(combatEncounters)
    .set({ currentTurn: encounter.currentTurn + 1 })
    .where(eq(combatEncounters.id, encounterId))
    .returning();
  res.json(updated[0]);
});

router.patch("/combat/apply-damage", async (req, res) => {
  const { entityId, damage } = req.body;
  const [entity] = await db.select().from(combatEntities).where(eq(combatEntities.id, entityId));
  const newHp = Math.max(0, entity.hp - damage);
  const updated = await db.update(combatEntities)
    .set({ hp: newHp })
    .where(eq(combatEntities.id, entityId))
    .returning();
  res.json(updated[0]);
});

router.get("/combat/:id/status", async (req, res) => {
  const id = parseInt(req.params.id);
  const [encounter] = await db.select().from(combatEncounters).where(eq(combatEncounters.id, id));
  const entities = await db.select().from(combatEntities).where(eq(combatEntities.encounterId, id));
  res.json({ encounter, entities });
});

export default router;
