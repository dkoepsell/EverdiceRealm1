
// drizzle-schema/combat.ts
import { pgTable, serial, integer, text, boolean, jsonb, timestamp } from "drizzle-orm/pg-core";

export const combatEncounters = pgTable("combat_encounters", {
  id: serial("id").primaryKey(),
  campaignId: integer("campaign_id").notNull(),
  isActive: boolean("is_active").default(true),
  currentTurn: integer("current_turn").default(0),
  createdAt: timestamp("created_at").defaultNow(),
});

export const combatEntities = pgTable("combat_entities", {
  id: serial("id").primaryKey(),
  encounterId: integer("encounter_id").notNull(),
  name: text("name").notNull(),
  hp: integer("hp").notNull(),
  maxHp: integer("max_hp").notNull(),
  initiative: integer("initiative").notNull(),
  isPlayer: boolean("is_player").notNull(),
  conditions: text("conditions").array().default([]),
});
