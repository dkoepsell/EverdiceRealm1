
// server/lib/promptHelpers.ts
export function getCombatPrompt(context) {
  return `
=== COMBAT MODE ===
Turn: ${context.currentTurn}
Characters: ${context.characters.map(c => c.name + ' (' + c.hp + '/' + c.maxHp + ' HP)').join(', ')}
Enemies: ${context.enemies.map(e => e.name + ' (' + e.hp + '/' + e.maxHp + ' HP)').join(', ')}

Describe current combat scene based on last action: "${context.lastAction}"
Resolve dice results and advance turn if applicable.
`;
}

export function getNarrativePrompt(context) {
  return `
=== STORY MODE ===
Location: ${context.location}
Characters: ${context.characters.map(c => c.name).join(', ')}
Last action: "${context.lastAction}"
Goals: ${context.sessionGoals}

Continue story with emotional tone and narrative detail.
`;
}

export function buildPrompt(context) {
  return context.sceneType === "combat"
    ? getCombatPrompt(context)
    : getNarrativePrompt(context);
}
