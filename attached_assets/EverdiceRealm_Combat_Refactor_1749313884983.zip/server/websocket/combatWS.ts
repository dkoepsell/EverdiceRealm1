
// server/websocket/combatWS.ts
import WebSocket from 'ws';
import { db } from '../db';
import { combatEncounters, combatEntities } from '../../drizzle-schema/combat';
import { eq } from 'drizzle-orm';

export function registerCombatWebSocket(server) {
  const wss = new WebSocket.Server({ server, path: "/ws/combat" });

  wss.on("connection", (ws) => {
    ws.on("message", async (message) => {
      const { type, encounterId } = JSON.parse(message.toString());
      if (type === "subscribe") {
        const [encounter] = await db.select().from(combatEncounters).where(eq(combatEncounters.id, encounterId));
        const entities = await db.select().from(combatEntities).where(eq(combatEntities.encounterId, encounterId));
        ws.send(JSON.stringify({ type: "combatUpdate", data: { encounter, entities } }));
      }
    });
  });
}
