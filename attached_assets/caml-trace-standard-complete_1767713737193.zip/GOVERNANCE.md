# Governance

CAML-Trace is an open standard intended to be independent of any single implementation.

## Decision process

Specification changes are proposed and discussed via GitHub Issues and Pull Requests.

A change is accepted when:
1. The change is documented in a PR modifying the spec and/or schemas
2. The change includes an example update (or a rationale for why no example changes are needed)
3. Maintainers reach consensus in review

## Compatibility policy

- Draft versions (0.x): backward-incompatible changes are allowed but should be minimized and clearly documented.
- 1.0+: backward compatibility is expected; breaking changes require a new major version.

## Reference implementations

Implementations MAY advertise support for CAML-Trace versions (e.g., `traceVersion: 0.1`). No implementation controls the standard.

## Code of conduct

Be constructive. Critique ideas, not people.
