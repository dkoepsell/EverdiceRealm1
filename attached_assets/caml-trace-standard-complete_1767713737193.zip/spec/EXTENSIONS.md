# Extensions (Normative)

CAML-Trace supports extension event kinds via namespaced `kind` strings.

## Rules

1. Extension kinds MUST be namespaced (e.g., `dnd5e.roll`).
2. Extension kinds MUST NOT be required for a valid CAML-Trace document.
3. Extension payloads SHOULD be documented in a public extension document.
4. Extensions SHOULD avoid redefining core kinds; prefer adding new kinds.

## Example: dnd5e.roll

Suggested payload:
- `actorId` (string, optional)
- `rollType` (string, required) — e.g., `attack|save|check|initiative`
- `formula` (string, required) — e.g., `1d20+5`
- `result` (number, required)
- `targetDC` (number, optional)
- `note` (string, optional)

## Example: foundry.combatRound

Suggested payload:
- `round` (integer, required)
- `turn` (integer, optional)
