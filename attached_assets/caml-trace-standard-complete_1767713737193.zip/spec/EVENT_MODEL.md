# Event Model (Normative)

## 1. Event object

Each event in `events[]` is an object with at least:

- `eid` (string): stable event identifier, unique within the trace
- `kind` (string): event kind (see taxonomy)
- `payload` (object): structured data specific to `kind`

Optional fields:
- `ts` (RFC 3339 timestamp string)
- `sessionId` (string)
- `who` (actor identifier)
- `where` (location identifier)
- `note` (human-readable note)
- `meta` (object): implementation metadata (non-normative)

## 2. Append-only ordering

Events are ordered by their position in the `events[]` array.

Implementations SHOULD treat `eid` as stable and monotonic and MUST NOT renumber historical events.
Reordering events changes meaning and is not allowed for an existing trace.

## 3. Payload constraints

CAML-Trace provides a core schema for a set of standard `kind` values.
For unknown `kind` values, the event remains valid if it follows the base event shape,
but consumers may ignore or treat it as opaque.

## 4. Namespaced kinds

Kinds MAY be namespaced using dotted strings:

- `dnd5e.roll`
- `foundry.combatRound`
- `myapp.customEvent`

Namespaced kinds SHOULD document their payload shape in `spec/EXTENSIONS.md` or a linked extension spec.
