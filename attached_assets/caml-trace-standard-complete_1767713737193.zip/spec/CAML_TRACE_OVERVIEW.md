# CAML-Trace Overview (Normative)

## 1. Scope

CAML-Trace defines an **append-only event stream** for recording a tabletop roleplaying playthrough as a traversal through a CAML-Core adventure model.

CAML-Trace is designed to:
- be human-readable (YAML/JSON),
- be machine-validated (JSON Schema),
- remain ruleset-agnostic by default,
- preserve stable identifiers and ordering for archival and reproducibility.

## 2. Non-goals

CAML-Trace does **not** aim to be:
- a combat log capturing every roll and movement,
- a transcript of spoken dialogue,
- a complete simulation trace of micro-actions,
- a replacement for CAML-Core authoring.

Ruleset-specific details MAY be recorded via extensions but MUST NOT be required for a valid trace.

## 3. Conceptual model

- **CAML-Core**: possibility space (what can happen).
- **CAML-Trace**: realized path (what did happen).

A trace references a module (`moduleId`) and records ordered `events[]` that reference CAML-Core IDs (encounters, items, locations, actors) when applicable.

## 4. Minimum compliance

A valid CAML-Trace document MUST include:
- `type: CAMLTrace`
- `id` (trace identifier)
- `moduleId` (CAML-Core module identifier)
- `traceVersion`
- `events[]` with each event containing: `eid`, `kind`, `payload`

Timestamps, sessions, and actor registries are RECOMMENDED but optional.
