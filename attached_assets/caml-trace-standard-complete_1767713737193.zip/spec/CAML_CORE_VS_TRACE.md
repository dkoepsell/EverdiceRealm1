# CAML-Core vs CAML-Trace (Normative)

## CAML-Core

**Purpose:** represent an adventure as a structured possibility space.

CAML-Core contains:
- locations, actors (NPCs/PCs), items, encounters, quests,
- availability conditions (gates),
- possible state transitions (outcomes),
- modular components suitable for remixing and export.

CAML-Core MUST NOT contain runtime playthrough state such as:
- `completed: false`
- per-session counters
- event sequences

## CAML-Trace

**Purpose:** record what happened in a specific playthrough.

CAML-Trace contains:
- ordered semantic events
- actual encounter resolutions
- state mutations and transfers
- references to CAML-Core IDs

CAML-Trace MUST NOT become a tactical micro-log by default:
- dice rolls are optional extensions
- movement/initiative tracking is optional extensions

## Interoperability contract

1. CAML-Core IDs are stable within a module.
2. CAML-Trace events reference those IDs.
3. CAML-Trace is portable between tools: a consumer can summarize and analyze without vendor context.
4. Extensions are namespaced and optional.
