# Event Taxonomy (Normative)

This document defines the core `kind` values and expected payload fields.

## 1. Session lifecycle

### session.started
Payload:
- `sessionId` (string, required)
- `title` (string, optional)

### session.ended
Payload:
- `sessionId` (string, required)

## 2. Encounter lifecycle

### encounter.available (optional)
Indicates an encounter became available given current state.
Payload:
- `encounterId` (string, required)
- `because` (array of strings, optional) — human-readable reasons

### encounter.triggered
Payload:
- `encounterId` (string, required)
- `occursAt` (string, optional) — CAML-Core location id
- `participants` (array of strings, optional) — actor ids

### encounter.resolved
Payload:
- `encounterId` (string, required)
- `resolution` (string, required) — recommended: `success|failure|partial|abandoned`
- `outcomeRefs` (array of strings, optional) — references to CAML-Core outcome ids

## 3. State mutation

### state.set
Payload:
- `path` (string, required) — e.g., `party.location`
- `value` (any JSON value, required)

### state.unset
Payload:
- `path` (string, required)

### state.addTag
Payload:
- `tag` (string, required)
- `scope` (string, optional) — e.g., `campaign|session|party|actor:<id>`

### state.removeTag
Payload:
- `tag` (string, required)
- `scope` (string, optional)

## 4. Inventory / ownership

### item.gained
Payload:
- `itemId` (string, required)
- `by` (string, optional) — actor/party id

### item.lost
Payload:
- `itemId` (string, required)
- `by` (string, optional)

### item.transferred
Payload:
- `itemId` (string, required)
- `from` (string, required)
- `to` (string, required)

## 5. Player intent (optional, recommended)

### actor.declared
Payload:
- `actorId` (string, required)
- `intent` (string, required)
- `targetId` (string, optional)

## 6. Extensions

Ruleset- and platform-specific event kinds MUST be namespaced and MUST NOT be required for compliance.
