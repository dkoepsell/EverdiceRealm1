# Conformance (Normative)

## Minimal conformance

A producer is minimally conformant if it emits CAML-Trace documents that satisfy `schemas/caml-trace.schema.json`.

A consumer is minimally conformant if it can:
- parse CAML-Trace YAML or JSON, and
- process the base event shape (`eid`, `kind`, `payload`), and
- ignore unknown `kind` values safely.

## Core kind conformance

A producer claiming ``core-kind conformance`` SHOULD:
- use the core kinds defined in `spec/EVENT_TAXONOMY.md`
- emit payload fields as specified

A consumer claiming ``core-kind conformance`` SHOULD:
- recognize core kinds
- handle them according to their stated semantics
