# State Path Conventions (Non-normative)

CAML-Trace uses `state.set` and `state.unset` with `path` strings.
This document provides recommended conventions for interoperability.

## Recommended prefixes

- `party.*` — party-level state (`party.location`, `party.reputation.<faction>`)
- `actor.<id>.*` — actor state (`actor.pc.aria.hp`)
- `quest.<id>.*` — quest state (`quest.quest.main.status`)
- `world.*` — world state (`world.timeOfDay`, `world.weather`)

## Notes

- Paths are intentionally unconstrained by the core schema.
- For portability, prefer stable, predictable paths and avoid embedding UI-specific keys.
