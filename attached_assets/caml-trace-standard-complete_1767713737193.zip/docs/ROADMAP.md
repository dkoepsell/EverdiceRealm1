# Roadmap

## 0.2 (Draft)
- Add a recommended canonical state path convention document (non-normative)
- Add a trace-merging guidance doc (for co-GM / offline sync)

## 0.3 (Draft)
- Provide an optional stricter schema profile that validates timestamp format (RFC 3339)
- Provide sample extensions for `dnd5e.*`

## 1.0
- Freeze core kinds and schemas
- Publish conformance tests and a minimal compliance suite
