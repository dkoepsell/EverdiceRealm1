# Design Rationale

CAML-Trace is designed to be:
- portable across tools,
- readable by humans,
- suitable for long-term archival,
- useful for analysis and replay.

## Why semantic events?
A complete combat log is brittle, ruleset-locked, and noisy. CAML-Trace focuses on semantic deltas that matter across play styles:
- what encounters happened,
- how they resolved,
- what state changed.

## Why append-only?
Appending preserves provenance. Editing history undermines reproducibility and makes analytics unreliable. You can always add corrective events rather than rewriting old ones.

## Why namespaced extensions?
Extensions allow VTTs or rulesets to record richer details without fragmenting the core standard. Consumers can ignore unknown namespaces safely.
