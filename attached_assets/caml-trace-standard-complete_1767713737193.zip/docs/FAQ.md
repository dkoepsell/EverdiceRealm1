# FAQ

## Is CAML-Trace required to use CAML?
No. CAML-Trace is optional. CAML-Core can be used without recording traces.

## Does CAML-Trace record dice rolls?
Not by default. Dice rolls are permitted as optional, namespaced extensions (e.g., `dnd5e.roll`).

## Is this a transcript format?
No. CAML-Trace records semantic events (encounter triggered/resolved, state mutations, transfers), not dialogue.

## Can I use CAML-Trace without CAML-Core?
You can, but you lose the main benefit: stable references to module content. A `moduleId` is required for compliance.

## What is the difference between `eid` and `ts`?
- `eid` is a stable identifier within the trace and should not change.
- `ts` is an optional timestamp; ordering is defined by array order, not timestamps.
