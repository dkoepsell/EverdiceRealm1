---
name: Bug report
about: Report a problem with the spec, schema, or examples
title: "[BUG] "
labels: bug
assignees: ""
---

## What happened?
Describe the problem clearly.

## Where?
- [ ] Spec (which file/section?)
- [ ] Schema (which file?)
- [ ] Example (which file?)
- [ ] Tooling (which script?)

## Expected
What should have happened?

## Notes
Any additional context.
