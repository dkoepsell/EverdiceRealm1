---
name: Feature request
about: Propose an addition or change to CAML-Trace
title: "[PROPOSAL] "
labels: enhancement
assignees: ""
---

## Proposal
Describe the change.

## Motivation
Why is this needed? What problem does it solve?

## Backward compatibility
Would this break existing traces? If yes, suggest a migration story.

## Examples
Provide a small example event or trace snippet.
