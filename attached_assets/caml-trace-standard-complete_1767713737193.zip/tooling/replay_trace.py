#!/usr/bin/env python3
"""Reference replay reducer for CAML-Trace.

This tool applies a subset of core event kinds to reconstruct a simple final state.
It is intentionally conservative and treats unknown kinds as no-ops.

State model (reference):
- tags: set[str] (scoped tags as 'scope::tag')
- kv: dict[str, any] (for state.set paths)
- inventory: dict[str, set[str]] mapping owner -> items

This is not a rules engine; it is a demonstrator for portability.
"""

import json
import sys
from pathlib import Path
from typing import Any, Dict, Set

def load_json(p: Path) -> Dict[str, Any]:
    return json.loads(p.read_text(encoding="utf-8"))

def scoped(scope: str, tag: str) -> str:
    s = scope or "campaign"
    return f"{s}::{tag}"

def main():
    if len(sys.argv) != 2:
        print("Usage: replay_trace.py <trace.json>")
        return 2

    trace = load_json(Path(sys.argv[1]))
    tags: Set[str] = set()
    kv: Dict[str, Any] = {}
    inventory: Dict[str, Set[str]] = {}

    for ev in trace.get("events", []):
        kind = ev.get("kind")
        payload = ev.get("payload", {}) or {}

        if kind == "state.set":
            kv[payload["path"]] = payload.get("value")

        elif kind == "state.unset":
            kv.pop(payload["path"], None)

        elif kind == "state.addTag":
            tags.add(scoped(payload.get("scope"), payload["tag"]))

        elif kind == "state.removeTag":
            tags.discard(scoped(payload.get("scope"), payload["tag"]))

        elif kind == "item.gained":
            by = payload.get("by", "party")
            inventory.setdefault(by, set()).add(payload["itemId"])

        elif kind == "item.lost":
            by = payload.get("by", "party")
            inventory.setdefault(by, set()).discard(payload["itemId"])

        elif kind == "item.transferred":
            src = payload["from"]
            dst = payload["to"]
            item = payload["itemId"]
            inventory.setdefault(src, set()).discard(item)
            inventory.setdefault(dst, set()).add(item)

        # Other kinds are no-ops for this reference reducer

    out = {
        "kv": kv,
        "tags": sorted(tags),
        "inventory": {k: sorted(v) for k, v in inventory.items()}
    }
    print(json.dumps(out, indent=2, ensure_ascii=False))
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
