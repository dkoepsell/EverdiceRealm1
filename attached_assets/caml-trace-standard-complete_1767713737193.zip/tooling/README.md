# Tooling

This folder contains reference tools for working with CAML-Trace.

## Tools

- `validate_trace.py` — validate a JSON trace against the JSON Schemas.
- `yaml_to_json.py` — convert YAML trace to JSON.
- `json_to_yaml.py` — convert JSON trace to YAML.
- `replay_trace.py` — apply events to a simple state store to reconstruct final state (reference behavior).

## Install

```bash
pip install -r requirements.txt
```

## Validate

```bash
python validate_trace.py ../examples/minimal-trace.json
```
