#!/usr/bin/env python3
import json
import sys
from pathlib import Path
import yaml

def main():
    if len(sys.argv) != 3:
        print("Usage: yaml_to_json.py <in.yaml> <out.json>")
        return 2

    src = Path(sys.argv[1])
    dst = Path(sys.argv[2])

    data = yaml.safe_load(src.read_text(encoding="utf-8"))
    dst.write_text(json.dumps(data, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print(f"Wrote {dst}")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
