#!/usr/bin/env python3
import json
import sys
from pathlib import Path
from jsonschema import Draft202012Validator, RefResolver

def load_json(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))

def main():
    if len(sys.argv) != 2:
        print("Usage: validate_trace.py <trace.json>")
        return 2

    trace_path = Path(sys.argv[1]).resolve()
    repo_root = Path(__file__).resolve().parents[1]
    schema_dir = repo_root / "schemas"

    schema = load_json(schema_dir / "caml-trace.schema.json")

    # Enable local $ref resolution from schemas directory
    def resolve(ref):
        # jsonschema uses file:// URIs; map to local file if needed
        return ref

    resolver = RefResolver(base_uri=(schema_dir.as_uri() + "/"), referrer=schema)

    instance = load_json(trace_path)

    validator = Draft202012Validator(schema, resolver=resolver)
    errors = sorted(validator.iter_errors(instance), key=lambda e: list(e.path))

    if errors:
        print(f"INVALID: {trace_path}")
        for e in errors:
            loc = ".".join([str(p) for p in e.path]) if e.path else "(root)"
            print(f"- {loc}: {e.message}")
        return 1

    print(f"VALID: {trace_path}")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
