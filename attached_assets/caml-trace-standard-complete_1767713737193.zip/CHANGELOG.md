# Changelog

All notable changes to this specification will be documented in this file.

## [0.1.0] - 2026-01-06
### Added
- Initial draft CAML-Trace specification
- Core event model and taxonomy
- JSON Schema for trace and event objects
- Examples in YAML and JSON
- Reference validator + YAML→JSON converter
- CI workflow to validate examples on pull requests
