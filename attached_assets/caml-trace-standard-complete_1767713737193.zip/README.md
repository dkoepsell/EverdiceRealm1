# CAML-Trace

**CAML-Trace** is an open standard for recording what actually happened during tabletop roleplaying gameplay as a structured, append-only event stream.

CAML-Trace is a companion specification to **CAML-Core**:

- **CAML-Core** describes *what can happen* (adventure as a possibility space).
- **CAML-Trace** records *what did happen* (a traversal through that possibility space).

The intent is portability, long-term archival, analysis, replay, and cross-tool interoperability without locking users into any single VTT, app, or vendor.

## Why CAML-Trace exists

Most tabletop sessions are recorded as prose notes, if at all. VTT logs (when available) are often tactical and ruleset-specific. CAML-Trace focuses on **semantic events** that are:

- **human-readable** (YAML/JSON),
- **machine-actionable** (schemas + tooling),
- **ruleset-agnostic by default**, and
- **grounded in stable CAML-Core IDs**.

## Core guarantees

A CAML-Trace file MUST:

1. Reference a CAML-Core module by `moduleId`
2. Contain an ordered `events[]` stream
3. Provide `eid`, `kind`, and `payload` for each event
4. Preserve append-only ordering (no re-numbering / rewriting historical EIDs)

## Event kinds

CAML-Trace defines a small core taxonomy (see `spec/EVENT_TAXONOMY.md`) including:

- Session lifecycle (`session.started`, `session.ended`)
- Encounter lifecycle (`encounter.triggered`, `encounter.resolved`)
- State mutation (`state.set`, `state.addTag`, …)
- Inventory transfer (`item.transferred`, …)
- Optional extensions via namespacing (e.g., `dnd5e.roll`)

## Repository layout

- `spec/` — normative specification (Markdown)
- `schemas/` — JSON Schemas for validation
- `examples/` — example traces (YAML + JSON)
- `tooling/` — reference validator + conversion tools
- `docs/` — FAQ, design rationale, roadmap
- `.github/` — issue templates + CI validation workflow

## Quick start

### Validate an example trace

```bash
python tooling/validate_trace.py examples/minimal-trace.json
```

### Convert YAML to JSON (canonical ordering preserved)

```bash
python tooling/yaml_to_json.py examples/minimal-trace.yaml examples/minimal-trace.json
```

## Status

Current version: **0.1.0 (Draft)**

This is stable enough for experimentation. Backward-incompatible changes, if any, will be clearly noted in the changelog and release notes.

## License

Specification and schemas are released under **CC BY 4.0** (see `LICENSE`).

## Related

- CAML-Core: https://github.com/dkoepsell/CAML5e
