// Simple test script for character rewards
const campaignId = 5;
const testRewards = {
  xp: 250,
  gold: 75,
  items: [
    {
      id: 1001,
      name: "Healing Potion",
      description: "Restores 2d4+2 hit points when consumed.",
      rarity: "common",
      type: "potion"
    },
    {
      id: 1002,
      name: "Moon-Touched Sword",
      description: "This sword glows with moonlight, creating dim light in a 15-foot radius.",
      rarity: "common",
      type: "weapon",
      slot: "weapon",
      equipped: false
    }
  ]
};

// Function to simulate a POST request
async function testRewardsApi() {
  try {
    const response = await fetch(`/api/campaigns/${campaignId}/character/reward`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(testRewards)
    });
    
    const result = await response.json();
    console.log('Reward API response:', result);
    return result;
  } catch (error) {
    console.error('Error testing rewards API:', error);
    return null;
  }
}

// Test button in UI
document.addEventListener('DOMContentLoaded', () => {
  const testButton = document.createElement('button');
  testButton.textContent = 'Test Combat Rewards';
  testButton.style.position = 'fixed';
  testButton.style.bottom = '20px';
  testButton.style.right = '20px';
  testButton.style.zIndex = '9999';
  testButton.style.padding = '10px 15px';
  testButton.style.backgroundColor = '#4CAF50';
  testButton.style.color = 'white';
  testButton.style.border = 'none';
  testButton.style.borderRadius = '5px';
  testButton.style.cursor = 'pointer';
  
  testButton.addEventListener('click', async () => {
    console.log('Testing combat rewards...');
    const result = await testRewardsApi();
    if (result && result.success) {
      alert(`Rewards applied successfully!\nXP: +${testRewards.xp}\nGold: +${testRewards.gold}\nItems: +${testRewards.items.length}`);
    } else {
      alert('Failed to apply rewards. Check console for details.');
    }
  });
  
  document.body.appendChild(testButton);
});