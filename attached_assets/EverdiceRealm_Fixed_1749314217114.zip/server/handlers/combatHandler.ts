import { storage } from '../storage';
import { Request, Response } from 'express';
import OpenAI from 'openai';

// Initialize OpenAI client
const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

/**
 * Roll dice and return result
 * @param diceType Type of dice (e.g., d20, 2d6, etc.)
 * @param modifier Modifier to add to roll
 * @returns Result of the dice roll
 */
export function rollDice(diceType: string, modifier: number = 0): { 
  roll: number;
  total: number;
  formula: string;
  breakdown: string;
} {
  const diceParts = diceType.toLowerCase().match(/(\d+)?d(\d+)/);

  if (!diceParts) {
    throw new Error(`Invalid dice format: ${diceType}`);
  }

  const numDice = parseInt(diceParts[1] || '1');
  const diceValue = parseInt(diceParts[2]);

  const rolls: number[] = [];
  let total = 0;

  for (let i = 0; i < numDice; i++) {
    const roll = Math.floor(Math.random() * diceValue) + 1;
    rolls.push(roll);
    total += roll;
  }

  const finalTotal = total + modifier;
  const modString = modifier !== 0 ? (modifier > 0 ? `+${modifier}` : modifier.toString()) : '';

  return {
    roll: total,
    total: finalTotal,
    formula: `${diceType}${modString}`,
    breakdown: `[${rolls.join(' + ')}]${modString} = ${finalTotal}`
  };
}

/**
 * Calculate ability modifier based on ability score
 * @param score Ability score (e.g., Strength, Dexterity)
 * @returns Calculated modifier
 */
export function getAbilityModifier(score: number): number {
  return Math.floor((score - 10) / 2);
}

/**
 * Handle monster or NPC turn in combat
 */
export async function handleMonsterTurn(req: Request, res: Response) {
  try {
    const { campaignId, sessionId, monsterId } = req.body;

    if (!campaignId || !sessionId || !monsterId) {
      return res.status(400).json({ message: "Missing required parameters" });
    }

    // Get encounter data
    const encounter = await storage.getActiveEncounter(campaignId);
    if (!encounter) {
      return res.status(404).json({ message: "No active encounter found" });
    }

    // Get monster data
    const monster = encounter.monsters.find((m: any) => m.id === monsterId);
    if (!monster) {
      return res.status(404).json({ message: "Monster not found in encounter" });
    }

    // Get potential targets (players in the encounter)
    const participants = await storage.getCampaignParticipants(campaignId);
    const playerTargets = await Promise.all(
      participants.map(async (p) => {
        const character = await storage.getCharacter(p.characterId);
        if (!character) return null;
        return {
          id: p.characterId,
          name: character.name,
          hitPoints: character.hitPoints,
          currentHitPoints: character.currentHitPoints,
          armorClass: character.armorClass,
          level: character.level
        };
      })
    );

    // Filter out null values and characters with 0 HP
    const validTargets = playerTargets.filter(
      target => target !== null && target.currentHitPoints > 0
    );

    if (validTargets.length === 0) {
      // All players are down, combat should end
      return res.status(200).json({
        combatLog: [`${monster.name} has no valid targets remaining!`],
        combatResolved: true,
        outcome: "defeat",
        rewards: {}
      });
    }

    // Determine monster's action
    // This is where D&D monster AI logic happens
    const monsterAction = determineMonsterAction(monster, validTargets);

    // Execute the action and get results
    const actionResult = executeMonsterAction(monster, monsterAction);

    // Update target's health if damage was dealt
    if (actionResult.damage && actionResult.targetId) {
      const target = validTargets.find(t => t.id === actionResult.targetId);
      if (target) {
        // Calculate new hit points
        const newHitPoints = Math.max(0, target.currentHitPoints - actionResult.damage);

        // Update character hit points in database
        await storage.updateCharacterHitPoints(target.id, newHitPoints);

        // Check if target is down
        if (newHitPoints === 0) {
          actionResult.combatLog.push(`${target.name} falls unconscious!`);
        }
      }
    }

    // Check if all players are down
    const updatedParticipants = await storage.getCampaignParticipants(campaignId);
    const allPlayersDown = updatedParticipants.every(async (p) => {
      const character = await storage.getCharacter(p.characterId);
      return !character || character.currentHitPoints <= 0;
    });

    return res.status(200).json({
      combatLog: actionResult.combatLog,
      combatResolved: allPlayersDown,
      outcome: allPlayersDown ? "defeat" : null,
      rewards: {},
      actionResult
    });

  } catch (error) {
    console.error("Error handling monster turn:", error);
    return res.status(500).json({ message: "Failed to process monster turn", error: error.message });
  }
}

/**
 * Determine what action a monster should take
 */
function determineMonsterAction(monster: any, targets: any[]): {
  type: string;
  action: any;
  targetId: number;
} {
  // Choose a random target with weighted preference for low HP targets
  const weightedTargets = targets.map(target => {
    // Lower HP = higher chance to be targeted
    const hpRatio = target.currentHitPoints / target.hitPoints;
    const weight = 1 + (1 - hpRatio) * 2; // Weights from 1 to 3
    return { target, weight };
  });

  // Calculate total weight
  const totalWeight = weightedTargets.reduce((sum, t) => sum + t.weight, 0);

  // Choose target based on weight
  let randomValue = Math.random() * totalWeight;
  let chosenTarget = weightedTargets[0].target;

  for (const { target, weight } of weightedTargets) {
    randomValue -= weight;
    if (randomValue <= 0) {
      chosenTarget = target;
      break;
    }
  }

  // Get available actions for the monster
  const availableActions = monster.actions || [];

  if (availableActions.length === 0) {
    // Fallback basic attack if no actions defined
    return {
      type: 'attack',
      action: {
        name: 'Attack',
        toHit: getAbilityModifier(monster.strength) + 2, // Basic proficiency
        damage: '1d6'
      },
      targetId: chosenTarget.id
    };
  }

  // Determine action based on monster type and situation
  // 70% chance to use a damaging attack, 30% chance for another ability
  const useDamagingAttack = Math.random() < 0.7;

  // Filter for damaging and non-damaging actions
  const damagingActions = availableActions.filter((a: any) => a.damage);
  const utilityActions = availableActions.filter((a: any) => !a.damage);

  let selectedAction;

  if (useDamagingAttack && damagingActions.length > 0) {
    // Choose a random damaging action
    selectedAction = damagingActions[Math.floor(Math.random() * damagingActions.length)];
  } else if (utilityActions.length > 0) {
    // Choose a random utility action
    selectedAction = utilityActions[Math.floor(Math.random() * utilityActions.length)];
  } else {
    // Fallback to any action
    selectedAction = availableActions[Math.floor(Math.random() * availableActions.length)];
  }

  return {
    type: selectedAction.damage ? 'attack' : 'ability',
    action: selectedAction,
    targetId: chosenTarget.id
  };
}

/**
 * Execute a monster's action and determine the results
 */
function executeMonsterAction(monster: any, actionData: any): {
  success: boolean;
  damage?: number;
  targetId?: number;
  combatLog: string[];
} {
  const { type, action, targetId } = actionData;
  const combatLog: string[] = [];

  if (type === 'attack') {
    // Roll attack
    const attackRoll = rollDice('d20');
    const toHit = action.toHit || getAbilityModifier(monster.strength) + 2;
    const attackTotal = attackRoll.total + toHit;

    combatLog.push(`${monster.name} uses ${action.name}!`);
    combatLog.push(`${monster.name} rolls ${attackRoll.total} + ${toHit} = ${attackTotal} to hit.`);

    // Get target's AC
    // This would normally be fetched from the database
    const targetAC = 14; // Default value if not provided

    if (attackTotal >= targetAC) {
      // Hit! Roll damage
      const damageRoll = rollDice(action.damage || '1d6');
      const damageModifier = getAbilityModifier(monster.strength);
      const totalDamage = damageRoll.total + damageModifier;

      combatLog.push(`Hit! ${monster.name} deals ${damageRoll.breakdown} damage.`);

      return {
        success: true,
        damage: totalDamage,
        targetId,
        combatLog
      };
    } else {
      combatLog.push(`Miss! ${monster.name}'s attack fails to connect.`);

      return {
        success: false,
        combatLog
      };
    }
  } else if (type === 'ability') {
    // Handle special abilities
    combatLog.push(`${monster.name} uses ${action.name}!`);
    combatLog.push(action.description || "The ability's effects ripple through the battlefield!");

    // Some abilities might still deal damage or have other effects
    if (action.damage) {
      const damageRoll = rollDice(action.damage);
      combatLog.push(`The ability deals ${damageRoll.breakdown} damage.`);

      return {
        success: true,
        damage: damageRoll.total,
        targetId,
        combatLog
      };
    } else {
      // For non-damaging abilities
      return {
        success: true,
        combatLog
      };
    }
  }

  // Default fallback
  combatLog.push(`${monster.name} hesitates and does nothing.`);
  return {
    success: false,
    combatLog
  };
}

/**
 * Handle player attack action in combat
 */
export async function handlePlayerAttack(req: Request, res: Response) {
  try {
    const { campaignId, sessionId, attackerId, targetId, action } = req.body;

    if (!campaignId || !sessionId || !attackerId || !targetId) {
      return res.status(400).json({ message: "Missing required parameters" });
    }

    // Get character data
    const character = await storage.getCharacter(attackerId);
    if (!character) {
      return res.status(404).json({ message: "Character not found" });
    }

    // Get encounter data
    const encounter = await storage.getActiveEncounter(campaignId);
    if (!encounter) {
      return res.status(404).json({ message: "No active encounter found" });
    }

    // Get target (monster) data
    const monster = encounter.monsters.find((m: any) => m.id === targetId);
    if (!monster) {
      return res.status(404).json({ message: "Target monster not found" });
    }

    const combatLog: string[] = [];
    let success = false;
    let damage = 0;

    // Process different action types
    if (action.type === 'attack') {
      // Standard attack
      const abilityMod = getAbilityModifier(character.strength);
      const proficiencyBonus = Math.floor((character.level - 1) / 4) + 2;

      // Roll attack
      const attackRoll = rollDice('d20');

      // Natural 20 is always a critical hit
      const isCritical = attackRoll.roll === 20;

      // Calculate final attack value
      const attackTotal = attackRoll.total + abilityMod + proficiencyBonus;

      combatLog.push(`${character.name} attacks ${monster.name} with a weapon!`);
      combatLog.push(`Attack roll: ${attackRoll.total} + ${abilityMod} (ability) + ${proficiencyBonus} (proficiency) = ${attackTotal}`);

      // Check if attack hits
      if (isCritical || attackTotal >= monster.armorClass) {
        // Determine weapon damage dice
        const weaponDice = '1d8'; // Default longsword damage

        // Roll damage (double dice on critical hit)
        const damageDice = isCritical ? weaponDice.replace(/(\d+)d(\d+)/, '$1*2d$2') : weaponDice;
        const damageRoll = rollDice(damageDice);

        // Add ability modifier to damage
        const totalDamage = damageRoll.total + abilityMod;

        if (isCritical) {
          combatLog.push(`Critical Hit! ${character.name} deals ${damageRoll.breakdown} damage!`);
        } else {
          combatLog.push(`Hit! ${character.name} deals ${damageRoll.breakdown} damage.`);
        }

        success = true;
        damage = totalDamage;
      } else {
        combatLog.push(`Miss! ${character.name}'s attack fails to hit ${monster.name}.`);
      }
    } else if (action.type === 'spell') {
      // Spell attack
      const spellcastingMod = getAbilityModifier(character.intelligence || character.wisdom || character.charisma);
      const proficiencyBonus = Math.floor((character.level - 1) / 4) + 2;

      combatLog.push(`${character.name} casts ${action.name} at ${monster.name}!`);

      // Determine if it's an attack spell or saving throw spell
      if (action.name === 'Magic Missile') {
        // Magic Missile always hits
        const damageRoll = rollDice('3d4');
        const totalDamage = damageRoll.total + 3; // +1 per missile

        combatLog.push(`Three magical darts strike unerringly! Dealing ${damageRoll.breakdown} + 3 = ${totalDamage} force damage.`);

        success = true;
        damage = totalDamage;
      } else {
        // Generic spell attack
        const spellAttackRoll = rollDice('d20');
        const spellAttackTotal = spellAttackRoll.total + spellcastingMod + proficiencyBonus;

        combatLog.push(`Spell attack roll: ${spellAttackRoll.total} + ${spellcastingMod} (ability) + ${proficiencyBonus} (proficiency) = ${spellAttackTotal}`);

        if (spellAttackTotal >= monster.armorClass) {
          const damageRoll = rollDice('2d8'); // Default damage for generic spells
          const totalDamage = damageRoll.total;

          combatLog.push(`The spell hits! ${character.name} deals ${damageRoll.breakdown} damage.`);

          success = true;
          damage = totalDamage;
        } else {
          combatLog.push(`The spell misses! ${monster.name} avoids the magical effect.`);
        }
      }
    } else if (action.type === 'special') {
      // Special abilities like Second Wind
      if (action.name === 'Second Wind') {
        const healingRoll = rollDice('1d10');
        const totalHealing = healingRoll.total + character.level;

        combatLog.push(`${character.name} uses Second Wind to recover health!`);
        combatLog.push(`${character.name} regains ${healingRoll.total} + ${character.level} = ${totalHealing} hit points.`);

        // Update character hit points
        const newHitPoints = Math.min(character.hitPoints, character.currentHitPoints + totalHealing);
        await storage.updateCharacterHitPoints(character.id, newHitPoints);

        // This doesn't deal damage to the monster, but counts as an action
        success = true;
      }
    }

    // If damage was dealt, update monster's hit points
    if (success && damage > 0) {
      const newMonsterHp = Math.max(0, monster.currentHitPoints - damage);

      // Update monster HP in the encounter
      await storage.updateMonsterHitPoints(campaignId, monster.id, newMonsterHp);

      if (newMonsterHp === 0) {
        combatLog.push(`${monster.name} is defeated!`);
      }
    }

    // Check if combat is over (all monsters defeated)
    const updatedEncounter = await storage.getActiveEncounter(campaignId);
    const allMonstersDefeated = updatedEncounter.monsters.every((m: any) => m.currentHitPoints <= 0);

    // Calculate rewards if all monsters are defeated
    let rewards = {};
    if (allMonstersDefeated) {
      // Calculate XP rewards based on monster Challenge Ratings
      const xpReward = encounter.monsters.reduce((total: number, m: any) => {
        // CR to XP mapping (simplified)
        const crToXp: { [key: string]: number } = {
          "0": 10, "1/8": 25, "1/4": 50, "1/2": 100, "1": 200,
          "2": 450, "3": 700, "4": 1100, "5": 1800
        };

        const xp = crToXp[m.challengeRating?.toString()] || m.challengeRating * 200 || 100;
        return total + xp;
      }, 0);

      rewards = {
        xp: xpReward,
        items: generateLootRewards(encounter)
      };
    }

    return res.status(200).json({
      success,
      combatLog,
      combatResolved: allMonstersDefeated,
      outcome: allMonstersDefeated ? "victory" : null,
      rewards: allMonstersDefeated ? rewards : {}
    });

  } catch (error) {
    console.error("Error handling player attack:", error);
    return res.status(500).json({ message: "Failed to process attack", error: error.message });
  }
}

/**
 * Generate random loot rewards based on encounter difficulty
 */
function generateLootRewards(encounter: any): any[] {
  // This would normally fetch from a loot table in the database
  // For now, we'll create some simple random loot

  const loot: any[] = [];

  // Determine loot quantity based on encounter challenge
  const monsterCRs = encounter.monsters.map((m: any) => m.challengeRating || 1);
  const avgCR = monsterCRs.reduce((sum: number, cr: number) => sum + cr, 0) / monsterCRs.length;

  // Generate gold coins
  const goldAmount = Math.floor((10 + Math.random() * 10) * avgCR);
  loot.push({
    type: 'currency',
    name: 'Gold Coins',
    amount: goldAmount,
    description: `A small pile of ${goldAmount} gold coins.`
  });

  // Random chance for an item based on average CR
  const itemChance = Math.min(0.7, 0.2 + (avgCR * 0.1));

  if (Math.random() < itemChance) {
    // Potential items based on CR
    const itemPools: { [key: string]: any[] } = {
    low: [
      { name: "Potion of Healing", type: "potion", rarity: "common", value: 50, effect: "Heals 2d4+2 HP" },
      { name: "Scroll of Identify", type: "scroll", rarity: "common", value: 60, effect: "Identifies magical items" },
      { name: "Silver Dagger", type: "weapon", rarity: "common", value: 25, damage: "1d4", properties: ["finesse", "light", "thrown"] },
      { name: "Studded Leather Armor", type: "armor", rarity: "common", value: 45, armorClass: 12, properties: ["light"] },
      { name: "Thieves' Tools", type: "tool", rarity: "common", value: 25, effect: "Advantage on lock picking" }
    ],
    medium: [
      { name: "Potion of Greater Healing", type: "potion", rarity: "uncommon", value: 100, effect: "Heals 4d4+4 HP" },
      { name: "Ring of Protection", type: "ring", rarity: "uncommon", value: 350, effect: "+1 to AC and saving throws" },
      { name: "+1 Longsword", type: "weapon", rarity: "uncommon", value: 500, damage: "1d8+1", properties: ["versatile", "magical"] },
      { name: "Cloak of Elvenkind", type: "wondrous", rarity: "uncommon", value: 400, effect: "Advantage on Stealth checks" },
      { name: "Bag of Holding", type: "wondrous", rarity: "uncommon", value: 500, effect: "Can hold up to 500 pounds in extradimensional space" }
    ],
    high: [
      { name: "Staff of Power", type: "staff", rarity: "rare", value: 1000, damage: "1d6+2", properties: ["versatile", "magical"], charges: 20 },
      { name: "Flame Tongue Sword", type: "weapon", rarity: "rare", value: 800, damage: "1d8 + 2d6 fire", properties: ["versatile", "magical"] },
      { name: "Ring of Spell Storing", type: "ring", rarity: "rare", value: 900, effect: "Store up to 5 levels of spells" }
    ]
    };

    let pool;
    if (avgCR < 2) pool = itemPools.low;
    else if (avgCR < 4) pool = itemPools.medium;
    else pool = itemPools.high;

    const randomItem = pool[Math.floor(Math.random() * pool.length)];
    loot.push({
      type: 'item',
      ...randomItem,
      description: `A ${randomItem.rarity} ${randomItem.type}.`
    });
  }

  return loot;
}

/**
 * Uses GPT-4o to generate NPC dialog responses
 */
export async function generateNpcResponse(req: Request, res: Response) {
  try {
    const { campaignId, npcId, playerAction, playerCharacterId } = req.body;

    if (!campaignId || !npcId || !playerAction) {
      return res.status(400).json({ message: "Missing required parameters" });
    }

    // Get NPC data
    const npc = await storage.getNpc(npcId);
    if (!npc) {
      return res.status(404).json({ message: "NPC not found" });
    }

    // Get campaign data for context
    const campaign = await storage.getCampaign(campaignId);
    if (!campaign) {
      return res.status(404).json({ message: "Campaign not found" });
    }

    // Get player character data
    let characterContext = "";
    if (playerCharacterId) {
      const character = await storage.getCharacter(playerCharacterId);
      if (character) {
        characterContext = `Player Character: ${character.name}, a level ${character.level} ${character.race} ${character.class}. `;
      }
    }

    // Build NPC prompt
    const prompt = `
      You are ${npc.name}, a ${npc.race} ${npc.gender} ${npc.occupation || "NPC"} in a Dungeons & Dragons campaign. 

      Your personality: ${npc.personality || "You are friendly but cautious around strangers."}
      Your background: ${npc.background || "You've lived in this area for many years."}
      Your motivations: ${npc.goals || "You want to live peacefully and make a modest living."}

      Campaign context: ${campaign.title}. ${campaign.description || ""}
      ${characterContext}

      The player has just said or done: "${playerAction}"

      Respond in character as ${npc.name} would, using first-person perspective and staying true to your character's personality and motives. Keep your response concise (2-4 sentences) and conversational. Include one small detail about your appearance or mannerisms.

      Response format: Just provide the direct in-character response with no additional commentary.
    `;

    // Ensure we have the OpenAI API key
    if (!process.env.OPENAI_API_KEY) {
      return res.status(500).json({ message: "OpenAI API key not configured" });
    }

    // Send request to OpenAI
    const response = await openai.chat.completions.create({
      model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
      messages: [
        { role: "system", content: "You are a Dungeon Master's assistant for D&D, generating NPC responses." },
        { role: "user", content: prompt }
      ],
      max_tokens: 200,
      temperature: 0.7,
    });

    // Extract the NPC's response
    const npcResponse = response.choices[0].message.content?.trim();

    // Log interaction to campaign history
    await storage.logNpcInteraction(campaignId, npcId, playerCharacterId, playerAction, npcResponse);

    return res.status(200).json({
      npcId,
      npcName: npc.name,
      response: npcResponse,
      // Include some NPC details for UI rendering
      npcDetails: {
        race: npc.race,
        occupation: npc.occupation,
        portraitUrl: npc.portraitUrl
      }
    });

  } catch (error) {
    console.error("Error generating NPC response:", error);
    return res.status(500).json({ message: "Failed to generate NPC response", error: error.message });
  }
}

/**
 * Use GPT-4o to generate ambient descriptions based on location
 */
export async function generateLocationDescription(req: Request, res: Response) {
  try {
    const { campaignId, sessionId, location, time, weather, previousEvents } = req.body;

    if (!location) {
      return res.status(400).json({ message: "Location is required" });
    }

    // Get campaign data for context
    let campaignContext = "";
    if (campaignId) {
      const campaign = await storage.getCampaign(parseInt(campaignId));
      if (campaign) {
        campaignContext = `Campaign: ${campaign.title}. ${campaign.description || ""} Difficulty: ${campaign.difficulty}. Narrative style: ${campaign.narrativeStyle}.`;
      }
    }

    // Build location prompt
    const prompt = `
      Generate a rich, atmospheric description of the following D&D location: "${location}"

      ${campaignContext}
      ${time ? `Time of day: ${time}.` : ""}
      ${weather ? `Weather conditions: ${weather}.` : ""}
      ${previousEvents ? `Recent events: ${previousEvents}.` : ""}

      Create an evocative, sensory description that brings this location to life for the players. Include:
      - Visual details (what they see)
      - Sounds and ambient noise
      - Smells and atmosphere
      - How the location feels (temperature, air quality, overall ambiance)
      - 1-2 notable or interesting interactive elements players might investigate

      Keep your description between 3-5 sentences, focusing on creating a vivid mental image without being overly verbose.
    `;

    // Ensure we have the OpenAI API key
    if (!process.env.OPENAI_API_KEY) {
      return res.status(500).json({ message: "OpenAI API key not configured" });
    }

    // Send request to OpenAI
    const response = await openai.chat.completions.create({
      model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
      messages: [
        { role: "system", content: "You are a Dungeon Master's assistant for D&D, generating vivid location descriptions." },
        { role: "user", content: prompt }
      ],
      max_tokens: 250,
      temperature: 0.7,
    });

    // Extract the location description
    const description = response.choices[0].message.content?.trim();

    return res.status(200).json({
      location,
      description,
      generatedElements: generateLocationElements(location)
    });

  } catch (error) {
    console.error("Error generating location description:", error);
    return res.status(500).json({ message: "Failed to generate location description", error: error.message });
  }
}

/**
 * Generate interactive elements for a location
 */
function generateLocationElements(location: string): any[] {
  // This would normally use a more sophisticated approach, possibly with AI
  // For now, we'll use some predefined templates based on location keywords

  const elements: any[] = [];
  const lowercaseLocation = location.toLowerCase();

  if (lowercaseLocation.includes('tavern') || lowercaseLocation.includes('inn')) {
    elements.push(
      { type: 'object', name: 'Bar Counter', description: 'A long wooden counter with various bottles and mugs.', actions: ['Approach', 'Order drink'] },
      { type: 'npc', name: 'Bartender', description: 'A busy innkeeper serving drinks to patrons.', actions: ['Talk', 'Ask about rumors'] },
      { type: 'ambient', name: 'Hearth', description: 'A warm fireplace crackles in the corner.', actions: ['Sit nearby', 'Examine'] }
    );
  } else if (lowercaseLocation.includes('forest') || lowercaseLocation.includes('woods')) {
    elements.push(
      { type: 'object', name: 'Ancient Tree', description: 'A massive tree with strange markings on its trunk.', actions: ['Examine', 'Climb'] },
      { type: 'ambient', name: 'Rustling Bushes', description: 'Something seems to be moving in the undergrowth.', actions: ['Investigate', 'Ignore'] },
      { type: 'track', name: 'Animal Tracks', description: 'Fresh tracks lead deeper into the forest.', actions: ['Follow', 'Identify'] }
    );
  } else if (lowercaseLocation.includes('dungeon') || lowercaseLocation.includes('ruin') || lowercaseLocation.includes('crypt')) {
    elements.push(
      { type: 'object', name: 'Strange Altar', description: 'An old stone altar with mysterious symbols.', actions: ['Examine', 'Touch symbols'] },
      { type: 'trap', name: 'Suspicious Floor Tiles', description: 'Some floor tiles appear different from the others.', actions: ['Examine', 'Test with tool'] },
      { type: 'ambient', name: 'Eerie Whispers', description: 'Faint whispers seem to emanate from the walls.', actions: ['Listen closely', 'Ignore'] }
    );
  } else if (lowercaseLocation.includes('town') || lowercaseLocation.includes('village') || lowercaseLocation.includes('city')) {
    elements.push(
      { type: 'npc', name: 'Town Crier', description: 'A loud official announcing the day\'s news.', actions: ['Listen', 'Ask questions'] },
      { type: 'object', name: 'Notice Board', description: 'A board with various quests and announcements pinned to it.', actions: ['Read notices', 'Post something'] },
      { type: 'ambient', name: 'Market Stalls', description: 'Various vendors selling goods and produce.', actions: ['Browse goods', 'Haggle'] }
    );
  } else {
    // Generic elements
    elements.push(
      { type: 'object', name: 'Interesting Feature', description: 'Something unusual catches your eye.', actions: ['Examine', 'Interact'] },
      { type: 'ambient', name: 'Environmental Detail', description: 'A notable aspect of your surroundings.', actions: ['Investigate', 'Ignore'] }
    );
  }

  return elements;
}