
import session from 'express-session';
import connectPgSimple from 'connect-pg-simple';
import { pool } from './db';

export function createSessionStore() {
  const PgStore = connectPgSimple(session);
  
  if (process.env.NODE_ENV === 'production') {
    return new PgStore({
      pool,
      tableName: 'session'
    });
  }
  
  // Use memory store for development
  return new session.MemoryStore();
}
