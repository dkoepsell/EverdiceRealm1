import express, { Request, Response } from 'express';
import { storage } from '../storage';
import { 
  handleMonsterTurn, 
  handlePlayerAttack, 
  generateNpcResponse,
  generateLocationDescription
} from '../handlers/combatHandler';

const router = express.Router();

// Combat routes
router.post('/campaigns/:campaignId/combat/monster-turn', handleMonsterTurn);
router.post('/campaigns/:campaignId/combat/attack', handlePlayerAttack);

// NPC interaction routes
router.post('/npc/generate-response', generateNpcResponse);

// Location and environment routes
router.post('/location/generate-description', generateLocationDescription);

// Get active encounter for a campaign
router.get('/campaigns/:campaignId/encounters/active', async (req: Request, res: Response) => {
  try {
    const campaignId = parseInt(req.params.campaignId);

    if (isNaN(campaignId)) {
      return res.status(400).json({ message: "Invalid campaign ID" });
    }

    // This would normally fetch from the database
    // For now, we'll create a sample encounter for demo purposes
    const encounter = {
      id: 1,
      campaignId,
      title: "Forest Ambush",
      description: "As you travel through the dense forest, a group of bandits springs from the undergrowth, weapons drawn!",
      initiativeRolled: false,
      monsters: [
        {
          id: 101,
          name: "Bandit Leader",
          type: "humanoid",
          size: "medium",
          armorClass: 15,
          hitPoints: 65,
          currentHitPoints: 65,
          speed: 30,
          strength: 15,
          dexterity: 16,
          constitution: 14,
          intelligence: 12,
          wisdom: 11,
          charisma: 14,
          challengeRating: 2,
          abilities: ["Sneak Attack", "Parry"],
          actions: [
            {
              name: "Shortsword",
              description: "Melee Weapon Attack",
              toHit: 5,
              damage: "1d6+3"
            },
            {
              name: "Crossbow",
              description: "Ranged Weapon Attack",
              toHit: 5,
              damage: "1d8+3"
            }
          ]
        },
        {
          id: 102,
          name: "Bandit Thug",
          type: "humanoid",
          size: "medium",
          armorClass: 12,
          hitPoints: 32,
          currentHitPoints: 32,
          speed: 30,
          strength: 14,
          dexterity: 12,
          constitution: 12,
          intelligence: 10,
          wisdom: 10,
          charisma: 10,
          challengeRating: 1/2,
          abilities: [],
          actions: [
            {
              name: "Club",
              description: "Melee Weapon Attack",
              toHit: 4,
              damage: "1d4+2"
            }
          ]
        },
        {
          id: 103,
          name: "Bandit Archer",
          type: "humanoid",
          size: "medium",
          armorClass: 13,
          hitPoints: 22,
          currentHitPoints: 22,
          speed: 30,
          strength: 11,
          dexterity: 14,
          constitution: 12,
          intelligence: 10,
          wisdom: 10,
          charisma: 10,
          challengeRating: 1/4,
          abilities: [],
          actions: [
            {
              name: "Shortbow",
              description: "Ranged Weapon Attack",
              toHit: 4,
              damage: "1d6+2"
            },
            {
              name: "Dagger",
              description: "Melee Weapon Attack",
              toHit: 4,
              damage: "1d4+2"
            }
          ]
        }
      ]
    };

    res.status(200).json(encounter);
  } catch (error) {
    console.error("Error fetching active encounter:", error);
    res.status(500).json({ message: "Failed to fetch active encounter" });
  }
});

// Get active participants for a campaign
router.get('/campaigns/:campaignId/participants/active', async (req: Request, res: Response) => {
  try {
    const campaignId = parseInt(req.params.campaignId);

    if (isNaN(campaignId)) {
      return res.status(400).json({ message: "Invalid campaign ID" });
    }

    const participants = await storage.getCampaignParticipants(campaignId);

    // Fetch character data for each participant
    const participantsWithCharacters = await Promise.all(
      participants.map(async (p) => {
        const character = await storage.getCharacter(p.characterId);
        return {
          ...p,
          character: {
            ...character,
            // Add initial currentHitPoints if not already present
            currentHitPoints: character.currentHitPoints ?? character.hitPoints
          }
        };
      })
    );

    res.status(200).json(participantsWithCharacters);
  } catch (error) {
    console.error("Error fetching participants:", error);
    res.status(500).json({ message: "Failed to fetch participants" });
  }
});

// Update initiatives for combat
router.post('/campaigns/:campaignId/encounters/update-initiatives', async (req: Request, res: Response) => {
  try {
    const campaignId = parseInt(req.params.campaignId);
    const { monsters, players } = req.body;

    if (isNaN(campaignId)) {
      return res.status(400).json({ message: "Invalid campaign ID" });
    }

    if (!monsters || !players) {
      return res.status(400).json({ message: "Missing required data" });
    }

    // In a real implementation, this would update the database
    // For the demo, we'll just return success

    res.status(200).json({ 
      success: true,
      message: "Initiatives updated",
      monsters,
      players
    });
  } catch (error) {
    console.error("Error updating initiatives:", error);
    res.status(500).json({ message: "Failed to update initiatives" });
  }
});

// Update monster hit points
router.post('/campaigns/:campaignId/monster/:monsterId/hp', async (req: Request, res: Response) => {
  try {
    const campaignId = parseInt(req.params.campaignId);
    const monsterId = parseInt(req.params.monsterId);
    const { hitPoints } = req.body;

    if (isNaN(campaignId) || isNaN(monsterId)) {
      return res.status(400).json({ message: "Invalid ID" });
    }

    if (typeof hitPoints !== 'number') {
      return res.status(400).json({ message: "Hit points must be a number" });
    }

    // In a real implementation, this would update the database
    // For the demo, we'll just return success

    res.status(200).json({ 
      success: true,
      message: "Monster hit points updated",
      monsterId,
      hitPoints
    });
  } catch (error) {
    console.error("Error updating monster hit points:", error);
    res.status(500).json({ message: "Failed to update monster hit points" });
  }
});

// Route for advancing story with AI assistance
router.post('/story/advance', async (req: Request, res: Response) => {
  try {
    const { 
      campaignId, 
      sessionId, 
      playerAction, 
      location, 
      currentNpcs,
      combatOutcome 
    } = req.body;

    if (!campaignId || !sessionId) {
      return res.status(400).json({ message: "Missing required parameters" });
    }

    // Get campaign data for context
    const campaign = await storage.getCampaign(parseInt(campaignId));
    if (!campaign) {
      return res.status(404).json({ message: "Campaign not found" });
    }

    // Get current session data
    const session = await storage.getCampaignSession(parseInt(sessionId));
    if (!session) {
      return res.status(404).json({ message: "Session not found" });
    }

    // Get the campaign's current story context
    const storyContext = await storage.getCampaignStoryContext(parseInt(campaignId));

    // Generate contextual next story segment based on previous actions and current state
    const nextStorySegment = {
      narrative: generateContextualNarrative({
        playerAction,
        location,
        combatOutcome,
        storyContext,
        previousNarrative: session.narrative
      }),
      choices: generateContextualChoices({
        location,
        storyContext,
        playerAction,
        combatOutcome
      }),
      location: determineNextLocation({
        currentLocation: location || session.location,
        playerAction,
        storyContext
      }),
      npcs: await determineRelevantNPCs({
        campaignId: parseInt(campaignId),
        location: location || session.location,
        storyContext
      })
    };

    // Update story context for future reference
    await storage.updateCampaignStoryContext(parseInt(campaignId), {
      lastAction: playerAction,
      currentLocation: nextStorySegment.location,
      activeNPCs: nextStorySegment.npcs,
      storyPhase: determineStoryPhase(storyContext, playerAction)
    });

    res.status(200).json(nextStorySegment);
  } catch (error) {
    console.error("Error advancing story:", error);
    res.status(500).json({ message: "Failed to advance story" });
  }
});

export default router;
import { Router } from 'express';
import { handleDMResponseStream } from '../lib/openai';

const router = Router();

router.post('/dm/stream', async (req, res) => {
  try {
    res.setHeader('Content-Type', 'text/plain');
    res.setHeader('Cache-Control', 'no-cache');
    res.setHeader('Connection', 'keep-alive');
    res.setHeader('Transfer-Encoding', 'chunked');

    await handleDMResponseStream(
      req.body.lastChoice.action, 
      req.body,
      (chunk: string) => {
        res.write(chunk);
      }
    );

    res.end();
  } catch (error) {
    console.error('Stream error:', error);
    res.status(500).json({ error: 'Failed to stream DM response' });
  }
});

export default router;
