import { Request, Response } from 'express';
import { storage } from '../storage';
import { z } from 'zod';

// Schema for reward validation
const rewardSchema = z.object({
  xp: z.number().min(0),
  gold: z.number().min(0).optional().default(0),
  items: z.array(
    z.object({
      id: z.number(),
      name: z.string(),
      description: z.string(),
      rarity: z.enum(['common', 'uncommon', 'rare', 'very rare', 'legendary']),
      type: z.string(),
      equipped: z.boolean().optional(),
      slot: z.string().optional(),
      attunement: z.boolean().optional(),
      attuned: z.boolean().optional(),
    })
  ).optional().default([]),
});

export function registerCharacterRewardRoutes(app: any) {
  /**
   * Award rewards to a character after combat or quest completion
   */
  app.post('/api/campaigns/:campaignId/character/reward', async (req: Request, res: Response) => {
    try {
      if (!req.user) {
        return res.status(401).json({ message: 'Not authenticated' });
      }

      const { campaignId } = req.params;
      
      // Validate rewards data
      const result = rewardSchema.safeParse(req.body);
      if (!result.success) {
        return res.status(400).json({ message: 'Invalid reward data', errors: result.error.flatten() });
      }
      
      const rewardData = result.data;
      
      // Get campaign participant data
      const participant = await storage.getCampaignParticipant(parseInt(campaignId), req.user.id);
      if (!participant) {
        return res.status(404).json({ message: 'You are not a participant in this campaign' });
      }
      
      // Get the character
      const character = await storage.getCharacter(participant.characterId);
      if (!character) {
        return res.status(404).json({ message: 'Character not found' });
      }
      
      // Calculate new experience and gold
      const currentXP = character.experience || 0;
      const currentGold = character.gold || 0;
      
      const newXP = currentXP + rewardData.xp;
      const newGold = currentGold + rewardData.gold;
      
      // Update character XP and gold
      await storage.updateCharacterXPandGold(character.id, newXP, newGold);
      
      // Process level up if applicable
      let levelUpData = null;
      if (rewardData.xp > 0) {
        const newLevel = calculateLevel(newXP);
        if (newLevel > (character.level || 1)) {
          // Character has leveled up
          await storage.updateCharacterLevel(character.id, newLevel);
          levelUpData = {
            oldLevel: character.level || 1,
            newLevel
          };
        }
      }
      
      // Add items to inventory if any
      if (rewardData.items && rewardData.items.length > 0) {
        // Get current inventory
        const currentInventory = character.inventory || [];
        
        // Add new items
        const updatedInventory = [...currentInventory, ...rewardData.items];
        
        // Update character inventory
        await storage.updateCharacterInventory(character.id, updatedInventory);
      }
      
      // Return updated character data
      return res.status(200).json({ 
        success: true, 
        xpAwarded: rewardData.xp,
        goldAwarded: rewardData.gold,
        itemsAwarded: rewardData.items.length,
        levelUp: levelUpData
      });
    } catch (error) {
      console.error('Error rewarding character:', error);
      return res.status(500).json({ message: 'Failed to process character rewards' });
    }
  });
}

/**
 * Calculate character level based on XP (D&D 5e progression)
 */
function calculateLevel(xp: number): number {
  const xpThresholds = [
    0,      // Level 1
    300,    // Level 2
    900,    // Level 3
    2700,   // Level 4
    6500,   // Level 5
    14000,  // Level 6
    23000,  // Level 7
    34000,  // Level 8
    48000,  // Level 9
    64000,  // Level 10
    85000,  // Level 11
    100000, // Level 12
    120000, // Level 13
    140000, // Level 14
    165000, // Level 15
    195000, // Level 16
    225000, // Level 17
    265000, // Level 18
    305000, // Level 19
    355000  // Level 20
  ];
  
  let level = 1;
  for (let i = 1; i < xpThresholds.length; i++) {
    if (xp >= xpThresholds[i]) {
      level = i + 1;
    } else {
      break;
    }
  }
  
  return level;
}