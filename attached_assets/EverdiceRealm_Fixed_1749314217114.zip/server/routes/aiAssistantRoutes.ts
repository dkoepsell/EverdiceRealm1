import express, { Request, Response } from 'express';
import { requireAuth } from '../auth';
import { storage } from '../storage';
import OpenAI from 'openai';

const router = express.Router();

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY
});

// Generate complete quest outline
router.post('/generate-quest', requireAuth, async (req: Request, res: Response) => {
  try {
    const { campaignContext, questType, questTheme, partyLevel, partySize, sessionGoals } = req.body;

    const prompt = `You are an expert D&D 5e Dungeon Master creating a complete quest outline.

QUEST PARAMETERS:
- Type: ${questType}
- Theme: ${questTheme}
- Party Level: ${partyLevel}
- Party Size: ${partySize}
- Campaign Context: ${campaignContext}
- Session Goals: ${sessionGoals}

Create a comprehensive quest outline that includes:
1. A compelling title and description
2. 3-5 main objectives with optional side objectives
3. 4-6 varied encounters (combat, social, exploration, puzzle)
4. 3-5 unique NPCs with clear motivations
5. 2-4 interesting locations with map features
6. 3-5 quest-specific items and rewards

Ensure the quest is level-appropriate, engaging, and fits the campaign context.

Respond in this exact JSON format:
{
  "id": "quest_${Date.now()}",
  "title": "Quest title",
  "description": "Detailed quest description (2-3 paragraphs)",
  "level_range": "Levels X-Y",
  "estimated_sessions": 3,
  "themes": ["theme1", "theme2"],
  "objectives": [
    {
      "id": "obj_1",
      "title": "Objective title",
      "description": "What players need to do",
      "type": "main",
      "status": "incomplete",
      "xp_reward": 500
    }
  ],
  "encounters": [
    {
      "id": "enc_1",
      "title": "Encounter title",
      "type": "combat",
      "description": "Encounter description",
      "level": ${partyLevel},
      "location": "Location name",
      "rewards": ["reward1", "reward2"]
    }
  ],
  "locations": [
    {
      "id": "loc_1",
      "name": "Location name",
      "description": "Location description",
      "map_features": ["feature1", "feature2"],
      "connections": ["connected_location1"]
    }
  ],
  "npcs": [
    {
      "id": "npc_1",
      "name": "NPC name",
      "role": "quest_giver",
      "description": "NPC description",
      "personality": "Personality traits",
      "motivations": ["motivation1", "motivation2"]
    }
  ],
  "items": [
    {
      "id": "item_1",
      "name": "Item name",
      "type": "weapon",
      "rarity": "uncommon",
      "description": "Item description and properties",
      "properties": ["property1", "property2"]
    }
  ]
}`;

    const completion = await openai.chat.completions.create({
      model: "gpt-3.5-turbo",
      messages: [
        {
          role: "system",
          content: "You are an expert D&D 5e Dungeon Master. Create comprehensive, balanced quest outlines that are engaging and level-appropriate."
        },
        {
          role: "user",
          content: prompt
        }
      ],
      temperature: 0.8,
      max_tokens: 2000
    });

    const response = completion.choices[0]?.message?.content;
    if (!response) {
      throw new Error("Failed to generate quest outline");
    }

    const questOutline = JSON.parse(response);
    res.json(questOutline);

  } catch (error) {
    console.error("Error generating quest outline:", error);
    res.status(500).json({ message: "Failed to generate quest outline" });
  }
});

// This endpoint has been removed - content is now saved through proper dedicated routes

// Generate adventure structure
router.post('/generate-adventure', requireAuth, async (req: Request, res: Response) => {
  try {
    const { campaignContext, partyLevel, partySize, sessionGoals } = req.body;

    const prompt = `Create a structured adventure scenario for a D&D 5e session.

PARAMETERS:
- Party Level: ${partyLevel}
- Party Size: ${partySize}
- Campaign Context: ${campaignContext}
- Session Goals: ${sessionGoals}

Create an adventure with:
- Engaging title and 2-3 paragraph description
- 3-4 key NPCs involved
- 2-3 locations
- 3-4 adventure hooks
- 2-3 potential complications

Respond in JSON format:
{
  "id": "adv_${Date.now()}",
  "type": "adventure",
  "title": "Adventure title",
  "description": "Adventure description",
  "difficulty": "medium",
  "estimatedTime": "2-3 hours",
  "requirements": ["requirement1", "requirement2"],
  "npcsInvolved": ["NPC 1", "NPC 2"],
  "locations": ["Location 1", "Location 2"],
  "hooks": ["Hook 1", "Hook 2"],
  "complications": ["Complication 1", "Complication 2"]
}`;

    const completion = await openai.chat.completions.create({
      model: "gpt-3.5-turbo",
      messages: [
        {
          role: "system",
          content: "You are an expert D&D 5e Dungeon Master creating engaging adventure scenarios."
        },
        {
          role: "user",
          content: prompt
        }
      ],
      temperature: 0.8,
      max_tokens: 1000
    });

    const response = completion.choices[0]?.message?.content;
    if (!response) {
      throw new Error("Failed to generate adventure");
    }

    const adventure = JSON.parse(response);
    res.json(adventure);

  } catch (error) {
    console.error("Error generating adventure:", error);
    res.status(500).json({ message: "Failed to generate adventure" });
  }
});

// Generate combat advice
router.post('/generate-combat-advice', requireAuth, async (req: Request, res: Response) => {
  try {
    const { currentSituation, partyLevel, partySize } = req.body;

    const prompt = `Provide tactical combat advice for a D&D 5e encounter.

SITUATION: ${currentSituation}
PARTY LEVEL: ${partyLevel}
PARTY SIZE: ${partySize}

Provide advice on:
- Initiative management
- Tactical suggestions
- Environmental factors
- Potential outcomes
- NPC behaviors

Respond in JSON format:
{
  "initiative": "Initiative management advice",
  "tacticalAdvice": "Tactical suggestions",
  "environmentalFactors": ["factor1", "factor2"],
  "potentialOutcomes": ["outcome1", "outcome2"],
  "npcBehaviors": {
    "Enemy Type 1": "Behavior description",
    "Enemy Type 2": "Behavior description"
  }
}`;

    const completion = await openai.chat.completions.create({
      model: "gpt-3.5-turbo",
      messages: [
        {
          role: "system",
          content: "You are an expert D&D 5e Dungeon Master providing tactical combat advice."
        },
        {
          role: "user",
          content: prompt
        }
      ],
      temperature: 0.7,
      max_tokens: 800
    });

    const response = completion.choices[0]?.message?.content;
    if (!response) {
      throw new Error("Failed to generate combat advice");
    }

    const advice = JSON.parse(response);
    res.json(advice);

  } catch (error) {
    console.error("Error generating combat advice:", error);
    res.status(500).json({ message: "Failed to generate combat advice" });
  }
});

// Get saved quest content by user
router.get('/saved-content', requireAuth, async (req: Request, res: Response) => {
  try {
    const userId = req.user.id;

    // Get content from proper tables
    const [npcs, adventureElements, adventureTemplates] = await Promise.all([
      storage.getUserNpcs(userId),
      storage.getUserAdventureElements(userId),
      storage.getUserAdventureTemplates(userId)
    ]);

    // Separate adventure elements by type
    const items = adventureElements.filter(element => element.elementType === 'item');
    const locations = adventureElements.filter(element => element.elementType === 'location');
    const monsters = adventureElements.filter(element => element.elementType === 'monster');

    res.json({
      npcs: npcs.filter(npc => !npc.companionType || npc.companionType === null).map(npc => ({
        id: npc.id,
        name: npc.name,
        race: npc.race,
        occupation: npc.occupation,
        personality: npc.personality,
        appearance: npc.appearance
      })),
      items: items.map(item => ({
        id: item.id,
        name: item.title,
        type: item.details?.type || 'wondrous',
        rarity: item.details?.rarity || 'uncommon',
        description: item.description,
        properties: item.details?.properties || []
      })),
      locations: locations.map(location => ({
        id: location.id,
        name: location.title,
        type: location.details?.type || 'landmark',
        description: location.description,
        features: location.details?.features || []
      })),
      monsters: monsters.map(monster => ({
        id: monster.id,
        name: monster.title,
        type: monster.details?.type || 'beast',
        challengeRating: monster.details?.challengeRating || '1',
        description: monster.description,
        hitPoints: monster.details?.hitPoints || 20,
        armorClass: monster.details?.armorClass || 12
      })),
      quests: adventureTemplates.map(template => ({
        id: template.id,
        title: template.title,
        description: template.description,
        difficulty: template.difficultyRange,
        recommendedLevels: template.recommendedLevels,
        structure: template.structure
      }))
    });

  } catch (error) {
    console.error("Error fetching saved content:", error);
    res.status(500).json({ message: "Failed to fetch saved content" });
  }
});

export default router;