
export interface CombatOutcome {
  result: 'win' | 'loss' | 'draw';
  damage: number;
}

export function resolveCombatOutcome(playerTotal: number, enemyTotal: number): CombatOutcome {
  let result: 'win' | 'loss' | 'draw';
  
  if (playerTotal > enemyTotal) {
    result = 'win';
  } else if (playerTotal < enemyTotal) {
    result = 'loss';
  } else {
    result = 'draw';
  }
  
  // Calculate damage modifier based on the difference
  const difference = Math.abs(playerTotal - enemyTotal);
  const damage = Math.max(1, Math.floor(difference / 2));
  
  return {
    result,
    damage
  };
}
