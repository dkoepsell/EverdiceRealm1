
export type CombatEntity = {
  name: string;
  hp: number;
  ac: number;
  initiative: number;
};

export class CombatManager {
  private players: CombatEntity[] = [];
  private enemies: CombatEntity[] = [];
  private round: number = 0;
  private inCombat: boolean = false;

  startCombat(players: CombatEntity[], enemies: CombatEntity[]) {
    this.players = players;
    this.enemies = enemies;
    this.round = 1;
    this.inCombat = true;
    this.sortInitiative();
  }

  private sortInitiative() {
    [...this.players, ...this.enemies].sort((a, b) => b.initiative - a.initiative);
  }

  resolveAttack(attacker: CombatEntity, defender: CombatEntity, roll: number, damage: number): string {
    if (roll >= defender.ac) {
      defender.hp -= damage;
      const status = defender.hp <= 0 ? `${defender.name} has been defeated!` : `${defender.name} has ${defender.hp} HP left.`;
      return `${attacker.name} hits ${defender.name} for ${damage} damage. ${status}`;
    } else {
      return `${attacker.name} misses ${defender.name}.`;
    }
  }

  endCombat(): string {
    this.inCombat = false;
    return "Combat has ended.";
  }
}

export const combatManager = new CombatManager();
