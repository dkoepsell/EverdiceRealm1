import OpenAI from 'openai';

export async function handleDMResponseStream(
  action: string,
  context: DMContext,
  onChunk: (chunk: string) => void
): Promise<void> {
  const openai = new OpenAI({
    apiKey: process.env.OPENAI_API_KEY
  });

  const history = context.sessionHistory?.slice(-3).join("\n") || '';
  const rollSummary = context.lastChoice?.skillCheckResult
    ? `${context.lastChoice.skillCheckResult.success ? "Success" : "Failure"} on a ${context.lastChoice.skillCheckResult.abilityType} check (Roll: ${context.lastChoice.skillCheckResult.roll}, DC: ${context.lastChoice.skillCheckResult.dc})`
    : "No skill check required";

  // Special handling for combat scenarios
  let combatContext = '';
  const combatTriggered = action.toLowerCase().includes("attack") || action.toLowerCase().includes("defend") || action.toLowerCase().includes("cast"); // Example combat triggers
  const narrativeCombatDetected = context.narrative.toLowerCase().includes("attacks") || context.narrative.toLowerCase().includes("defends") || context.narrative.toLowerCase().includes("casts"); // Example narrative triggers
  if (combatTriggered || narrativeCombatDetected) {
    combatContext = `
=== COMBAT DETECTED ===
Combat situation detected. If this is the start of combat:
1. Describe initiative order and positioning
2. Provide combat-specific choices (Attack, Defend, Cast Spell, etc.)
3. Include HP and status tracking in narrative
4. Set requiresDiceRoll to true for combat actions

If combat is already in progress:
1. Resolve the current action based on the dice roll
2. Describe damage, effects, or outcomes
3. Advance to next turn or declare victory/defeat
4. Include remaining HP and conditions
`;
  }

  const prompt = `You are a Dungeon Master continuing a high-fantasy RPG adventure. Return only a JSON object describing vivid consequences of the player's actions, using cinematic storytelling and enforcing continuity with past sessions.
${combatContext}
${storyArcContext}
=== CAMPAIGN CONTEXT ===
Recent session history (max 3 entries):
${history}

Current location: "${context.location}"
Current narrative: "${context.narrative}"
Active characters: ${context.characters || 'A party of adventurers'}

Player action: "${action}"
Result of last dice roll: ${rollSummary}

=== RULES FOR NARRATIVE RESPONSE ===
1. The narrative must show direct consequences of the player's latest action and roll result. Do not skip this.
2. If the roll was a failure, depict failure meaningfully: delay, misinterpretation, detection, confusion, physical stumble, etc.
3. If the roll was a success, narrate success appropriate to the challenge — insight, passage, persuasion, discovery, etc.
4. Always reflect the emotional state of characters and environmental response.
5. Do not invent new actions not tied to the roll or past choices. Use the existing action as your anchor.
6. Integrate atmosphere: weather, light, sound, forest energy, spirits, etc.

=== RESPONSE FORMAT ===
{
  "narrative": "Vivid description of the direct outcome and consequences.",
  "location": "Current or updated location name",
  "choices": [
    {
      "action": "Concise title",
      "description": "Narrative description with clear consequences",
      "requiresDiceRoll": true/false,
      "diceType": "d20",
      "rollDC": 15,
      "abilityType": "strength/dexterity/constitution/intelligence/wisdom/charisma",
      "rollModifier": 3,
      "rollPurpose": "What this check determines"
    }
  ]
}

=== CONTEXT ===
Recent session history:
${history}

Current location: "${context.location}"
Current narrative: "${context.narrative}"
Characters: ${context.characters || 'A party of adventurers'}

Latest player action: "${action}"
Result of that action: ${rollSummary}

=== INSTRUCTIONS ===
1. You must begin by narrating the outcome of the most recent player action and the result of the dice roll.
2. Describe any world or character reactions caused by this outcome.
3. Show consequences and choices resulting from that action.
4. Never skip the player's choice or roll — your response must follow from it directly.
5. Format your response as strict JSON only.

=== RESPONSE FORMAT ===
{
  "narrative": "Vivid 2-3 paragraph description showing the outcome of the last action and its consequences.",
  "location": "Current or updated location name.",
  "choices": [
    {
      "action": "Concise title",
      "description": "Narrative description of what this choice represents",
      "requiresDiceRoll": true/false,
      "diceType": "d20",
      "rollDC": 15,
      "abilityType": "wisdom",
      "rollModifier": 3,
      "rollPurpose": "What the check tests"
    }
  ]
}`;

  const stream = await openai.chat.completions.create({
    model: 'gpt-4o',
    messages: [
      {
        role: 'system',
        content: 'You are a D&D Dungeon Master responding in structured JSON only.'
      },
      {
        role: 'user',
        content: prompt
      }
    ],
    stream: true,
    response_format: { type: "json_object" }
  });

  let fullResponse = '';

  for await (const chunk of stream) {
    const content = chunk.choices[0]?.delta?.content || '';
    if (content) {
      fullResponse += content;
      onChunk(content);
    }
  }

  return fullResponse;
}
// the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

export interface CampaignGenerationRequest {
  theme?: string;
  difficulty?: string;
  narrativeStyle?: string;
  numberOfSessions?: number;
}

export interface EventLog {
  event: string;
  timestamp: Date;
  rollResult?: {
    type: string;
    roll: number;
    dc?: number;
    success: boolean;
  };
}

export interface DMContext {
  sessionHistory: string[];
  location: string;
  narrative: string;
  lastChoice?: {
    action: string;
    skillCheckResult?: {
      abilityType: string;
      roll: number;
      success: boolean;
      dc: number;
    };
  };
  characters?: string;
}

export interface CampaignGenerationResponse {
  title: string;
  description: string;
  difficulty: string;
  narrativeStyle: string;
  startingLocation: string;
  mainNPC: string;
  mainQuest: string;
  sideQuests: string[];
  suggestedLevel: number;
}

export interface DMResponse {
  narrative: string;
  location: string;
  choices: Array<{
    action: string;
    description: string;
    requiresDiceRoll?: boolean;
    diceType?: string;
    rollDC?: number;
    abilityType?: string;
    rollModifier?: number;
    rollPurpose?: string;
  }>;
}

export async function generateCampaign(req: CampaignGenerationRequest): Promise<CampaignGenerationResponse> {
  try {
    const prompt = `
Create a D&D campaign with the following parameters:
${req.theme ? `Theme: ${req.theme}` : 'Theme: Fantasy (create a suitable theme if none specified)'}
${req.difficulty ? `Difficulty: ${req.difficulty}` : 'Difficulty: Normal (balanced challenge)'}
${req.narrativeStyle ? `Narrative Style: ${req.narrativeStyle}` : 'Narrative Style: Descriptive'}
${req.numberOfSessions ? `Expected Number of Sessions: ${req.numberOfSessions}` : 'Expected Number of Sessions: 5'}

Please generate a complete D&D campaign overview in JSON format with these fields:
- title: A catchy title for the campaign
- description: A compelling 3-4 sentence description that outlines the main themes and hooks
- difficulty: The campaign difficulty (Easy, Normal, Hard)
- narrativeStyle: The narrative style (Descriptive, Dramatic, Humorous, etc.)
- startingLocation: Where the adventure begins
- mainNPC: The key non-player character that drives the plot
- mainQuest: The primary objective of the campaign
- sideQuests: An array of 3 side quests that complement the main story
- suggestedLevel: Recommended starting character level (1-10)

Format the response as a valid JSON object without explanation.
`;

    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [{ role: "user", content: prompt }],
      response_format: { type: "json_object" },
      temperature: 0.7,
    });

    const result = JSON.parse(response.choices[0].message.content);
    return result as CampaignGenerationResponse;
  } catch (error) {
    console.error("Error generating campaign with OpenAI:", error);
    throw new Error("Failed to generate campaign. Please try again later.");
  }
}

function isValidDMResponse(obj: any): obj is DMResponse {
  return obj && 
    typeof obj.narrative === "string" &&
    typeof obj.location === "string" &&
    Array.isArray(obj.choices) &&
    obj.choices.every(c => 
      typeof c.action === "string" &&
      typeof c.description === "string" &&
      typeof c.requiresDiceRoll === "boolean" &&
      (!c.requiresDiceRoll || (
        typeof c.diceType === "string" &&
        typeof c.rollDC === "number" &&
        typeof c.abilityType === "string" &&
        typeof c.rollModifier === "number" &&
        typeof c.rollPurpose === "string"
      ))
    );
}

export async function handleDMResponse(action: string, context: DMContext): Promise<DMResponse> {
  const history = context.sessionHistory?.slice(-3).join("\n") || '';
  const rollSummary = context.lastChoice?.skillCheckResult
    ? `${context.lastChoice.skillCheckResult.success ? "Success" : "Failure"} on a ${context.lastChoice.skillCheckResult.abilityType} check (Roll: ${context.lastChoice.skillCheckResult.roll}, DC: ${context.lastChoice.skillCheckResult.dc})`
    : "No skill check required";

  // Special handling for combat scenarios
  let combatContext = '';
  const combatTriggered = action.toLowerCase().includes("attack") || action.toLowerCase().includes("defend") || action.toLowerCase().includes("cast"); // Example combat triggers
  const narrativeCombatDetected = context.narrative.toLowerCase().includes("attacks") || context.narrative.toLowerCase().includes("defends") || context.narrative.toLowerCase().includes("casts"); // Example narrative triggers

  if (combatTriggered || narrativeCombatDetected) {
    combatContext = `
=== COMBAT DETECTED ===
Combat situation detected. If this is the start of combat:
1. Describe initiative order and positioning
2. Provide combat-specific choices (Attack, Defend, Cast Spell, etc.)
3. Include HP and status tracking in narrative
4. Set requiresDiceRoll to true for combat actions

If combat is already in progress:
1. Resolve the current action based on the dice roll
2. Describe damage, effects, or outcomes
3. Advance to next turn or declare victory/defeat
4. Include remaining HP and conditions
`;
  }

  const prompt = `You are a Dungeon Master continuing a high-fantasy RPG adventure. Return only a JSON object describing vivid consequences of the player's actions, using cinematic storytelling and enforcing continuity with past sessions.
${combatContext}
${storyArcContext}
=== CAMPAIGN CONTEXT ===
Recent session history (max 3 entries):
${history}

Current location: "${context.location}"
Current narrative: "${context.narrative}"
Active characters: ${context.characters || 'A party of adventurers'}

Player action: "${action}"
Result of last dice roll: ${rollSummary}

=== RULES FOR NARRATIVE RESPONSE ===
1. The narrative must show direct consequences of the player's latest action and roll result. Do not skip this.
2. If the roll was a failure, depict failure meaningfully: delay, misinterpretation, detection, confusion, physical stumble, etc.
3. If the roll was a success, narrate success appropriate to the challenge — insight, passage, persuasion, discovery, etc.
4. Always reflect the emotional state of characters and environmental response.
5. Do not invent new actions not tied to the roll or past choices. Use the existing action as your anchor.
6. Integrate atmosphere: weather, light, sound, forest energy, spirits, etc.

=== RESPONSE FORMAT ===
{
  "narrative": "Rich, multi-paragraph description showing direct consequences and emotional weight of the action",
  "location": "Current or updated location name",
  "choices": [
    {
      "action": "Concise action title",
      "description": "Detailed explanation with hints at consequences",
      "requiresDiceRoll": true/false,
      "diceType": "d20/d12/d10/d8/d6/d4",
      "rollDC": 15,
      "abilityType": "strength/dexterity/constitution/intelligence/wisdom/charisma",
      "rollModifier": 2,
      "rollPurpose": "Clear purpose for the roll"
    }
  ]
}`;

  try {
    const chatResponse = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        { role: "system", content: "You are a high-fantasy RPG Dungeon Master responding in structured JSON only." },
        { role: "user", content: prompt }
      ],
      temperature: 0.8,
      response_format: { type: "json_object" }
    });

    const content = chatResponse.choices[0]?.message?.content;
    if (!content) {
      throw new Error("Empty response from OpenAI");
    }

    const parsed = JSON.parse(content);
    if (!isValidDMResponse(parsed)) {
      throw new Error("Invalid DM response format");
    }

    return parsed;
  } catch (error) {
    console.error("DM response error:", error, "Response:", chatResponse?.choices[0]?.message?.content);

    // Return a fallback response
    return {
      narrative: "The Dungeon Master pauses for a moment, considering the situation carefully.",
      location: context.location,
      choices: [
        {
          action: "Wait patiently",
          description: "Give the DM a moment to gather their thoughts and continue the story.",
          requiresDiceRoll: false
        }
      ]
    };
  }
}