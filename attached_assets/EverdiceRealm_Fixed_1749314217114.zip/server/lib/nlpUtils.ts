
export function summarizeScene(sceneText: string): string {
  if (!sceneText) return '';
  
  // Extract key elements from scene text
  const location = extractLocation(sceneText);
  const characters = extractCharacters(sceneText);
  const action = extractPrimaryAction(sceneText);
  
  return `${location}: ${characters} ${action}`;
}

export function extractUnresolvedThreads(recentLogs: string[]): string[] {
  const threads = [];
  
  // Look for unfinished business in recent logs
  recentLogs.forEach(log => {
    if (log.includes('must') || log.includes('need to') || log.includes('should')) {
      threads.push(log);
    }
    if (log.includes('mystery') || log.includes('unknown') || log.includes('unclear')) {
      threads.push(log);
    }
  });
  
  return threads.slice(0, 3); // Limit to most recent/important
}

export function determineNarrativePhase(context: string, sessionCount: number): 'discovery' | 'confrontation' | 'resolution' {
  if (sessionCount < 15) return 'discovery';
  if (context.includes('portal') || context.includes('final') || context.includes('ultimate')) {
    return 'resolution';
  }
  return 'confrontation';
}

function extractLocation(text: string): string {
  const locationMatch = text.match(/(Grove|Clearing|Glade|Forest|Altar|Pool)/i);
  return locationMatch?.[0] || 'Unknown Location';
}

function extractCharacters(text: string): string {
  const characters = [];
  if (text.toLowerCase().includes('elowen')) characters.push('Elowen');
  if (text.toLowerCase().includes('unicorn')) characters.push('Unicorn');
  if (text.toLowerCase().includes('guardian')) characters.push('Guardian');
  if (characters.length === 0) characters.push('Adventurers');
  
  return characters.join(', ');
}

function extractPrimaryAction(text: string): string {
  if (text.includes('investigate') || text.includes('examine')) return 'investigating';
  if (text.includes('approach') || text.includes('move')) return 'approaching';
  if (text.includes('ritual') || text.includes('ceremony')) return 'performing ritual';
  if (text.includes('combat') || text.includes('fight')) return 'in combat';
  return 'exploring';
}
