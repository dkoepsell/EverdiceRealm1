
interface SessionLog {
  campaignId: number;
  title: string;
  scene: string;
  timestamp: string;
  phase: string;
  keyEvents: string[];
}

export async function pushSessionLog({ campaignId, title, scene, phase = 'ongoing', keyEvents = [] }: {
  campaignId: number;
  title: string;
  scene: string;
  phase?: string;
  keyEvents?: string[];
}): Promise<void> {
  const log: SessionLog = {
    campaignId,
    title,
    scene,
    timestamp: new Date().toISOString(),
    phase,
    keyEvents
  };
  
  // This would typically save to database
  console.log('Session logged:', log);
  
  // Update campaign memory based on this session
  // This is where we'd extract key developments and update the memory store
}

export async function getSessionHistory(campaignId: number, limit: number = 5): Promise<SessionLog[]> {
  // This would fetch from database
  // For now, return empty array as placeholder
  return [];
}
import fs from 'fs';
import path from 'path';

interface SessionData {
  id: number;
  number: number;
  title: string;
  location: string;
  description: string;
  date: string;
  playerActions?: string[];
  npcs?: string[];
  themes?: string;
  unresolvedHooks?: string[];
}

export function logSession(sessionData: SessionData) {
  // Ensure directory exists
  const logDir = path.resolve('data/sessionLogs');
  if (!fs.existsSync(logDir)) {
    fs.mkdirSync(logDir, { recursive: true });
  }

  const base = `data/sessionLogs/session-${sessionData.number}`;
  const jsonPath = path.resolve(`${base}.json`);
  const mdPath = path.resolve(`${base}.md`);

  // Save JSON format
  fs.writeFileSync(jsonPath, JSON.stringify(sessionData, null, 2));

  // Save Markdown format
  const mdContent = `# Session ${sessionData.number}: ${sessionData.title}

**Location**: ${sessionData.location}  
**Date**: ${new Date(sessionData.date).toLocaleString()}

## Summary
${sessionData.description}

## Player Actions
${sessionData.playerActions?.map(a => `- ${a}`).join('\n') || '_None_'}

## NPCs
${sessionData.npcs?.join(', ') || '_None_'}

## Themes
${sessionData.themes || '_Not specified_'}

## Unresolved Hooks
${sessionData.unresolvedHooks?.map(h => `- ${h}`).join('\n') || '_None_'}

---

`.trim();

  fs.writeFileSync(mdPath, mdContent);
}

export function getRecentSessions(count: number = 3): SessionData[] {
  const logDir = path.resolve('data/sessionLogs');
  if (!fs.existsSync(logDir)) {
    return [];
  }

  try {
    const files = fs.readdirSync(logDir)
      .filter(f => f.endsWith('.json'))
      .sort((a, b) => {
        const numA = parseInt(a.match(/session-(\d+)\.json/)?.[1] || '0');
        const numB = parseInt(b.match(/session-(\d+)\.json/)?.[1] || '0');
        return numB - numA; // Most recent first
      })
      .slice(0, count);

    return files.map(file => {
      const content = fs.readFileSync(path.join(logDir, file), 'utf8');
      return JSON.parse(content);
    });
  } catch (error) {
    console.error('Error reading session logs:', error);
    return [];
  }
}
