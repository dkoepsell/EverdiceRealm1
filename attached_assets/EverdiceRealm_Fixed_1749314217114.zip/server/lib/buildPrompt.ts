import { DMContext } from "./openai";
import { storage } from '../storage';

interface Session {
  id: number;
  title: string;
  narrative: string;
  location: string;
  themes?: string;
  unresolvedHooks?: string[];
  npcs?: string[];
  playerActions?: string[];
  createdAt: string;
}

// Helper functions for enhanced context
async function getCharacterProgression(campaignId: number) {
  const participants = await storage.getCampaignParticipants(campaignId);
  return participants.map(p => ({
    name: p.character.name,
    class: p.character.class,
    level: p.character.level || 1,
    recentActions: [], // Will be populated from session history
    skillProficiencies: [], // Based on class and background
    equipment: p.character.equipment || []
  }));
}

async function getActiveStoryArcs(campaignId: number) {
  // Implement story arc tracking
  return [
    {
      name: "Grove Corruption Mystery",
      status: "active",
      keyElements: ["corrupted guardian", "ancient altar", "Elowen's guidance"],
      nextMilestones: ["discover corruption source", "restore grove balance"]
    }
  ];
}

async function buildConsequencesTracker(sessionHistory: any[]) {
  const consequences = {
    unresolved: [],
    environmental: [],
    character: []
  };

  sessionHistory.forEach(session => {
    if (session.combatOutcome === 'victory') {
      consequences.environmental.push(`Defeated ${session.enemiesDefeated || 'creatures'} in ${session.location}`);
    }
    if (session.skillChecks?.some((check: any) => check.success)) {
      consequences.character.push(`Successfully used ${session.skillChecks.find((c: any) => c.success).abilityType} in ${session.location}`);
    }
  });

  return consequences;
}

async function updateStoryArcsFromAction(campaignId: number, action: string, lastChoice: any, storyUpdate: any) {
  // Update story progression based on player actions
  console.log(`📖 Updating story arcs for action: ${action}`);

  // This would update a story_arcs table or similar tracking mechanism
  // For now, we'll log the progression
  if (lastChoice?.skillCheckResult?.success) {
    console.log(`✅ Skill check success will advance story arc`);
  }
  if (lastChoice?.combatOutcome === 'victory') {
    console.log(`⚔️ Combat victory will unlock new story elements`);
  }
}

export function buildEnhancedPrompt(context: any): { systemPrompt: string; userPrompt: string } {
  const systemPrompt = `You are an expert Dungeon Master for D&D 5e running "${context.campaign.title}".

CORE PRINCIPLES:
- Respond to player actions with meaningful consequences that affect the world
- Integrate dice roll results naturally into the narrative and story progression
- Advance the story based on character choices, successes, and failures
- Build continuity from previous sessions rather than resetting scenarios
- Create escalating tension and meaningful character development

CURRENT CONTEXT:
Campaign: ${context.campaign.title}
Location: ${context.location}
Characters: ${context.characters}

${context.mechanicsContext ? `
CHARACTER PROGRESSION:
${context.mechanicsContext.characterProgression?.map((char: any) => 
  `- ${char.name} (${char.class} ${char.level}): Recent significant actions in story`
).join('\n') || 'No progression data'}

ACTIVE STORY ARCS:
${context.mechanicsContext.storyArcs?.map((arc: any) => 
  `- ${arc.name}: ${arc.status} (Next: ${arc.nextMilestones?.join(', ') || 'undefined'})`
).join('\n') || 'No active arcs'}

CONSEQUENCES TO ADDRESS:
${context.mechanicsContext.consequencesTracker ? 
  Object.entries(context.mechanicsContext.consequencesTracker).map(([key, value]: [string, any]) => 
    `${key}: ${Array.isArray(value) ? value.join('; ') : value}`
  ).join('\n') : 'No consequences tracked'}
` : ''}

${context.lastChoice?.skillCheckResult ? `
RECENT SKILL CHECK - MUST ACKNOWLEDGE:
- ${context.lastChoice.skillCheckResult.abilityType} check: ${context.lastChoice.skillCheckResult.roll} vs DC ${context.lastChoice.skillCheckResult.dc}
- Result: ${context.lastChoice.skillCheckResult.success ? 'SUCCESS - Story advances positively' : 'FAILURE - Story takes different path'}
- Action: ${context.lastChoice.skillCheckResult.actionContext}
- REQUIREMENT: Show clear consequences of this result in the narrative
` : ''}

${context.lastChoice?.combatOutcome ? `
RECENT COMBAT OUTCOME - MUST ACKNOWLEDGE:
- Outcome: ${context.lastChoice.combatOutcome}
- Rewards Applied: ${JSON.stringify(context.lastChoice.rewards || {})}
- REQUIREMENT: Show how this victory/defeat changes the situation and unlocks new story elements
` : ''}

ANTI-REPETITION GUIDELINES:
- AVOID these overused locations: ${context.antiRepetition.recentLocations?.join(', ') || 'none'}
- AVOID these repetitive action patterns: ${context.antiRepetition.recentActions?.join(', ') || 'none'}
- Current environmental elements to vary: ${context.antiRepetition.environmentalState?.join(', ') || 'none'}

MANDATORY RESPONSE REQUIREMENTS:
1. Acknowledge and show consequences of the player's most recent action and any dice results
2. Advance the main story arc rather than introducing new side mysteries
3. Build upon previous session outcomes instead of resetting to new scenarios
4. Create meaningful progression toward campaign objectives
5. Provide 2-3 specific action choices that relate to character abilities and story goals
6. If previous actions succeeded, unlock new story elements; if they failed, create meaningful setbacks
7. Ensure the narrative flows logically from the last session rather than jumping to new scenes`;

  const userPrompt = `The player character just performed this action: "${context.action}"

${context.lastChoice?.skillCheckResult ? `
This action involved a ${context.lastChoice.skillCheckResult.abilityType} check:
- Roll: ${context.lastChoice.skillCheckResult.roll} vs DC ${context.lastChoice.skillCheckResult.dc}
- Result: ${context.lastChoice.skillCheckResult.success ? 'SUCCESS' : 'FAILURE'}
- CRITICAL: Your narrative MUST show the consequences of this ${context.lastChoice.skillCheckResult.success ? 'success' : 'failure'}
` : ''}

${context.lastChoice?.combatOutcome ? `
This followed a combat encounter:
- Outcome: ${context.lastChoice.combatOutcome}
- Rewards: ${JSON.stringify(context.lastChoice.rewards || {})}
- CRITICAL: Your narrative MUST show how this ${context.lastChoice.combatOutcome} changes the situation
` : ''}

Current narrative state: ${context.narrative}

Recent session progression (MUST build upon these):
${context.sessionHistory.slice(-5).map((entry: any, index: number) => 
  `${index + 1}. ${entry.location || 'Unknown location'}: ${entry.action || 'Unknown action'}${
    entry.skillChecks?.length > 0 ? ` [${entry.skillChecks.map((c: any) => `${c.abilityType} ${c.success ? 'success' : 'fail'}`).join(', ')}]` : ''
  }${entry.combatOutcome ? ` [Combat: ${entry.combatOutcome}]` : ''}`
).join('\n') || 'No recent history'}

CRITICAL REQUIREMENTS:
1. Show clear consequences of the most recent action and any dice results
2. Advance the main story arc instead of creating new unrelated scenarios
3. Build logical continuity from the session history
4. If a skill check succeeded, show positive progression; if it failed, show meaningful setbacks
5. If combat was won, unlock new story elements; if lost, create interesting complications

Generate a response that progresses the EXISTING story rather than starting new side quests.

Respond in JSON format:
{
  "narrative": "Your detailed narrative response that shows consequences and advances the story",
  "location": "Current location name (should evolve from previous location)",
  "choices": [
    {
      "action": "Specific action description related to character abilities",
      "requiresRoll": false,
      "abilityType": "strength/dexterity/etc if roll required",
      "rollDC": 15
    }
  ],
  "storyProgression": {
    "arcAdvancement": "How this advances the main story arc",
    "consequencesShown": "What consequences were shown for previous actions",
    "nextObjectives": ["List of logical next story objectives"]
  }
}`;

  return { systemPrompt, userPrompt };
}

export function buildPrompt(context: DMContext): string {
  const {
    campaignState,
    sessionHistory,
    currentLocation,
    playerChoices,
    characterProfiles,
    storyArcInfo
  } = context;

  // Build session memory from recent history
  const sessionMemory = sessionHistory.slice(-5).map(session => {
    return `- Session ${session.sessionNumber}: ${session.title || 'Untitled'} - ${session.narrative.substring(0, 150)}...`;
  }).join('\n');

  // Extract last session's key events
  const lastSession = sessionHistory[sessionHistory.length - 1];
  const lastEvent = lastSession ? `Last event: ${lastSession.narrative.substring(lastSession.narrative.lastIndexOf('.', 200))}` : '';

  let prompt = `SYSTEM: You are a Dungeons & Dragons storyteller generating an adventure session. Maintain rich sensory detail, character consistency, and meaningful branching. Keep pacing tight and tie each session to prior ones. Assume a persistent world with memory.

USER: Generate the next session in a D&D campaign.

Session Summary:
- Current location: ${currentLocation}
- Party members: ${characterProfiles.map(char => `${char.name} (${char.race} ${char.class})`).join(', ')}
- Campaign: ${campaignState.title} (${campaignState.difficulty} difficulty)
- Current session: ${campaignState.currentSession}
- ${lastEvent}

Session Memory:
${sessionMemory}`;

  if (storyArcInfo) {
    const currentPhase = storyArcInfo.phases[storyArcInfo.currentPhase];
    prompt += `\n\nStory Arc Context:
- Arc: "${storyArcInfo.title}" - Phase ${storyArcInfo.currentPhase + 1}/${storyArcInfo.phases.length}
- Current Phase: "${currentPhase?.title}"
- Phase Objectives: ${currentPhase?.objectives.join(', ')}
- Sessions in Phase: ${currentPhase?.sessionCount}/${currentPhase?.maxSessions}`;
  }

  prompt += `\n\nCharacter Details:
${characterProfiles.map(char => 
  `- ${char.name}: ${char.race} ${char.class} (Level ${char.level}) - ${char.background || 'Background unknown'}`
).join('\n')}

Instructions:
1. Begin with a vivid description of the environment that builds on the current situation.
2. Include a dramatic development or encounter that pushes the story forward meaningfully.
3. Offer 2-3 meaningful player choices or tests (combat, wisdom, stealth, diplomacy, etc.).
4. Ensure continuity with past events and character motivations.
5. Include character-specific interactions that play to their strengths and backgrounds.
6. Create consequences that matter - choices should have weight and impact.
7. End on a compelling moment that requires player decision.

Choice Structure:
Present choices in this format:
- [Action Type]: Brief description of the choice
- [Action Type]: Alternative approach
- [Action Type]: Creative/unexpected option

Generate Session ${campaignState.currentSession} of the narrative with rich detail and meaningful player agency.`;

  return prompt;
}

function extractThemesFromHistory(history: string[] = []): string[] {
  const text = history.join(" ").toLowerCase();
  const themes = [];
  if (text.includes("darkness") || text.includes("corruption")) themes.push("Forest corruption");
  if (text.includes("Elowen")) themes.push("Elowen's warnings");
  if (text.includes("guardian") || text.includes("spirits")) themes.push("Twisted guardians");
  if (text.includes("ancient magic") || text.includes("runes")) themes.push("Ancient magic");
  return themes;
}

function identifyUnresolvedThreads(history: string[] = []): string[] {
  const threads: string[] = [];
  if (history.some(h => h.includes("portal") && !h.includes("entered"))) {
    threads.push("Unentered portal");
  }
  if (history.some(h => h.includes("runes") && !h.includes("solved") && !h.includes("translated"))) {
    threads.push("Mysterious runes");
  }
  if (history.some(h => h.includes("spirit") && h.includes("cry") && !h.includes("resolved"))) {
    threads.push("Spirit's cry unanswered");
  }
  return threads;
}

export function parseModifier(mod: any): number {
  if (typeof mod === 'string') {
    const cleaned = mod.replace(/[^-+\d]/g, '');
    const num = parseInt(cleaned, 10);
    return isNaN(num) ? 0 : num;
  }
  return typeof mod === 'number' ? mod : 0;
}

export function checkForStalling(current: string, last: string): boolean {
  const currentLower = current.toLowerCase();
  const lastLower = last.toLowerCase();

  return (
    (currentLower.includes('elowen gestures') && lastLower.includes('elowen gestures')) ||
    (currentLower.includes('ancient oak') && lastLower.includes('ancient oak')) ||
    (currentLower.includes('dappled sunlight') && lastLower.includes('dappled sunlight')) ||
    (currentLower.match(/the grove/g)?.length > 2 && lastLower.match(/the grove/g)?.length > 2)
  );
}