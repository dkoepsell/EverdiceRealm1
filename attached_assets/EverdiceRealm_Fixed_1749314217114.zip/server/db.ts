import { Pool, neonConfig } from '@neondatabase/serverless';
import { drizzle } from 'drizzle-orm/neon-serverless';
import ws from "ws";
import * as schema from "@shared/schema";

neonConfig.webSocketConstructor = ws;

if (!process.env.DATABASE_URL) {
  throw new Error(
    "DATABASE_URL must be set. Did you forget to provision a database?",
  );
}

export const pool = new Pool({ connectionString: process.env.DATABASE_URL });
export const db = drizzle(pool, { 
  schema,
  logger: process.env.NODE_ENV === 'development'
});

import { pgTable, serial, integer, varchar, boolean, timestamp } from 'drizzle-orm/pg-core';

export const users = pgTable('users', {
  id: serial('id').primaryKey(),
  email: varchar('email', { length: 256 }).notNull(),
  password: varchar('password', { length: 256 }).notNull(),
  createdAt: timestamp('created_at').defaultNow(),
});

export type User = typeof users.$inferSelect;

export const npcs = pgTable('npcs', {
  id: serial('id').primaryKey(),
  name: varchar('name', { length: 256 }).notNull(),
  description: varchar('description', { length: 256 }).notNull(),
  createdAt: timestamp('created_at').defaultNow(),
});

export type NPC = typeof npcs.$inferSelect;

export const items = pgTable('items', {
  id: serial('id').primaryKey(),
  name: varchar('name', { length: 256 }).notNull(),
  description: varchar('description', { length: 256 }).notNull(),
  createdAt: timestamp('created_at').defaultNow(),
});

export type Item = typeof items.$inferSelect;

export const quests = pgTable('quests', {
  id: serial('id').primaryKey(),
  name: varchar('name', { length: 256 }).notNull(),
  description: varchar('description', { length: 256 }).notNull(),
  createdAt: timestamp('created_at').defaultNow(),
});

export type Quest = typeof quests.$inferSelect;

export const campaigns = pgTable('campaigns', {
  id: serial('id').primaryKey(),
  name: varchar('name', { length: 256 }).notNull(),
  description: varchar('description', { length: 256 }).notNull(),
  createdAt: timestamp('created_at').defaultNow(),
  ownerId: integer('owner_id').references(() => users.id),
  isActive: boolean('is_active').default(true),
});

export type Campaign = typeof campaigns.$inferSelect;

export const campaignNpcs = pgTable('campaign_npcs', {
  id: serial('id').primaryKey(),
  campaignId: integer('campaign_id').references(() => campaigns.id),
  npcId: integer('npc_id').references(() => npcs.id),
  role: varchar('role', { length: 50 }).default('companion'),
  isActive: boolean('is_active').default(true),
  createdAt: timestamp('created_at').defaultNow(),
});

export const campaignParticipants = pgTable('campaign_participants', {
  id: serial('id').primaryKey(),
  campaignId: integer('campaign_id').references(() => campaigns.id),
  userId: integer('user_id').references(() => users.id),
  role: varchar('role', { length: 50 }).default('player'),
  joinedAt: timestamp('joined_at').defaultNow(),
  isActive: boolean('is_active').default(true),
});

export type CampaignNPC = typeof campaignNpcs.$inferSelect;
export type CampaignParticipant = typeof campaignParticipants.$inferSelect;

export { eq, and, or, desc, asc, sql, gte, lte, like, ilike, inArray } from 'drizzle-orm';