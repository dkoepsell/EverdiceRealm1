# Session 62: The Grove's Heart

**Location**: The Enchanted Grove - Clearing with a Stone Altar  
**Date**: 5/26/2025, 4:43:29 PM

## Summary
The adventurers find themselves standing at the edge of a mist-laden clearing within the heart of the Enchanted Grove. Towering trees encircle the space like ancient sentinels, their gnarled branches weaving together to form a canopy that filters the silvery moonlight into ethereal patterns on the forest floor. The air is heavy with the intoxicating scent of wildflowers and the soft hum of nocturnal creatures awakening. In the center of the clearing stands a stone altar, overgrown yet still emanating a faint, otherworldly glow.

Elowen, the druid guiding them, steps forward, her voice a soft whisper carried by the breeze. "This is the Grove's Heart," she explains, her fingers lightly tracing the strange runes carved into the altar's surface. "The darkness you seek originates here, spreading through the forest like a blight. To restore balance, we must rekindle the ancient magic sleeping within these stones."

As Elowen speaks, a low growl echoes from the shadows, and the group turns to see a pair of spectral wolves emerging from the mist, their eyes glowing with an unnatural light. They circle the clearing, an unnerving presence that demands caution and quick thinking.

The adventurers must decide their course of action, weighing the need for immediate defense against the potential for discovering further secrets hidden within the grove.

## Player Actions
- undefined

## NPCs
_None_

## Themes
corruption, grove, mystery

## Unresolved Hooks
- Investigate the stone altar
- Prepare to defend against the spectral wolves
- Consult with Elowen
- Sneak closer to the wolves for a surprise attack

---