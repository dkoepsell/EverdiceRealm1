# Session 68: The Wayward Guardian

**Location**: Luminous Clearing of the Enchanted Grove  
**Date**: 5/28/2025, 3:03:50 PM

## Summary
As the adventurers press on through the sun-dappled shadows of the Enchanted Grove, a palpable tension hangs in the air. The eerily hushed whispers of the trees seem to converge above in the rustling canopy, their once welcoming boughs now draped in an unsettling shroud of mystery. Elowen, the enigmatic druid, pauses beside an ancient, gnarled oak, her eyes closed, hands caressing the rugged bark as she communes with the forest. "The balance is disrupted," she murmurs, her voice strained yet determined. "Something... or someone... is corrupting the heart of this grove. We must be vigilant."

Suddenly, the ground trembles ever so slightly beneath their feet; a foreboding sign that something stirs deep within. Before the party, a clearing unfurls, revealing a peculiar grove bathed in an unearthly green glow. In its center stands a pedestal of twisted roots and stones, encircling a luminous orb pulsating with flickers of shadowy energy—clearly the source of the malevolent transformation.

From behind the pedestal, stepping out of the shifting mirage of dappled light, emerges a creature of ethereal beauty yet undeniable menace. With skin like alabaster and eyes that shimmer like moonlit pools, the dryad—twisted by the darkness—is a guardian overcome by the very corruption they seek to end. With a voice resonant and mournful, she speaks: "Turn back, trespassers, lest you fall victim to the grove's darkened embrace."

Armed with resolution and determination, the adventurers know they must either find a way to bypass the dryad peacefully, confront her head-on, or unlock the secrets of the orb to restore balance once more.

## Player Actions
- undefined

## NPCs
_None_

## Themes
corruption, grove, mystery

## Unresolved Hooks
- Approach the dryad with diplomacy
- Investigate the orb and the pedestal
- Charge into combat with the dryad
- Retreat and find another path

---