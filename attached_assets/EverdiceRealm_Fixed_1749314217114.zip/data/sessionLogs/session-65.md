# Session 65: The Call of the Sacred Pool

**Location**: Sacred Pool of Elara  
**Date**: 5/28/2025, 2:54:17 PM

## Summary
As the party ventures further into the heart of the Enchanted Grove, they are met with a sudden and overwhelming stillness. The air is thick with anticipation, and the usual symphony of forest sounds is eerily absent. Sunlight filters through the dense canopy in intricate patterns, casting mystical shadows that dance across the forest floor. Ahead, a shimmering pond appears, its surface a mirror reflecting the emerald hue of the surrounding foliage.

Elowen, the enigmatic druid, pauses at the edge of the water, her gaze intense as she studies the pond's depths. She turns to the adventurers, her voice a soft whisper even in the unnatural quiet. "This is the Sacred Pool of Elara," she explains, gesturing to the still surface. "For centuries, it has been a wellspring of life and magic, but now it lies tainted by darkness."

Just as her words fade, the water ripples, and from the depths emerges a creature of ethereal beauty—an ancient mermaid with scales that glimmer like moonlight. Her expression is one of wearied grief. "I am Nereia, guardian of this sacred place," she speaks, her voice a haunting melody. "A darkness unknown to me seeps into these waters, threatening all that inhabit the grove. I beseech you, brave souls, unravel this mystery and restore what once was."

As the players absorb this newfound task, a gentle breeze stirs the leaves, infusing the air with a subtle scent of jasmine, as if the grove itself joins in urging them onward. The future is uncertain, yet filled with the promise of discovery and the possibility of freeing this enchanted land from its curse.

## Player Actions
- undefined

## NPCs
_None_

## Themes
corruption, grove, mystery

## Unresolved Hooks
- Examine the pond closely
- Communicate with Nereia
- Explore the surrounding area
- Prepare defenses against potential threats

---