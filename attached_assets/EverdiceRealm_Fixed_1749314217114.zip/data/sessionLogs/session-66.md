# Session 66: The Heart of Darkness

**Location**: Enchanted Grove Core, Elaria  
**Date**: 5/28/2025, 2:58:53 PM

## Summary
The adventurers find themselves deep in the heart of the Enchanted Grove, where the trees loom tall and old, their bark covered in intricate patterns that seem to shift under the dappled light. The air is thick with the scent of moss and earth, and the leaves whisper secrets as the wind caresses them gently. Elowen, the druid guide, pauses, raising a hand to signal silence. Her eyes, sharp and emerald green, scan the surroundings with an intensity born of years spent in harmony with nature.

'Here,' she finally speaks, her voice barely above a whisper. 'This is the core of the grove's magic, but something foul seeps into its heart.' She points to a monolithic stone partly hidden by the underbrush, etched with ancient runes now covered in creeping shadows that pulse with a life of their own.

As the adventurers approach the stone, they can feel the unnerving cold emanating from the runes. A low hum vibrates through the ground, growing louder with each step they take. Suddenly, from the shadows at the stone's base, a group of Dark Sprites emerges, their small wings buzzing angrily as they ready themselves to guard whatever dark magic holds sway over the grove.

The party stands poised on the edge of action, each adventurer instinctively tightening their grip on weapons or focusing on the arcane spells they might need to unravel the threads of this dark curse. It's clear that they must act carefully, for disturbing the magic here may have unintended consequences.

## Player Actions
- undefined

## NPCs
_None_

## Themes
corruption, grove, mystery

## Unresolved Hooks
- Engage the Dark Sprites in combat
- Attempt to communicate with the sprites
- Examine the runes on the monolithic stone
- Retreat and regroup

---