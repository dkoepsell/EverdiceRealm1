const fetch = require('node-fetch');

// Test environment
const API_BASE = 'http://localhost:3000';
const CAMPAIGN_ID = 5; // Using an existing campaign ID from your logs
const TEST_REWARDS = {
  xp: 250,
  gold: 75,
  items: [
    {
      id: 1001,
      name: "Healing Potion",
      description: "Restores 2d4+2 hit points when consumed.",
      rarity: "common",
      type: "potion"
    },
    {
      id: 1002,
      name: "Moon-Touched Sword",
      description: "This sword glows with moonlight, creating dim light in a 15-foot radius.",
      rarity: "common",
      type: "weapon",
      slot: "weapon",
      equipped: false
    }
  ]
};

// Function to test character rewards
async function testCombatRewards() {
  console.log("Testing Character Combat Rewards System");
  console.log("---------------------------------------");
  
  try {
    // 1. Get a character to use for testing
    console.log("Fetching campaign participants...");
    const participantsResponse = await fetch(`${API_BASE}/api/campaigns/${CAMPAIGN_ID}/participants`, {
      credentials: 'include'
    });
    
    if (!participantsResponse.ok) {
      throw new Error(`Failed to fetch participants: ${participantsResponse.statusText}`);
    }
    
    const participants = await participantsResponse.json();
    
    if (!participants || participants.length === 0) {
      throw new Error("No participants found in the campaign");
    }
    
    // Get the first participant's character
    const characterId = participants[0].characterId;
    console.log(`Using character ID: ${characterId}`);
    
    // 2. Get the character's initial state
    console.log("Fetching character's initial state...");
    const initialCharResponse = await fetch(`${API_BASE}/api/characters/${characterId}`, {
      credentials: 'include'
    });
    
    if (!initialCharResponse.ok) {
      throw new Error(`Failed to fetch character: ${initialCharResponse.statusText}`);
    }
    
    const initialCharacter = await initialCharResponse.json();
    console.log(`Initial character state:`);
    console.log(`- XP: ${initialCharacter.experience || 0}`);
    console.log(`- Gold: ${initialCharacter.gold || 0}`);
    console.log(`- Inventory items: ${(initialCharacter.inventory || []).length}`);
    
    // 3. Apply combat rewards
    console.log("\nSending combat rewards...");
    const rewardResponse = await fetch(`${API_BASE}/api/campaigns/${CAMPAIGN_ID}/character/reward`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(TEST_REWARDS),
      credentials: 'include'
    });
    
    if (!rewardResponse.ok) {
      throw new Error(`Failed to apply rewards: ${rewardResponse.statusText}`);
    }
    
    const rewardResult = await rewardResponse.json();
    console.log("Reward response:", rewardResult);
    
    // 4. Get the character's updated state
    console.log("\nFetching character's updated state...");
    const updatedCharResponse = await fetch(`${API_BASE}/api/characters/${characterId}`, {
      credentials: 'include'
    });
    
    if (!updatedCharResponse.ok) {
      throw new Error(`Failed to fetch updated character: ${updatedCharResponse.statusText}`);
    }
    
    const updatedCharacter = await updatedCharResponse.json();
    console.log(`Updated character state:`);
    console.log(`- XP: ${updatedCharacter.experience || 0} (${(updatedCharacter.experience || 0) - (initialCharacter.experience || 0)} added)`);
    console.log(`- Gold: ${updatedCharacter.gold || 0} (${(updatedCharacter.gold || 0) - (initialCharacter.gold || 0)} added)`);
    console.log(`- Inventory items: ${(updatedCharacter.inventory || []).length} (${(updatedCharacter.inventory || []).length - (initialCharacter.inventory || []).length} added)`);
    
    if (updatedCharacter.inventory && updatedCharacter.inventory.length > 0) {
      console.log("\nNew inventory items:");
      updatedCharacter.inventory.slice(-TEST_REWARDS.items.length).forEach(item => {
        console.log(`- ${item.name} (${item.rarity} ${item.type})`);
      });
    }
    
    // 5. Validate the results
    const xpAdded = (updatedCharacter.experience || 0) - (initialCharacter.experience || 0);
    const goldAdded = (updatedCharacter.gold || 0) - (initialCharacter.gold || 0);
    const itemsAdded = (updatedCharacter.inventory || []).length - (initialCharacter.inventory || []).length;
    
    if (xpAdded === TEST_REWARDS.xp && 
        goldAdded === TEST_REWARDS.gold && 
        itemsAdded === TEST_REWARDS.items.length) {
      console.log("\n✅ TEST PASSED: Character rewards system is working correctly!");
    } else {
      console.log("\n❌ TEST FAILED: Discrepancies in expected vs actual rewards");
      console.log(`Expected: +${TEST_REWARDS.xp} XP, +${TEST_REWARDS.gold} gold, +${TEST_REWARDS.items.length} items`);
      console.log(`Actual: +${xpAdded} XP, +${goldAdded} gold, +${itemsAdded} items`);
    }
    
  } catch (error) {
    console.error("Error during test:", error.message);
  }
}

// Run the test
testCombatRewards();