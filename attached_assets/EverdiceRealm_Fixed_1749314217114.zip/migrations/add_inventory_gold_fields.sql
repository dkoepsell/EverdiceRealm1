-- Add gold column if it doesn't exist
DO $$ 
BEGIN
    IF NOT EXISTS (
        SELECT FROM information_schema.columns 
        WHERE table_name = 'characters' AND column_name = 'gold'
    ) THEN
        ALTER TABLE characters ADD COLUMN gold INTEGER DEFAULT 0;
    END IF;
END $$;

-- Add inventory JSON column if it doesn't exist
DO $$ 
BEGIN
    IF NOT EXISTS (
        SELECT FROM information_schema.columns 
        WHERE table_name = 'characters' AND column_name = 'inventory'
    ) THEN
        ALTER TABLE characters ADD COLUMN inventory JSONB DEFAULT '[]';
    END IF;
END $$;