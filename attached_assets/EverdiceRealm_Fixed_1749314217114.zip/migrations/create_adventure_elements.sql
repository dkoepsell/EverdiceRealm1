
-- Create adventure_elements table for storing AI-generated quest content
CREATE TABLE IF NOT EXISTS adventure_elements (
  id SERIAL PRIMARY KEY,
  element_type VARCHAR(50) NOT NULL,
  title VARCHAR(255) NOT NULL,
  description TEXT,
  details JSONB,
  is_public BOOLEAN DEFAULT false,
  created_by INTEGER REFERENCES users(id) ON DELETE CASCADE,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_adventure_elements_type ON adventure_elements(element_type);
CREATE INDEX IF NOT EXISTS idx_adventure_elements_created_by ON adventure_elements(created_by);
CREATE INDEX IF NOT EXISTS idx_adventure_elements_public ON adventure_elements(is_public);
