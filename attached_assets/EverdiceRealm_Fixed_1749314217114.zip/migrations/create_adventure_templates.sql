
-- Create adventure_templates table for storing quest templates
CREATE TABLE IF NOT EXISTS adventure_templates (
  id SERIAL PRIMARY KEY,
  title VARCHAR(255) NOT NULL,
  description TEXT,
  structure JSONB,
  difficulty_range VARCHAR(50),
  recommended_levels VARCHAR(50),
  tags JSONB,
  is_public BOOLEAN DEFAULT false,
  created_by INTEGER REFERENCES users(id) ON DELETE CASCADE,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_adventure_templates_created_by ON adventure_templates(created_by);
CREATE INDEX IF NOT EXISTS idx_adventure_templates_public ON adventure_templates(is_public);
