import { describe, it, expect } from 'vitest';
import { resolveCombatOutcome } from '../server/utils/combat';

describe('resolveCombatOutcome', () => {
  it('should calculate a win if player total > enemy total', () => {
    const result = resolveCombatOutcome(18, 14);
    expect(result.result).toBe('win');
  });

  it('should calculate a loss if player total < enemy total', () => {
    const result = resolveCombatOutcome(12, 16);
    expect(result.result).toBe('loss');
  });

  it('should calculate a draw if totals are equal', () => {
    const result = resolveCombatOutcome(15, 15);
    expect(result.result).toBe('draw');
  });

  it('should include the correct damage modifier', () => {
    const result = resolveCombatOutcome(18, 14);
    expect(result.damage).toBeGreaterThan(0);
  });
});
