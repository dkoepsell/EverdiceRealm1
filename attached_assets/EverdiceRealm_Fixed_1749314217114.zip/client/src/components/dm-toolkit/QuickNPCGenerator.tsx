
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { RefreshCw, Users, Scroll } from "lucide-react";

const names = {
  human: ["Aerdrie", "Ahvak", "Aramil", "Berris", "Cithreth", "Dayereth", "Enna", "Galinndan", "Hadarai", "Halimath", "Heian", "Himo", "Immeral", "Ivellios", "Korfel", "Lamlis", "Laucian", "Mindartis", "Naal", "Nutae", "Paelynn", "Peren", "Quarion", "Riardon", "Silvyr", "Suhnaal", "Thamior", "Theriatis", "Therivan", "Uthemar", "Vanuath", "Varis"],
  elf: ["Adrie", "Ahvak", "Aramil", "Berris", "Cithreth", "Dayereth", "Enna", "Galinndan", "Hadarai", "Halimath", "Heian", "Himo", "Immeral", "Ivellios", "Korfel", "Lamlis", "Laucian", "Mindartis", "Naal", "Nutae", "Paelynn", "Peren", "Quarion", "Riardon", "Silvyr", "Suhnaal", "Thamior", "Theriatis", "Therivan", "Uthemar", "Vanuath", "Varis"],
  dwarf: ["Adrik", "Alberich", "Baern", "Barendd", "Brottor", "Bruenor", "Dain", "Darrak", "Delg", "Eberk", "Einkil", "Fargrim", "Flint", "Gardain", "Harbek", "Kildrak", "Morgran", "Orsik", "Oskar", "Rangrim", "Rurik", "Taklinn", "Thoradin", "Thorek", "Tordek", "Traubon", "Travok", "Ulfgar", "Veit", "Vondal"]
};

const occupations = [
  "Blacksmith", "Baker", "Innkeeper", "Merchant", "Guard", "Farmer", "Tailor", "Carpenter", "Fisherman", "Scribe", 
  "Priest", "Herbalist", "Miner", "Hunter", "Stable Master", "Cook", "Barber", "Jeweler", "Leatherworker", "Mason"
];

const personalities = [
  "Friendly and talkative", "Gruff but helpful", "Suspicious of strangers", "Overly cheerful", "Quiet and mysterious",
  "Greedy and calculating", "Honest and straightforward", "Nervous and fidgety", "Wise and patient", "Hot-tempered",
  "Curious about everything", "Pessimistic outlook", "Optimistic dreamer", "Practical and direct", "Eccentric and odd"
];

const secrets = [
  "Has a hidden treasure", "Is actually nobility in hiding", "Owes money to dangerous people", "Knows about a secret passage",
  "Has magical abilities they hide", "Is related to someone important", "Witnessed a crime", "Has a dark past",
  "Is secretly in love with someone", "Knows the location of something valuable", "Is being blackmailed", "Has a gambling problem"
];

export default function QuickNPCGenerator() {
  const [npc, setNpc] = useState<any>(null);

  const generateNPC = () => {
    const races = Object.keys(names);
    const selectedRace = races[Math.floor(Math.random() * races.length)];
    const nameList = names[selectedRace as keyof typeof names];
    
    const newNpc = {
      name: nameList[Math.floor(Math.random() * nameList.length)],
      race: selectedRace.charAt(0).toUpperCase() + selectedRace.slice(1),
      occupation: occupations[Math.floor(Math.random() * occupations.length)],
      personality: personalities[Math.floor(Math.random() * personalities.length)],
      secret: secrets[Math.floor(Math.random() * secrets.length)],
      appearance: generateAppearance(),
      quirk: generateQuirk()
    };
    
    setNpc(newNpc);
  };

  const generateAppearance = () => {
    const features = [
      "tall and lanky", "short and stout", "average height", "muscular build", "thin frame",
      "weathered face", "youthful appearance", "scarred hands", "bright eyes", "stern expression"
    ];
    return features[Math.floor(Math.random() * features.length)];
  };

  const generateQuirk = () => {
    const quirks = [
      "always fidgets with something", "speaks in riddles", "has a nervous laugh", "constantly cleaning",
      "quotes old sayings", "hums while working", "avoids eye contact", "gestures wildly when talking",
      "has a pet that follows them", "collects unusual items"
    ];
    return quirks[Math.floor(Math.random() * quirks.length)];
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Users className="h-5 w-5" />
          Quick NPC Generator
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <Button onClick={generateNPC} className="w-full">
          <RefreshCw className="h-4 w-4 mr-2" />
          Generate Random NPC
        </Button>

        {npc && (
          <div className="space-y-4">
            <div className="flex items-center gap-2">
              <h3 className="text-lg font-semibold">{npc.name}</h3>
              <Badge>{npc.race}</Badge>
              <Badge variant="outline">{npc.occupation}</Badge>
            </div>
            
            <Separator />
            
            <div className="space-y-2">
              <div>
                <span className="font-medium">Appearance:</span> {npc.appearance}
              </div>
              <div>
                <span className="font-medium">Personality:</span> {npc.personality}
              </div>
              <div>
                <span className="font-medium">Quirk:</span> {npc.quirk}
              </div>
              <div>
                <span className="font-medium">Potential Secret:</span> {npc.secret}
              </div>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
