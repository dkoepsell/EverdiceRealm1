import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { Plus, Edit, Trash2, MapPin, Home, Skull, TreePine, Castle, Mountain } from "lucide-react";

interface Location {
  id: string;
  name: string;
  type: 'city' | 'dungeon' | 'wilderness' | 'tavern' | 'temple' | 'ruins' | 'cave' | 'castle';
  description: string;
  inhabitants: string;
  dangers: string;
  treasures: string;
  connections: string[];
  secrets: string;
  atmosphere: string;
  difficulty: 'easy' | 'medium' | 'hard' | 'legendary';
}

const locationTypes = [
  { value: 'city', label: 'City/Town', icon: Home },
  { value: 'dungeon', label: 'Dungeon', icon: Skull },
  { value: 'wilderness', label: 'Wilderness', icon: TreePine },
  { value: 'tavern', label: 'Tavern/Inn', icon: Home },
  { value: 'temple', label: 'Temple', icon: Castle },
  { value: 'ruins', label: 'Ruins', icon: Mountain },
  { value: 'cave', label: 'Cave', icon: Mountain },
  { value: 'castle', label: 'Castle', icon: Castle }
];

export default function LocationsTab() {
  const { toast } = useToast();
  const [locations, setLocations] = useState<Location[]>([]);
  const [loading, setLoading] = useState(true);
  const [isCreateOpen, setIsCreateOpen] = useState(false);
  const [editingLocation, setEditingLocation] = useState<Location | null>(null);
  const [formData, setFormData] = useState<Partial<Location>>({
    name: '',
    type: 'city',
    description: '',
    inhabitants: '',
    dangers: '',
    treasures: '',
    connections: [],
    secrets: '',
    atmosphere: '',
    difficulty: 'easy'
  });
  const [isSaving, setSaving] = useState(false);
  const [isGenerating, setIsGenerating] = useState(false);
  const [generationPrompt, setGenerationPrompt] = useState('');

  const generateLocationWithAI = async () => {
    if (!generationPrompt.trim()) {
      toast({
        title: "Error",
        description: "Please enter a description for the location you want to generate",
        variant: "destructive"
      });
      return;
    }

    setIsGenerating(true);
    try {
      const response = await fetch('/api/openai/generate-location', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        credentials: 'include',
        body: JSON.stringify({
          prompt: generationPrompt,
          locationType: formData.type || 'city'
        })
      });

      if (!response.ok) {
        throw new Error('Failed to generate location');
      }

      const generatedLocation = await response.json();

      // Fill form with generated data
      setFormData({
        name: generatedLocation.name || '',
        type: generatedLocation.type || 'city',
        description: generatedLocation.description || '',
        inhabitants: generatedLocation.inhabitants || '',
        dangers: generatedLocation.dangers || '',
        treasures: generatedLocation.treasures || '',
        connections: generatedLocation.connections || [],
        secrets: generatedLocation.secrets || '',
        atmosphere: generatedLocation.atmosphere || '',
        difficulty: generatedLocation.difficulty || 'easy'
      });

      setGenerationPrompt('');

      toast({
        title: "Success",
        description: "Location generated successfully! Review and save when ready."
      });
    } catch (error) {
      console.error('Error generating location:', error);
      toast({
        title: "Error",
        description: "Failed to generate location with AI",
        variant: "destructive"
      });
    } finally {
      setIsGenerating(false);
    }
  };

  // Load locations from database
  useEffect(() => {
    fetchLocations();
  }, []);

  const fetchLocations = async () => {
    try {
      const response = await fetch('/api/dm-toolkit/locations', {
        credentials: 'include'
      });
      if (response.ok) {
        const data = await response.json();
        setLocations(data);
      } else {
        toast({
          title: "Error",
          description: "Failed to load locations",
          variant: "destructive"
        });
      }
    } catch (error) {
      console.error('Error fetching locations:', error);
      toast({
        title: "Error", 
        description: "Failed to load locations",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const saveLocation = async (locationData: Partial<Location>) => {
    try {
      const method = editingLocation ? 'PUT' : 'POST';
      const url = editingLocation 
        ? `/api/dm-toolkit/locations/${editingLocation.id}`
        : '/api/dm-toolkit/locations';

      const response = await fetch(url, {
        method,
        headers: {
          'Content-Type': 'application/json'
        },
        credentials: 'include',
        body: JSON.stringify(locationData)
      });

      if (response.ok) {
        const savedLocation = await response.json();

        if (editingLocation) {
          setLocations(locations.map(loc => 
            loc.id === editingLocation.id ? savedLocation : loc
          ));
          toast({
            title: "Success",
            description: "Location updated successfully"
          });
        } else {
          setLocations([...locations, savedLocation]);
          toast({
            title: "Success", 
            description: "Location created successfully"
          });
        }

        resetForm();
      } else {
        throw new Error('Failed to save location');
      }
    } catch (error) {
      console.error('Error saving location:', error);
      toast({
        title: "Error",
        description: "Failed to save location",
        variant: "destructive"
      });
    }
  };

  const deleteLocation = async (id: string) => {
    try {
      const response = await fetch(`/api/dm-toolkit/locations/${id}`, {
        method: 'DELETE',
        credentials: 'include'
      });

      if (response.ok) {
        setLocations(locations.filter(loc => loc.id !== id));
        toast({
          title: "Success",
          description: "Location deleted successfully"
        });
      } else {
        throw new Error('Failed to delete location');
      }
    } catch (error) {
      console.error('Error deleting location:', error);
      toast({
        title: "Error",
        description: "Failed to delete location",
        variant: "destructive"
      });
    }
  };

  const handleCreate = () => {
    if (!formData.name || !formData.description) {
      toast({
        title: "Error",
        description: "Name and description are required",
        variant: "destructive"
      });
      return;
    }
    saveLocation(formData);
  };

  const handleEdit = (location: Location) => {
    setEditingLocation(location);
    setFormData({
      name: location.name,
      type: location.type,
      description: location.description,
      inhabitants: location.inhabitants,
      dangers: location.dangers,
      treasures: location.treasures,
      connections: location.connections,
      secrets: location.secrets,
      atmosphere: location.atmosphere,
      difficulty: location.difficulty
    });
    setIsCreateOpen(true);
  };

  const handleDelete = (id: string) => {
    if (confirm('Are you sure you want to delete this location?')) {
      deleteLocation(id);
    }
  };

  const resetForm = () => {
    setFormData({
      name: '',
      type: 'city',
      description: '',
      inhabitants: '',
      dangers: '',
      treasures: '',
      connections: [],
      secrets: '',
      atmosphere: '',
      difficulty: 'easy'
    });
    setEditingLocation(null);
    setIsCreateOpen(false);
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center p-8">
        <div className="text-center">
          <MapPin className="h-8 w-8 animate-spin mx-auto mb-2" />
          <p>Loading locations...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-fantasy font-bold">Location Builder</h2>
          <p className="text-muted-foreground">Create and manage locations for your campaigns</p>
        </div>
        <Dialog open={isCreateOpen} onOpenChange={setIsCreateOpen}>
          <DialogTrigger asChild>
            <Button onClick={() => setEditingLocation(null)}>
              <Plus className="h-4 w-4 mr-2" />
              Create Location
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>{editingLocation ? 'Edit Location' : 'Create New Location'}</DialogTitle>
              <DialogDescription>
                Design a location for your campaign world
              </DialogDescription>
            </DialogHeader>

            <div className="space-y-4">
              {/* AI Generation Prompt */}
              <div>
                <Label htmlFor="ai-prompt">AI Generation Prompt</Label>
                <Textarea
                  id="ai-prompt"
                  value={generationPrompt}
                  onChange={(e) => setGenerationPrompt(e.target.value)}
                  placeholder="Describe the kind of location you want to generate with AI"
                  rows={2}
                />
                <Button
                  onClick={generateLocationWithAI}
                  disabled={isGenerating}
                  className="mt-2 w-full"
                >
                  {isGenerating ? 'Generating...' : 'Generate with AI'}
                </Button>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="name">Location Name</Label>
                  <Input
                    id="name"
                    value={formData.name || ''}
                    onChange={(e) => setFormData({...formData, name: e.target.value})}
                    placeholder="Enter location name"
                  />
                </div>
                <div>
                  <Label htmlFor="type">Location Type</Label>
                  <Select value={formData.type} onValueChange={(value) => setFormData({...formData, type: value as Location['type']})}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select type" />
                    </SelectTrigger>
                    <SelectContent>
                      {locationTypes.map(type => (
                        <SelectItem key={type.value} value={type.value}>
                          {type.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div>
                <Label htmlFor="description">Description</Label>
                <Textarea
                  id="description"
                  value={formData.description || ''}
                  onChange={(e) => setFormData({...formData, description: e.target.value})}
                  placeholder="Describe the location's appearance and atmosphere"
                  rows={3}
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="inhabitants">Inhabitants</Label>
                  <Textarea
                    id="inhabitants"
                    value={formData.inhabitants || ''}
                    onChange={(e) => setFormData({...formData, inhabitants: e.target.value})}
                    placeholder="Who lives or frequents this location?"
                    rows={2}
                  />
                </div>
                <div>
                  <Label htmlFor="atmosphere">Atmosphere</Label>
                  <Textarea
                    id="atmosphere"
                    value={formData.atmosphere || ''}
                    onChange={(e) => setFormData({...formData, atmosphere: e.target.value})}
                    placeholder="What's the mood and feeling of this place?"
                    rows={2}
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="dangers">Dangers</Label>
                  <Textarea
                    id="dangers"
                    value={formData.dangers || ''}
                    onChange={(e) => setFormData({...formData, dangers: e.target.value})}
                    placeholder="What threats or hazards exist here?"
                    rows={2}
                  />
                </div>
                <div>
                  <Label htmlFor="treasures">Treasures</Label>
                  <Textarea
                    id="treasures"
                    value={formData.treasures || ''}
                    onChange={(e) => setFormData({...formData, treasures: e.target.value})}
                    placeholder="What valuable items or rewards can be found?"
                    rows={2}
                  />
                </div>
              </div>

              <div>
                <Label htmlFor="secrets">Secrets</Label>
                <Textarea
                  id="secrets"
                  value={formData.secrets || ''}
                  onChange={(e) => setFormData({...formData, secrets: e.target.value})}
                  placeholder="Hidden information or plot hooks"
                  rows={2}
                />
              </div>

              <div>
                <Label htmlFor="difficulty">Difficulty Level</Label>
                <Select value={formData.difficulty} onValueChange={(value) => setFormData({...formData, difficulty: value as Location['difficulty']})}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select difficulty" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="easy">Easy</SelectItem>
                    <SelectItem value="medium">Medium</SelectItem>
                    <SelectItem value="hard">Hard</SelectItem>
                    <SelectItem value="legendary">Legendary</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="flex justify-end space-x-2 pt-4">
                <Button variant="outline" onClick={resetForm}>Cancel</Button>
                <Button onClick={handleCreate} disabled={isSaving}>
                  {editingLocation ? 'Update Location' : 'Create Location'}
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {locations.map((location) => (
          <Card key={location.id} className="hover:shadow-md transition-shadow">
            <CardHeader className="pb-3">
              <div className="flex justify-between items-start">
                <CardTitle className="font-fantasy">{location.name}</CardTitle>
                <Badge variant="outline">{location.type}</Badge>
              </div>
            </CardHeader>
            <CardContent className="pt-0 space-y-3">
              <p className="text-sm">
                {location.description.length > 100
                  ? location.description.substring(0, 100) + "..."
                  : location.description}
              </p>

              {location.inhabitants && (
                <div>
                  <span className="text-xs font-medium text-muted-foreground">Inhabitants:</span>
                  <p className="text-xs">{location.inhabitants}</p>
                </div>
              )}

              {location.dangers && (
                <div>
                  <span className="text-xs font-medium text-muted-foreground">Dangers:</span>
                  <p className="text-xs text-red-600">{location.dangers}</p>
                </div>
              )}

              <div className="flex justify-between items-center pt-2">
                <Badge variant={location.difficulty === 'easy' ? 'default' : location.difficulty === 'medium' ? 'secondary' : location.difficulty === 'hard' ? 'destructive' : 'outline'}>
                  {location.difficulty}
                </Badge>
                <div className="flex space-x-1">
                  <Button size="sm" variant="outline" onClick={() => handleEdit(location)}>
                    <Edit className="h-3 w-3" />
                  </Button>
                  <Button size="sm" variant="outline" onClick={() => handleDelete(location.id)}>
                    <Trash2 className="h-3 w-3" />
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {locations.length === 0 && (
        <Card className="text-center py-12">
          <CardContent>
            <MapPin className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
            <h3 className="text-lg font-semibold mb-2">No Locations Yet</h3>
            <p className="text-muted-foreground mb-4">
              Create your first location to start building your campaign world.
            </p>
            <Button onClick={() => setIsCreateOpen(true)}>
              <Plus className="h-4 w-4 mr-2" />
              Create Your First Location
            </Button>
          </CardContent>
        </Card>
      )}
    </div>
  );
}