import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { ScrollText, Plus, Edit, Trash2, CheckCircle, Clock, Star, Swords, Heart, Crown } from 'lucide-react';
import { useToast } from "@/hooks/use-toast";

interface Quest {
  id: string;
  title: string;
  type: 'main' | 'side' | 'personal' | 'bounty' | 'exploration' | 'delivery' | 'rescue';
  description: string;
  objectives: string[];
  rewards: {
    xp: number;
    gold: number;
    items: string[];
  };
  difficulty: 'easy' | 'medium' | 'hard' | 'deadly';
  status: 'available' | 'active' | 'completed' | 'failed';
  location: string;
  npcGiver: string;
  timeLimit?: string;
  prerequisites: string[];
  consequences: string;
}

const questTypes = [
  { value: 'main', label: 'Main Quest', icon: Crown },
  { value: 'side', label: 'Side Quest', icon: Star },
  { value: 'personal', label: 'Personal Quest', icon: Heart },
  { value: 'bounty', label: 'Bounty/Hunt', icon: Swords },
  { value: 'exploration', label: 'Exploration', icon: ScrollText },
  { value: 'delivery', label: 'Delivery', icon: ScrollText },
  { value: 'rescue', label: 'Rescue Mission', icon: Heart }
];

export default function QuestsTab() {
  const { toast } = useToast();
  const [quests, setQuests] = useState<Quest[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  const [isCreateOpen, setIsCreateOpen] = useState(false);
  const [editingQuest, setEditingQuest] = useState<Quest | null>(null);
  const [formData, setFormData] = useState<Partial<Quest>>({
    title: '',
    type: 'side',
    description: '',
    objectives: [''],
    rewards: { xp: 0, gold: 0, items: [] },
    difficulty: 'medium',
    status: 'available',
    location: '',
    npcGiver: '',
    prerequisites: [],
    consequences: ''
  });

  // Load quests from server
  React.useEffect(() => {
    const loadQuests = async () => {
      try {
        const response = await fetch('/api/dm-toolkit/quests', {
          credentials: 'include'
        });
        if (response.ok) {
          const serverQuests = await response.json();
          const formattedQuests = serverQuests.map((quest: any) => ({
            id: quest.id.toString(),
            title: quest.title,
            description: quest.description,
            ...JSON.parse(quest.details || '{}')
          }));
          setQuests(formattedQuests);
        }
      } catch (error) {
        console.error('Failed to load quests:', error);
        toast({
          title: "Error",
          description: "Failed to load quests",
          variant: "destructive"
        });
      } finally {
        setIsLoading(false);
      }
    };

    loadQuests();
  }, [toast]);

  const handleCreate = async () => {
    if (!formData.title || !formData.description) {
      toast({
        title: "Error",
        description: "Title and description are required",
        variant: "destructive"
      });
      return;
    }

    try {
      const response = await fetch('/api/dm-toolkit/quests', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify(formData)
      });

      if (response.ok) {
        const serverQuest = await response.json();
        const newQuest: Quest = {
          id: serverQuest.id.toString(),
          title: serverQuest.title,
          description: serverQuest.description,
          ...JSON.parse(serverQuest.details)
        };

        setQuests([...quests, newQuest]);
        resetForm();
        setIsCreateOpen(false);

        toast({
          title: "Quest Created",
          description: `${newQuest.title} has been added to your quest log.`
        });
      } else {
        throw new Error('Failed to create quest');
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to create quest",
        variant: "destructive"
      });
    }
  };

  const resetForm = () => {
    setFormData({
      title: '',
      type: 'side',
      description: '',
      objectives: [''],
      rewards: { xp: 0, gold: 0, items: [] },
      difficulty: 'medium',
      status: 'available',
      location: '',
      npcGiver: '',
      prerequisites: [],
      consequences: ''
    });
  };

  const handleEdit = (quest: Quest) => {
    setEditingQuest(quest);
    setFormData(quest);
    setIsCreateOpen(true);
  };

  const handleUpdate = async () => {
    if (!editingQuest) return;

    try {
      const response = await fetch(`/api/dm-toolkit/quests/${editingQuest.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify(formData)
      });

      if (response.ok) {
        const updatedServerQuest = await response.json();
        const updatedQuest: Quest = {
          id: updatedServerQuest.id.toString(),
          title: updatedServerQuest.title,
          description: updatedServerQuest.description,
          ...JSON.parse(updatedServerQuest.details)
        };

        const updatedQuests = quests.map(quest =>
          quest.id === editingQuest.id ? updatedQuest : quest
        );
        setQuests(updatedQuests);
        setEditingQuest(null);
        setIsCreateOpen(false);

        toast({
          title: "Quest Updated",
          description: `${updatedQuest.title} has been updated.`
        });
      } else {
        throw new Error('Failed to update quest');
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to update quest",
        variant: "destructive"
      });
    }
  };

  const handleDelete = async (id: string) => {
    try {
      const response = await fetch(`/api/dm-toolkit/quests/${id}`, {
        method: 'DELETE',
        credentials: 'include'
      });

      if (response.ok) {
        setQuests(quests.filter(quest => quest.id !== id));
        toast({
          title: "Quest Deleted",
          description: "Quest has been removed from your quest log."
        });
      } else {
        throw new Error('Failed to delete quest');
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to delete quest",
        variant: "destructive"
      });
    }
  };

  const updateQuestStatus = (id: string, status: Quest['status']) => {
    setQuests(quests.map(quest =>
      quest.id === id ? { ...quest, status } : quest
    ));
  };

  const addObjective = () => {
    setFormData({
      ...formData,
      objectives: [...(formData.objectives || []), '']
    });
  };

  const updateObjective = (index: number, value: string) => {
    const objectives = [...(formData.objectives || [])];
    objectives[index] = value;
    setFormData({ ...formData, objectives });
  };

  const removeObjective = (index: number) => {
    const objectives = formData.objectives?.filter((_, i) => i !== index) || [];
    setFormData({ ...formData, objectives });
  };

  const generateRandomQuest = () => {
    const templates = {
      side: [
        {
          title: 'The Missing Merchant',
          description: 'A local merchant has gone missing on the trade route. Find them and ensure their safe return.',
          objectives: ['Investigate the trade route', 'Search for clues', 'Locate the merchant', 'Ensure safe return'],
          location: 'Trade Route',
          npcGiver: 'Guild Master'
        },
        {
          title: 'Herb Collection',
          description: 'Gather rare healing herbs from the dangerous marshlands for a local healer.',
          objectives: ['Travel to the marshlands', 'Collect 5 rare herbs', 'Return safely'],
          location: 'Misty Marshlands',
          npcGiver: 'Village Healer'
        }
      ],
      bounty: [
        {
          title: 'Bandit Leader Bounty',
          description: 'A notorious bandit leader has been terrorizing travelers. Bring them to justice.',
          objectives: ['Locate the bandit hideout', 'Defeat or capture the leader', 'Return for reward'],
          location: 'Bandit Hideout',
          npcGiver: 'Town Sheriff'
        }
      ]
    };

    const questType = formData.type as keyof typeof templates;
    const typeTemplates = templates[questType] || templates.side;
    const template = typeTemplates[Math.floor(Math.random() * typeTemplates.length)];

    setFormData({
      ...formData,
      ...template,
      rewards: { xp: 500, gold: 100, items: [] },
      consequences: 'Reputation with the quest giver will be affected'
    });
  };

  const getTypeIcon = (type: string) => {
    const typeInfo = questTypes.find(t => t.value === type);
    const IconComponent = typeInfo?.icon || ScrollText;
    return <IconComponent className="h-4 w-4" />;
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'available': return 'bg-blue-100 text-blue-800';
      case 'active': return 'bg-green-100 text-green-800';
      case 'completed': return 'bg-gray-100 text-gray-800';
      case 'failed': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case 'easy': return 'bg-green-100 text-green-800';
      case 'medium': return 'bg-yellow-100 text-yellow-800';
      case 'hard': return 'bg-orange-100 text-orange-800';
      case 'deadly': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-fantasy font-bold">Quest Manager</h2>
          <p className="text-muted-foreground">Create and track quests for your campaigns</p>
        </div>
        <Dialog open={isCreateOpen} onOpenChange={setIsCreateOpen}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="h-4 w-4 mr-2" />
              Create Quest
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-3xl max-h-[80vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>{editingQuest ? 'Edit Quest' : 'Create New Quest'}</DialogTitle>
              <DialogDescription>
                Design a quest for your campaign
              </DialogDescription>
            </DialogHeader>

            <div className="grid gap-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="title">Quest Title</Label>
                  <Input
                    id="title"
                    value={formData.title}
                    onChange={(e) => setFormData({...formData, title: e.target.value})}
                    placeholder="Enter quest title"
                  />
                </div>
                <div>
                  <Label htmlFor="type">Quest Type</Label>
                  <Select value={formData.type} onValueChange={(value) => setFormData({...formData, type: value as Quest['type']})}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {questTypes.map((type) => (
                        <SelectItem key={type.value} value={type.value}>
                          <div className="flex items-center">
                            <type.icon className="h-4 w-4 mr-2" />
                            {type.label}
                          </div>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div>
                <Label htmlFor="description">Description</Label>
                <Textarea
                  id="description"
                  value={formData.description}
                  onChange={(e) => setFormData({...formData, description: e.target.value})}
                  placeholder="Describe the quest and its background"
                  rows={3}
                />
              </div>

              <div>
                <Label>Objectives</Label>
                {formData.objectives?.map((objective, index) => (
                  <div key={index} className="flex gap-2 mb-2">
                    <Input
                      value={objective}
                      onChange={(e) => updateObjective(index, e.target.value)}
                      placeholder={`Objective ${index + 1}`}
                    />
                    <Button
                      type="button"
                      variant="outline"
                      size="sm"
                      onClick={() => removeObjective(index)}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                ))}
                <Button type="button" variant="outline" onClick={addObjective}>
                  <Plus className="h-4 w-4 mr-2" />
                  Add Objective
                </Button>
              </div>

              <div className="grid grid-cols-3 gap-4">
                <div>
                  <Label htmlFor="difficulty">Difficulty</Label>
                  <Select value={formData.difficulty} onValueChange={(value) => setFormData({...formData, difficulty: value as Quest['difficulty']})}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="easy">Easy</SelectItem>
                      <SelectItem value="medium">Medium</SelectItem>
                      <SelectItem value="hard">Hard</SelectItem>
                      <SelectItem value="deadly">Deadly</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="status">Status</Label>
                  <Select value={formData.status} onValueChange={(value) => setFormData({...formData, status: value as Quest['status']})}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="available">Available</SelectItem>
                      <SelectItem value="active">Active</SelectItem>
                      <SelectItem value="completed">Completed</SelectItem>
                      <SelectItem value="failed">Failed</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="location">Location</Label>
                  <Input
                    id="location"
                    value={formData.location}
                    onChange={(e) => setFormData({...formData, location: e.target.value})}
                    placeholder="Quest location"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="npcGiver">Quest Giver</Label>
                  <Input
                    id="npcGiver"
                    value={formData.npcGiver}
                    onChange={(e) => setFormData({...formData, npcGiver: e.target.value})}
                    placeholder="NPC who gives this quest"
                  />
                </div>
                <div>
                  <Label htmlFor="timeLimit">Time Limit (optional)</Label>
                  <Input
                    id="timeLimit"
                    value={formData.timeLimit || ''}
                    onChange={(e) => setFormData({...formData, timeLimit: e.target.value})}
                    placeholder="e.g., 3 days, 1 week"
                  />
                </div>
              </div>

              <div className="grid grid-cols-3 gap-4">
                <div>
                  <Label htmlFor="xp">XP Reward</Label>
                  <Input
                    id="xp"
                    type="number"
                    value={formData.rewards?.xp || 0}
                    onChange={(e) => setFormData({
                      ...formData,
                      rewards: { ...formData.rewards!, xp: parseInt(e.target.value) || 0 }
                    })}
                  />
                </div>
                <div>
                  <Label htmlFor="gold">Gold Reward</Label>
                  <Input
                    id="gold"
                    type="number"
                    value={formData.rewards?.gold || 0}
                    onChange={(e) => setFormData({
                      ...formData,
                      rewards: { ...formData.rewards!, gold: parseInt(e.target.value) || 0 }
                    })}
                  />
                </div>
                <div>
                  <Label htmlFor="items">Item Rewards</Label>
                  <Input
                    id="items"
                    value={formData.rewards?.items?.join(', ') || ''}
                    onChange={(e) => setFormData({
                      ...formData,
                      rewards: { ...formData.rewards!, items: e.target.value.split(',').map(item => item.trim()).filter(Boolean) }
                    })}
                    placeholder="Separate with commas"
                  />
                </div>
              </div>

              <div>
                <Label htmlFor="consequences">Consequences</Label>
                <Textarea
                  id="consequences"
                  value={formData.consequences}
                  onChange={(e) => setFormData({...formData, consequences: e.target.value})}
                  placeholder="What happens if the quest fails or is ignored?"
                  rows={2}
                />
              </div>

              <div className="flex gap-2">
                <Button variant="outline" onClick={generateRandomQuest}>
                  Generate Random
                </Button>
                <Button onClick={editingQuest ? handleUpdate : handleCreate}>
                  {editingQuest ? 'Update Quest' : 'Create Quest'}
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {quests.map((quest) => (
          <Card key={quest.id} className="hover:shadow-md transition-shadow">
            <CardHeader className="pb-3">
              <div className="flex items-start justify-between">
                <div className="flex items-center space-x-2">
                  {getTypeIcon(quest.type)}
                  <CardTitle className="text-lg">{quest.title}</CardTitle>
                </div>
                <div className="flex flex-col gap-1">
                  <Badge className={getStatusColor(quest.status)}>
                    {quest.status}
                  </Badge>
                  <Badge className={getDifficultyColor(quest.difficulty)}>
                    {quest.difficulty}
                  </Badge>
                </div>
              </div>
              <CardDescription className="flex items-center space-x-1">
                <Badge variant="outline">{questTypes.find(t => t.value === quest.type)?.label}</Badge>
                {quest.location && <Badge variant="outline">{quest.location}</Badge>}
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-3">
              <p className="text-sm">{quest.description}</p>

              <div>
                <span className="text-xs font-medium text-muted-foreground">Objectives:</span>
                <ul className="text-xs list-disc list-inside mt-1">
                  {quest.objectives.map((objective, index) => (
                    <li key={index}>{objective}</li>
                  ))}
                </ul>
              </div>

              <div>
                <span className="text-xs font-medium text-muted-foreground">Rewards:</span>
                <p className="text-xs">{quest.rewards.xp} XP, {quest.rewards.gold} gold</p>
                {quest.rewards.items.length > 0 && (
                  <p className="text-xs">{quest.rewards.items.join(', ')}</p>
                )}
              </div>

              <div className="flex justify-between items-center pt-2">
                <Select value={quest.status} onValueChange={(status) => updateQuestStatus(quest.id, status as Quest['status'])}>
                  <SelectTrigger className="w-24 h-7 text-xs">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="available">Available</SelectItem>
                    <SelectItem value="active">Active</SelectItem>
                    <SelectItem value="completed">Completed</SelectItem>
                    <SelectItem value="failed">Failed</SelectItem>
                  </SelectContent>
                </Select>

                <div className="flex space-x-1">
                  <Button size="sm" variant="outline" onClick={() => handleEdit(quest)}>
                    <Edit className="h-3 w-3" />
                  </Button>
                  <Button size="sm" variant="outline" onClick={() => handleDelete(quest.id)}>
                    <Trash2 className="h-3 w-3" />
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {!isLoading && quests.length === 0 && (
        <Card className="text-center py-12">
          <CardContent>
            <ScrollText className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
            <h3 className="text-lg font-semibold mb-2">No Quests Yet</h3>
            <p className="text-muted-foreground mb-4">
              Create your first quest to start building adventures for your players.
            </p>
            <Button onClick={() => setIsCreateOpen(true)}>
              <Plus className="h-4 w-4 mr-2" />
              Create Your First Quest
            </Button>
          </CardContent>
        </Card>
      )}
    </div>
  );
}