import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Save, Download, Upload, Wand2, MapPin, Users, Scroll, Sword } from "lucide-react";

interface GeneratedContent {
  id: string;
  type: 'location' | 'npc' | 'quest' | 'item' | 'encounter';
  title: string;
  content: string;
  tags: string[];
  createdAt: string;
}

export default function AIAssistantTab() {
  const [prompt, setPrompt] = useState('');
  const [generatedContent, setGeneratedContent] = useState<GeneratedContent[]>([]);
  const [isGenerating, setIsGenerating] = useState(false);
  const [savedContent, setSavedContent] = useState<GeneratedContent[]>([]);

  const generateContent = async (type: string) => {
    setIsGenerating(true);
    try {
      const response = await fetch(`/api/openai/generate-${type}`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        credentials: 'include',
        body: JSON.stringify({
          prompt: prompt,
          [type === 'location' ? 'locationType' : 'contentType']: type
        })
      });

      if (!response.ok) {
        throw new Error(`Failed to generate ${type}`);
      }

      const result = await response.json();

      const newContent: GeneratedContent = {
        id: Date.now().toString(),
        type: type as any,
        title: result.name || result.title || `Generated ${type}`,
        content: result.description || result.content || `AI-generated ${type} content`,
        tags: [type, 'ai-generated', 'unsaved'],
        createdAt: new Date().toISOString()
      };

      setGeneratedContent(prev => [newContent, ...prev]);
    } catch (error) {
      console.error('Error generating content:', error);
      // Fallback to mock content if API fails
      const fallbackContent: GeneratedContent = {
        id: Date.now().toString(),
        type: type as any,
        title: `Generated ${type}`,
        content: `AI generation failed. Prompt was: "${prompt}"`,
        tags: [type, 'fallback', 'unsaved'],
        createdAt: new Date().toISOString()
      };
      setGeneratedContent(prev => [fallbackContent, ...prev]);
    } finally {
      setIsGenerating(false);
    }
  };

  const saveContent = async (content: GeneratedContent) => {
    try {
      let endpoint = '';
      let requestData: any = {};

      switch (content.type) {
        case 'item':
          endpoint = '/api/dm-toolkit/items';
          requestData = {
            name: content.title,
            description: content.content,
            type: 'wondrous',
            rarity: 'uncommon',
            properties: [],
            attunement: false,
            value: 0,
            weight: 0,
            mechanics: content.content,
            lore: '',
            createdBy: 1, // Will be set by server
            isPublic: false
          };
          break;

        case 'monster':
          endpoint = '/api/dm-toolkit/monsters';
          requestData = {
            name: content.title,
            description: content.content,
            type: 'beast',
            size: 'medium',
            challengeRating: '1',
            armorClass: 12,
            hitPoints: 20,
            speed: '30 ft',
            stats: {
              strength: 10,
              dexterity: 10,
              constitution: 10,
              intelligence: 10,
              wisdom: 10,
              charisma: 10
            },
            skills: [],
            resistances: [],
            immunities: [],
            senses: [],
            languages: [],
            abilities: [],
            actions: [],
            environment: [],
            lore: content.content,
            createdBy: 1, // Will be set by server
            isPublic: false
          };
          break;

        case 'location':
          endpoint = '/api/dm-toolkit/locations';
          requestData = {
            name: content.title,
            description: content.content,
            type: 'settlement',
            size: 'medium',
            population: 100,
            government: 'unknown',
            economy: 'mixed',
            defenses: 'minimal',
            features: [],
            npcs: [],
            quests: [],
            secrets: '',
            atmosphere: content.content,
            createdBy: 1, // Will be set by server
            isPublic: false
          };
          break;

        case 'quest':
          endpoint = '/api/dm-toolkit/quests';
          requestData = {
            title: content.title,
            description: content.content,
            type: 'main',
            difficulty: 'medium',
            estimatedDuration: '2-3 hours',
            level: 1,
            objectives: [],
            rewards: {
              experience: 100,
              gold: 50,
              items: []
            },
            prerequisites: [],
            locations: [],
            npcs: [],
            hooks: content.content,
            notes: '',
            createdBy: 1, // Will be set by server
            isPublic: false
          };
          break;

        case 'npc':
          endpoint = '/api/dm-toolkit/npcs';
          requestData = {
            name: content.title,
            description: content.content,
            race: 'human',
            occupation: 'commoner',
            personality: content.content,
            appearance: content.content,
            motivation: 'unknown',
            voice: '',
            quirks: [],
            relationships: [],
            secrets: '',
            stats: {
              level: 1,
              hitPoints: 8,
              armorClass: 10,
              abilities: {
                strength: 10,
                dexterity: 10,
                constitution: 10,
                intelligence: 10,
                wisdom: 10,
                charisma: 10
              }
            },
            createdBy: 1, // Will be set by server
            isPublic: false
          };
          break;

        default:
          throw new Error(`Unsupported content type: ${content.type}`);
      }

      const response = await fetch(endpoint, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        credentials: 'include',
        body: JSON.stringify(requestData)
      });

      if (!response.ok) {
        const errorText = await response.text();
        throw new Error(`Failed to save ${content.type}: ${errorText}`);
      }

      const result = await response.json();

      // Update the content to show it's saved
      const updatedContent = {
        ...content,
        tags: [...content.tags.filter(tag => tag !== 'unsaved'), 'saved']
      };

      setGeneratedContent(prev => 
        prev.map(item => 
          item.id === content.id ? updatedContent : item
        )
      );

    } catch (error) {
      console.error(`Error saving ${content.type}:`, error);
      // Add error indicator to content
      const errorContent = {
        ...content,
        tags: [...content.tags.filter(tag => tag !== 'unsaved'), 'save-failed']
      };

      setGeneratedContent(prev => 
        prev.map(item => 
          item.id === content.id ? errorContent : item
        )
      );
    }
  };

  const exportContent = () => {
    const dataStr = JSON.stringify(savedContent, null, 2);
    const dataBlob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(dataBlob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'dm-assistant-content.json';
    link.click();
  };

  const importContent = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        try {
          const imported = JSON.parse(e.target?.result as string);
          setSavedContent(prev => [...prev, ...imported]);
        } catch (error) {
          console.error('Error importing content:', error);
        }
      };
      reader.readAsText(file);
    }
  };

  const getIcon = (type: string) => {
    switch (type) {
      case 'location': return <MapPin className="w-4 h-4" />;
      case 'npc': return <Users className="w-4 h-4" />;
      case 'quest': return <Scroll className="w-4 h-4" />;
      case 'item': return <Sword className="w-4 h-4" />;
      default: return <Wand2 className="w-4 h-4" />;
    }
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Wand2 className="w-5 h-5" />
            AI Assistant
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Textarea
              placeholder="Describe what you want to generate (e.g., 'A mysterious tavern in a port city with secrets')"
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              rows={3}
            />
          </div>

          <div className="flex gap-2 flex-wrap">
            <Button
              onClick={() => generateContent('location')}
              disabled={isGenerating || !prompt.trim()}
              size="sm"
            >
              <MapPin className="w-4 h-4 mr-2" />
              Generate Location
            </Button>
            <Button
              onClick={() => generateContent('npc')}
              disabled={isGenerating || !prompt.trim()}
              size="sm"
            >
              <Users className="w-4 h-4 mr-2" />
              Generate NPC
            </Button>
            <Button
              onClick={() => generateContent('quest')}
              disabled={isGenerating || !prompt.trim()}
              size="sm"
            >
              <Scroll className="w-4 h-4 mr-2" />
              Generate Quest
            </Button>
            <Button
              onClick={() => generateContent('item')}
              disabled={isGenerating || !prompt.trim()}
              size="sm"
            >
              <Sword className="w-4 h-4 mr-2" />
              Generate Item
            </Button>
          </div>
        </CardContent>
      </Card>

      <Tabs defaultValue="generated" className="w-full">
        <TabsList>
          <TabsTrigger value="generated">Generated Content</TabsTrigger>
          <TabsTrigger value="saved">Saved Content</TabsTrigger>
        </TabsList>

        <TabsContent value="generated" className="space-y-4">
          {generatedContent.length === 0 ? (
            <Card>
              <CardContent className="pt-6">
                <p className="text-muted-foreground text-center">
                  No content generated yet. Enter a prompt above and click a generate button.
                </p>
              </CardContent>
            </Card>
          ) : (
            generatedContent.map((content) => (
              <Card key={content.id}>
                <CardHeader className="pb-3">
                  <div className="flex items-center justify-between">
                    <CardTitle className="flex items-center gap-2 text-lg">
                      {getIcon(content.type)}
                      {content.title}
                    </CardTitle>
                    <Button
                    size="sm"
                    onClick={() => saveContent(content)}
                    disabled={content.tags.includes('saved')}
                    className={
                      content.tags.includes('saved') 
                        ? "bg-gray-400" 
                        : content.tags.includes('save-failed')
                        ? "bg-red-600 hover:bg-red-700"
                        : "bg-green-600 hover:bg-green-700"
                    }
                  >
                    {content.tags.includes('saved') 
                      ? 'Saved' 
                      : content.tags.includes('save-failed')
                      ? 'Retry Save'
                      : 'Save'
                    }
                  </Button>
                  </div>
                  <div className="flex gap-2">
                    {content.tags.map((tag) => (
                      <Badge key={tag} variant="secondary">
                        {tag}
                      </Badge>
                    ))}
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-sm">{content.content}</p>
                </CardContent>
              </Card>
            ))
          )}
        </TabsContent>

        <TabsContent value="saved" className="space-y-4">
          <div className="flex gap-2">
            <Button onClick={exportContent} size="sm" variant="outline">
              <Download className="w-4 h-4 mr-2" />
              Export All
            </Button>
            <div>
              <Input
                type="file"
                accept=".json"
                onChange={importContent}
                className="hidden"
                id="import-content"
              />
              <Button asChild size="sm" variant="outline">
                <label htmlFor="import-content" className="cursor-pointer flex items-center">
                  <Upload className="w-4 h-4 mr-2" />
                  Import
                </label>
              </Button>
            </div>
          </div>

          {savedContent.length === 0 ? (
            <Card>
              <CardContent className="pt-6">
                <p className="text-muted-foreground text-center">
                  No saved content yet. Generate and save content to see it here.
                </p>
              </CardContent>
            </Card>
          ) : (
            savedContent.map((content) => (
              <Card key={content.id}>
                <CardHeader className="pb-3">
                  <CardTitle className="flex items-center gap-2 text-lg">
                    {getIcon(content.type)}
                    {content.title}
                  </CardTitle>
                  <div className="flex gap-2">
                    {content.tags.map((tag) => (
                      <Badge key={tag} variant="secondary">
                        {tag}
                      </Badge>
                    ))}
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-sm">{content.content}</p>
                </CardContent>
              </Card>
            ))
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}