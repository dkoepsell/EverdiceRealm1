
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Trash2, Plus, RotateCcw, Sword, Heart, Shield } from "lucide-react";

type Combatant = {
  id: string;
  name: string;
  initiative: number;
  hp: number;
  maxHp: number;
  ac: number;
  isPlayer: boolean;
  status: string[];
};

export default function InitiativeTracker() {
  const [combatants, setCombatants] = useState<Combatant[]>([]);
  const [currentTurn, setCurrentTurn] = useState(0);
  const [round, setRound] = useState(1);
  const [newCombatant, setNewCombatant] = useState({
    name: "",
    initiative: "",
    hp: "",
    maxHp: "",
    ac: "",
    isPlayer: false
  });

  const addCombatant = () => {
    if (!newCombatant.name || !newCombatant.initiative) return;
    
    const combatant: Combatant = {
      id: Date.now().toString(),
      name: newCombatant.name,
      initiative: parseInt(newCombatant.initiative),
      hp: parseInt(newCombatant.hp) || 1,
      maxHp: parseInt(newCombatant.maxHp) || parseInt(newCombatant.hp) || 1,
      ac: parseInt(newCombatant.ac) || 10,
      isPlayer: newCombatant.isPlayer,
      status: []
    };

    setCombatants(prev => [...prev, combatant].sort((a, b) => b.initiative - a.initiative));
    setNewCombatant({ name: "", initiative: "", hp: "", maxHp: "", ac: "", isPlayer: false });
  };

  const removeCombatant = (id: string) => {
    setCombatants(prev => prev.filter(c => c.id !== id));
  };

  const nextTurn = () => {
    if (combatants.length === 0) return;
    
    if (currentTurn >= combatants.length - 1) {
      setCurrentTurn(0);
      setRound(prev => prev + 1);
    } else {
      setCurrentTurn(prev => prev + 1);
    }
  };

  const updateHp = (id: string, newHp: number) => {
    setCombatants(prev => 
      prev.map(c => c.id === id ? { ...c, hp: Math.max(0, Math.min(c.maxHp, newHp)) } : c)
    );
  };

  const resetCombat = () => {
    setCurrentTurn(0);
    setRound(1);
    setCombatants([]);
  };

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Sword className="h-5 w-5" />
            Initiative Tracker
            <Badge variant="outline">Round {round}</Badge>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Add Combatant Form */}
          <div className="grid grid-cols-2 md:grid-cols-6 gap-2">
            <Input
              placeholder="Name"
              value={newCombatant.name}
              onChange={(e) => setNewCombatant(prev => ({ ...prev, name: e.target.value }))}
            />
            <Input
              placeholder="Initiative"
              type="number"
              value={newCombatant.initiative}
              onChange={(e) => setNewCombatant(prev => ({ ...prev, initiative: e.target.value }))}
            />
            <Input
              placeholder="HP"
              type="number"
              value={newCombatant.hp}
              onChange={(e) => setNewCombatant(prev => ({ ...prev, hp: e.target.value }))}
            />
            <Input
              placeholder="Max HP"
              type="number"
              value={newCombatant.maxHp}
              onChange={(e) => setNewCombatant(prev => ({ ...prev, maxHp: e.target.value }))}
            />
            <Input
              placeholder="AC"
              type="number"
              value={newCombatant.ac}
              onChange={(e) => setNewCombatant(prev => ({ ...prev, ac: e.target.value }))}
            />
            <Button onClick={addCombatant} size="sm">
              <Plus className="h-4 w-4" />
            </Button>
          </div>

          {/* Combatants List */}
          <div className="space-y-2">
            {combatants.map((combatant, index) => (
              <div
                key={combatant.id}
                className={`flex items-center justify-between p-3 rounded border ${
                  index === currentTurn ? 'bg-primary/10 border-primary' : 'bg-background'
                }`}
              >
                <div className="flex items-center gap-3">
                  <Badge variant={combatant.isPlayer ? "default" : "secondary"}>
                    {combatant.initiative}
                  </Badge>
                  <span className="font-medium">{combatant.name}</span>
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <Heart className="h-4 w-4" />
                    <span>{combatant.hp}/{combatant.maxHp}</span>
                    <Shield className="h-4 w-4" />
                    <span>{combatant.ac}</span>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => updateHp(combatant.id, combatant.hp - 1)}
                  >
                    -1
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => updateHp(combatant.id, combatant.hp + 1)}
                  >
                    +1
                  </Button>
                  <Button
                    variant="destructive"
                    size="sm"
                    onClick={() => removeCombatant(combatant.id)}
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            ))}
          </div>

          {/* Combat Controls */}
          <div className="flex gap-2">
            <Button onClick={nextTurn} disabled={combatants.length === 0}>
              Next Turn
            </Button>
            <Button variant="outline" onClick={resetCombat}>
              <RotateCcw className="h-4 w-4 mr-2" />
              Reset Combat
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
