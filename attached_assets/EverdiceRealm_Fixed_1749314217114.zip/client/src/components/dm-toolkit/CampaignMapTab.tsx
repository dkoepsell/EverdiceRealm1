
import React, { useState, useRef, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Map, Plus, Eye, Settings, Wand2 } from 'lucide-react';
import { useToast } from "@/hooks/use-toast";

interface HexCoordinate {
  q: number; // column
  r: number; // row
  s: number; // diagonal (q + r + s = 0)
}

interface MapLocation {
  id: string;
  name: string;
  type: 'city' | 'dungeon' | 'wilderness' | 'landmark' | 'ruins';
  hexCoord: HexCoordinate;
  description: string;
  discovered: boolean;
  currentParty?: boolean;
  connections: string[]; // IDs of connected locations
  travelTime: number; // in hours
  difficulty: 'safe' | 'moderate' | 'dangerous' | 'deadly';
}

interface CampaignMap {
  id: string;
  name: string;
  description: string;
  hexRadius: number; // map size in hexes from center
  locations: MapLocation[];
  scale: number; // miles per hex
}

const HEX_SIZE = 30;
const HEX_WIDTH = Math.sqrt(3) * HEX_SIZE;
const HEX_HEIGHT = 2 * HEX_SIZE;

export default function CampaignMapTab() {
  const { toast } = useToast();
  const svgRef = useRef<SVGSVGElement>(null);
  const [currentMap, setCurrentMap] = useState<CampaignMap | null>(null);
  const [selectedHex, setSelectedHex] = useState<HexCoordinate | null>(null);
  const [showLocationDialog, setShowLocationDialog] = useState(false);
  const [newLocation, setNewLocation] = useState({
    name: '',
    type: 'city' as MapLocation['type'],
    description: '',
    difficulty: 'safe' as MapLocation['difficulty'],
    travelTime: 4
  });
  const [viewMode, setViewMode] = useState<'dm' | 'player'>('dm');

  // Hex coordinate math
  const hexToPixel = (hex: HexCoordinate): { x: number; y: number } => {
    const x = HEX_SIZE * (Math.sqrt(3) * hex.q + Math.sqrt(3) / 2 * hex.r);
    const y = HEX_SIZE * (3 / 2 * hex.r);
    return { x: x + 400, y: y + 300 }; // offset to center
  };

  const pixelToHex = (x: number, y: number): HexCoordinate => {
    const adjustedX = x - 400;
    const adjustedY = y - 300;
    
    const q = (Math.sqrt(3) / 3 * adjustedX - 1 / 3 * adjustedY) / HEX_SIZE;
    const r = (2 / 3 * adjustedY) / HEX_SIZE;
    const s = -q - r;
    
    return cubeRound({ q, r, s });
  };

  const cubeRound = (hex: HexCoordinate): HexCoordinate => {
    let rq = Math.round(hex.q);
    let rr = Math.round(hex.r);
    let rs = Math.round(hex.s);
    
    const qDiff = Math.abs(rq - hex.q);
    const rDiff = Math.abs(rr - hex.r);
    const sDiff = Math.abs(rs - hex.s);
    
    if (qDiff > rDiff && qDiff > sDiff) {
      rq = -rr - rs;
    } else if (rDiff > sDiff) {
      rr = -rq - rs;
    } else {
      rs = -rq - rr;
    }
    
    return { q: rq, r: rr, s: rs };
  };

  const hexDistance = (a: HexCoordinate, b: HexCoordinate): number => {
    return (Math.abs(a.q - b.q) + Math.abs(a.q + a.r - b.q - b.r) + Math.abs(a.r - b.r)) / 2;
  };

  const generateHexPath = (center: { x: number; y: number }): string => {
    const angles = [0, 60, 120, 180, 240, 300];
    const points = angles.map(angle => {
      const rad = (angle * Math.PI) / 180;
      const x = center.x + HEX_SIZE * Math.cos(rad);
      const y = center.y + HEX_SIZE * Math.sin(rad);
      return `${x},${y}`;
    });
    return `M ${points.join(' L ')} Z`;
  };

  const handleHexClick = (hex: HexCoordinate) => {
    setSelectedHex(hex);
    const existingLocation = currentMap?.locations.find(loc => 
      loc.hexCoord.q === hex.q && loc.hexCoord.r === hex.r
    );
    
    if (existingLocation) {
      // Show location details
      toast({
        title: existingLocation.name,
        description: existingLocation.description
      });
    } else {
      // Show create location dialog
      setShowLocationDialog(true);
    }
  };

  const createLocation = () => {
    if (!selectedHex || !currentMap) return;
    
    const location: MapLocation = {
      id: Date.now().toString(),
      name: newLocation.name,
      type: newLocation.type,
      hexCoord: selectedHex,
      description: newLocation.description,
      discovered: viewMode === 'dm',
      connections: [],
      travelTime: newLocation.travelTime,
      difficulty: newLocation.difficulty
    };
    
    setCurrentMap({
      ...currentMap,
      locations: [...currentMap.locations, location]
    });
    
    setShowLocationDialog(false);
    setNewLocation({
      name: '',
      type: 'city',
      description: '',
      difficulty: 'safe',
      travelTime: 4
    });
    
    toast({
      title: "Location Created",
      description: `${location.name} has been added to the map.`
    });
  };

  const generateCampaignMap = async () => {
    const sampleMap: CampaignMap = {
      id: '1',
      name: 'The Realm of Eldoria',
      description: 'A diverse realm with ancient forests, towering mountains, and mysterious ruins.',
      hexRadius: 10,
      scale: 6, // 6 miles per hex
      locations: [
        {
          id: '1',
          name: 'Millbrook Village',
          type: 'city',
          hexCoord: { q: 0, r: 0, s: 0 },
          description: 'A peaceful farming village serving as the starting point for adventures.',
          discovered: true,
          currentParty: true,
          connections: ['2', '3'],
          travelTime: 0,
          difficulty: 'safe'
        },
        {
          id: '2',
          name: 'Whispering Woods',
          type: 'wilderness',
          hexCoord: { q: -1, r: 1, s: 0 },
          description: 'Ancient forest filled with mystical creatures and hidden paths.',
          discovered: true,
          connections: ['1', '4'],
          travelTime: 4,
          difficulty: 'moderate'
        },
        {
          id: '3',
          name: 'Ironhold Fortress',
          type: 'landmark',
          hexCoord: { q: 1, r: -1, s: 0 },
          description: 'An abandoned dwarven fortress built into the mountainside.',
          discovered: false,
          connections: ['1'],
          travelTime: 6,
          difficulty: 'dangerous'
        },
        {
          id: '4',
          name: 'The Sunken Temple',
          type: 'dungeon',
          hexCoord: { q: -2, r: 2, s: 0 },
          description: 'Ancient ruins partially submerged in a mystical lake.',
          discovered: false,
          connections: ['2'],
          travelTime: 8,
          difficulty: 'deadly'
        }
      ]
    };
    
    setCurrentMap(sampleMap);
    
    toast({
      title: "Campaign Map Generated",
      description: "A sample campaign map has been created with connected locations."
    });
  };

  const getLocationColor = (location: MapLocation): string => {
    if (location.currentParty) return '#3B82F6'; // blue for party location
    if (!location.discovered && viewMode === 'player') return '#6B7280'; // gray for undiscovered
    
    switch (location.type) {
      case 'city': return '#10B981'; // green
      case 'dungeon': return '#EF4444'; // red
      case 'wilderness': return '#84CC16'; // lime
      case 'landmark': return '#F59E0B'; // amber
      case 'ruins': return '#8B5CF6'; // purple
      default: return '#6B7280';
    }
  };

  const renderHexGrid = () => {
    if (!currentMap) return null;
    
    const hexes = [];
    const radius = currentMap.hexRadius;
    
    for (let q = -radius; q <= radius; q++) {
      const r1 = Math.max(-radius, -q - radius);
      const r2 = Math.min(radius, -q + radius);
      
      for (let r = r1; r <= r2; r++) {
        const s = -q - r;
        const hex = { q, r, s };
        const pixel = hexToPixel(hex);
        const path = generateHexPath(pixel);
        
        const location = currentMap.locations.find(loc => 
          loc.hexCoord.q === q && loc.hexCoord.r === r
        );
        
        const isVisible = viewMode === 'dm' || (location && location.discovered);
        
        hexes.push(
          <g key={`${q}-${r}`}>
            <path
              d={path}
              fill={location ? getLocationColor(location) : '#F3F4F6'}
              stroke="#D1D5DB"
              strokeWidth="1"
              opacity={isVisible ? 0.8 : 0.3}
              className="cursor-pointer hover:opacity-100"
              onClick={() => handleHexClick(hex)}
            />
            {location && isVisible && (
              <text
                x={pixel.x}
                y={pixel.y}
                textAnchor="middle"
                className="text-xs font-medium fill-white pointer-events-none"
                dy="0.3em"
              >
                {location.name.split(' ')[0]}
              </text>
            )}
          </g>
        );
      }
    }
    
    return hexes;
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-fantasy font-bold flex items-center">
            <Map className="mr-2 h-6 w-6 text-blue-500" />
            Campaign Map
          </h2>
          <p className="text-muted-foreground">Create and manage hexagonal campaign maps with geographic consistency</p>
        </div>
        <div className="flex gap-2">
          <Select value={viewMode} onValueChange={(value: 'dm' | 'player') => setViewMode(value)}>
            <SelectTrigger className="w-32">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="dm">DM View</SelectItem>
              <SelectItem value="player">Player View</SelectItem>
            </SelectContent>
          </Select>
          <Button onClick={generateCampaignMap}>
            <Wand2 className="h-4 w-4 mr-2" />
            Generate Map
          </Button>
        </div>
      </div>

      {currentMap ? (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2">
            <Card>
              <CardHeader>
                <CardTitle>{currentMap.name}</CardTitle>
                <CardDescription>
                  {currentMap.description} • Scale: {currentMap.scale} miles per hex
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="border rounded-lg overflow-hidden">
                  <svg
                    ref={svgRef}
                    width="800"
                    height="600"
                    viewBox="0 0 800 600"
                    className="w-full h-auto"
                  >
                    {renderHexGrid()}
                  </svg>
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Locations</CardTitle>
                <CardDescription>Discovered locations on the map</CardDescription>
              </CardHeader>
              <CardContent className="space-y-3">
                {currentMap.locations
                  .filter(loc => viewMode === 'dm' || loc.discovered)
                  .map(location => (
                    <div key={location.id} className="flex items-center justify-between p-2 border rounded">
                      <div>
                        <div className="font-medium">{location.name}</div>
                        <div className="text-xs text-muted-foreground">
                          {location.type} • {location.travelTime}h travel
                        </div>
                      </div>
                      <Badge
                        style={{ backgroundColor: getLocationColor(location) }}
                        className="text-white"
                      >
                        {location.difficulty}
                      </Badge>
                    </div>
                  ))}
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Map Legend</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                <div className="flex items-center gap-2">
                  <div className="w-4 h-4 rounded" style={{ backgroundColor: '#10B981' }}></div>
                  <span className="text-sm">Cities & Towns</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-4 h-4 rounded" style={{ backgroundColor: '#EF4444' }}></div>
                  <span className="text-sm">Dungeons</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-4 h-4 rounded" style={{ backgroundColor: '#84CC16' }}></div>
                  <span className="text-sm">Wilderness</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-4 h-4 rounded" style={{ backgroundColor: '#F59E0B' }}></div>
                  <span className="text-sm">Landmarks</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-4 h-4 rounded" style={{ backgroundColor: '#3B82F6' }}></div>
                  <span className="text-sm">Party Location</span>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      ) : (
        <Card className="text-center py-12">
          <CardContent>
            <Map className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
            <h3 className="text-lg font-semibold mb-2">No Campaign Map</h3>
            <p className="text-muted-foreground mb-4">
              Generate a campaign map to start tracking locations and maintaining geographic consistency.
            </p>
            <Button onClick={generateCampaignMap}>
              <Wand2 className="h-4 w-4 mr-2" />
              Generate Campaign Map
            </Button>
          </CardContent>
        </Card>
      )}

      {/* Create Location Dialog */}
      <Dialog open={showLocationDialog} onOpenChange={setShowLocationDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Create New Location</DialogTitle>
            <DialogDescription>
              Add a new location at the selected hex coordinate
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label htmlFor="location-name">Location Name</Label>
              <Input
                id="location-name"
                value={newLocation.name}
                onChange={(e) => setNewLocation({...newLocation, name: e.target.value})}
                placeholder="Enter location name"
              />
            </div>
            <div>
              <Label htmlFor="location-type">Type</Label>
              <Select value={newLocation.type} onValueChange={(value: MapLocation['type']) => setNewLocation({...newLocation, type: value})}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="city">City/Town</SelectItem>
                  <SelectItem value="dungeon">Dungeon</SelectItem>
                  <SelectItem value="wilderness">Wilderness</SelectItem>
                  <SelectItem value="landmark">Landmark</SelectItem>
                  <SelectItem value="ruins">Ruins</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="location-description">Description</Label>
              <Textarea
                id="location-description"
                value={newLocation.description}
                onChange={(e) => setNewLocation({...newLocation, description: e.target.value})}
                placeholder="Describe this location"
                rows={3}
              />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="difficulty">Difficulty</Label>
                <Select value={newLocation.difficulty} onValueChange={(value: MapLocation['difficulty']) => setNewLocation({...newLocation, difficulty: value})}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="safe">Safe</SelectItem>
                    <SelectItem value="moderate">Moderate</SelectItem>
                    <SelectItem value="dangerous">Dangerous</SelectItem>
                    <SelectItem value="deadly">Deadly</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="travel-time">Travel Time (hours)</Label>
                <Input
                  id="travel-time"
                  type="number"
                  value={newLocation.travelTime}
                  onChange={(e) => setNewLocation({...newLocation, travelTime: parseInt(e.target.value) || 0})}
                  min="0"
                />
              </div>
            </div>
            <Button onClick={createLocation} className="w-full">
              Create Location
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
