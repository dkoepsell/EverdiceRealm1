
import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Skull, Plus, Edit, Trash2, Zap, Heart, Shield, Swords } from 'lucide-react';
import { useToast } from "@/hooks/use-toast";

interface Monster {
  id: string;
  name: string;
  type: 'beast' | 'humanoid' | 'undead' | 'fiend' | 'celestial' | 'dragon' | 'fey' | 'elemental' | 'aberration' | 'giant' | 'monstrosity' | 'plant';
  size: 'tiny' | 'small' | 'medium' | 'large' | 'huge' | 'gargantuan';
  challengeRating: string;
  armorClass: number;
  hitPoints: number;
  speed: string;
  stats: {
    strength: number;
    dexterity: number;
    constitution: number;
    intelligence: number;
    wisdom: number;
    charisma: number;
  };
  skills: string[];
  resistances: string[];
  immunities: string[];
  senses: string[];
  languages: string[];
  abilities: Array<{
    name: string;
    description: string;
  }>;
  actions: Array<{
    name: string;
    description: string;
    damage?: string;
    toHit?: number;
  }>;
  description: string;
  environment: string[];
  lore: string;
}

const monsterTypes = [
  { value: 'beast', label: 'Beast' },
  { value: 'humanoid', label: 'Humanoid' },
  { value: 'undead', label: 'Undead' },
  { value: 'fiend', label: 'Fiend' },
  { value: 'celestial', label: 'Celestial' },
  { value: 'dragon', label: 'Dragon' },
  { value: 'fey', label: 'Fey' },
  { value: 'elemental', label: 'Elemental' },
  { value: 'aberration', label: 'Aberration' },
  { value: 'giant', label: 'Giant' },
  { value: 'monstrosity', label: 'Monstrosity' },
  { value: 'plant', label: 'Plant' }
];

const sizes = [
  { value: 'tiny', label: 'Tiny' },
  { value: 'small', label: 'Small' },
  { value: 'medium', label: 'Medium' },
  { value: 'large', label: 'Large' },
  { value: 'huge', label: 'Huge' },
  { value: 'gargantuan', label: 'Gargantuan' }
];

const challengeRatings = [
  '0', '1/8', '1/4', '1/2', '1', '2', '3', '4', '5', '6', '7', '8', '9', '10',
  '11', '12', '13', '14', '15', '16', '17', '18', '19', '20', '21', '22', '23', '24', '25', '26', '27', '28', '29', '30'
];

export default function MonstersTab() {
  const { toast } = useToast();
  const [monsters, setMonsters] = useState<Monster[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  // Load monsters from server
  React.useEffect(() => {
    const loadMonsters = async () => {
      try {
        const response = await fetch('/api/dm-toolkit/monsters', {
          credentials: 'include'
        });
        if (response.ok) {
          const serverMonsters = await response.json();
          const formattedMonsters = serverMonsters.map((monster: any) => ({
            id: monster.id.toString(),
            name: monster.name,
            description: monster.description,
            ...monster
          }));
          setMonsters(formattedMonsters);
        }
      } catch (error) {
        console.error('Failed to load monsters:', error);
        toast({
          title: "Error",
          description: "Failed to load monsters",
          variant: "destructive"
        });
      } finally {
        setIsLoading(false);
      }
    };

    loadMonsters();
  }, [toast]);

  const [isCreateOpen, setIsCreateOpen] = useState(false);
  const [editingMonster, setEditingMonster] = useState<Monster | null>(null);
  const [formData, setFormData] = useState<Partial<Monster>>({
    name: '',
    type: 'beast',
    size: 'medium',
    challengeRating: '1',
    armorClass: 12,
    hitPoints: 20,
    speed: '30 ft',
    stats: {
      strength: 10,
      dexterity: 10,
      constitution: 10,
      intelligence: 10,
      wisdom: 10,
      charisma: 10
    },
    skills: [],
    resistances: [],
    immunities: [],
    senses: [],
    languages: [],
    abilities: [],
    actions: [],
    description: '',
    environment: [],
    lore: ''
  });

  const handleCreate = async () => {
    if (!formData.name || !formData.description) {
      toast({
        title: "Error",
        description: "Name and description are required",
        variant: "destructive"
      });
      return;
    }

    try {
      const response = await fetch('/api/dm-toolkit/monsters', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify(formData)
      });

      if (response.ok) {
        const serverMonster = await response.json();
        const newMonster: Monster = {
          id: serverMonster.id.toString(),
          name: serverMonster.title,
          description: serverMonster.description,
          ...JSON.parse(serverMonster.details)
        };

        setMonsters([...monsters, newMonster]);
        resetForm();
        setIsCreateOpen(false);

        toast({
          title: "Monster Created",
          description: `${newMonster.name} has been added to your bestiary.`
        });
      } else {
        throw new Error('Failed to create monster');
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to create monster",
        variant: "destructive"
      });
    }
  };

  const resetForm = () => {
    setFormData({
      name: '',
      type: 'beast',
      size: 'medium',
      challengeRating: '1',
      armorClass: 12,
      hitPoints: 20,
      speed: '30 ft',
      stats: {
        strength: 10,
        dexterity: 10,
        constitution: 10,
        intelligence: 10,
        wisdom: 10,
        charisma: 10
      },
      skills: [],
      resistances: [],
      immunities: [],
      senses: [],
      languages: [],
      abilities: [],
      actions: [],
      description: '',
      environment: [],
      lore: ''
    });
  };

  const handleEdit = (monster: Monster) => {
    setEditingMonster(monster);
    setFormData(monster);
    setIsCreateOpen(true);
  };

  const handleUpdate = async () => {
    if (!editingMonster) return;

    try {
      const response = await fetch(`/api/dm-toolkit/monsters/${editingMonster.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify(formData)
      });

      if (response.ok) {
        const updatedServerMonster = await response.json();
        const updatedMonster: Monster = {
          id: updatedServerMonster.id.toString(),
          name: updatedServerMonster.title,
          description: updatedServerMonster.description,
          ...JSON.parse(updatedServerMonster.details)
        };

        const updatedMonsters = monsters.map(monster =>
          monster.id === editingMonster.id ? updatedMonster : monster
        );
        setMonsters(updatedMonsters);
        setEditingMonster(null);
        setIsCreateOpen(false);

        toast({
          title: "Monster Updated",
          description: `${updatedMonster.name} has been updated.`
        });
      } else {
        throw new Error('Failed to update monster');
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to update monster",
        variant: "destructive"
      });
    }
  };

  const handleDelete = async (id: string) => {
    try {
      const response = await fetch(`/api/dm-toolkit/monsters/${id}`, {
        method: 'DELETE',
        credentials: 'include'
      });

      if (response.ok) {
        setMonsters(monsters.filter(monster => monster.id !== id));
        toast({
          title: "Monster Deleted",
          description: "Monster has been removed from your bestiary."
        });
      } else {
        throw new Error('Failed to delete monster');
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to delete monster",
        variant: "destructive"
      });
    }
  };

  const addAbility = () => {
    setFormData({
      ...formData,
      abilities: [...(formData.abilities || []), { name: '', description: '' }]
    });
  };

  const updateAbility = (index: number, field: 'name' | 'description', value: string) => {
    const abilities = [...(formData.abilities || [])];
    abilities[index][field] = value;
    setFormData({ ...formData, abilities });
  };

  const removeAbility = (index: number) => {
    const abilities = formData.abilities?.filter((_, i) => i !== index) || [];
    setFormData({ ...formData, abilities });
  };

  const addAction = () => {
    setFormData({
      ...formData,
      actions: [...(formData.actions || []), { name: '', description: '', damage: '', toHit: 0 }]
    });
  };

  const updateAction = (index: number, field: keyof Monster['actions'][0], value: string | number) => {
    const actions = [...(formData.actions || [])];
    (actions[index] as any)[field] = value;
    setFormData({ ...formData, actions });
  };

  const removeAction = (index: number) => {
    const actions = formData.actions?.filter((_, i) => i !== index) || [];
    setFormData({ ...formData, actions });
  };

  const generateRandomMonster = () => {
    const templates = {
      beast: {
        names: ['Dire Wolf', 'Giant Spider', 'Owlbear', 'Displacer Beast'],
        descriptions: ['A large predatory animal', 'A monstrous creature of the wild', 'A fearsome beast']
      },
      undead: {
        names: ['Wraith', 'Skeleton Warrior', 'Zombie Brute', 'Specter'],
        descriptions: ['A restless spirit', 'Animated remains of the dead', 'An undead horror']
      },
      fey: {
        names: ['Dryad', 'Pixie Swarm', 'Treant', 'Blink Dog'],
        descriptions: ['A nature spirit', 'A magical woodland creature', 'A fey guardian']
      }
    };

    const monsterType = formData.type as keyof typeof templates;
    const template = templates[monsterType] || templates.beast;
    const randomName = template.names[Math.floor(Math.random() * template.names.length)];
    const randomDesc = template.descriptions[Math.floor(Math.random() * template.descriptions.length)];

    setFormData({
      ...formData,
      name: randomName,
      description: randomDesc,
      abilities: [{ name: 'Natural Ability', description: 'A natural trait of this creature.' }],
      actions: [{ name: 'Attack', description: 'A basic attack.', damage: '1d6+2', toHit: 4 }],
      lore: 'A creature with mysterious origins and ancient purpose.'
    });
  };

  const getCRColor = (cr: string) => {
    const crNum = cr.includes('/') ? parseFloat(cr.split('/')[0]) / parseFloat(cr.split('/')[1]) : parseFloat(cr);
    if (crNum <= 1) return 'bg-green-100 text-green-800';
    if (crNum <= 5) return 'bg-yellow-100 text-yellow-800';
    if (crNum <= 10) return 'bg-orange-100 text-orange-800';
    return 'bg-red-100 text-red-800';
  };

  const getStatModifier = (stat: number) => {
    return Math.floor((stat - 10) / 2);
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-fantasy font-bold">Monster Bestiary</h2>
          <p className="text-muted-foreground">Create and manage monsters for your campaigns</p>
        </div>
        <Dialog open={isCreateOpen} onOpenChange={setIsCreateOpen}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="h-4 w-4 mr-2" />
              Create Monster
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>{editingMonster ? 'Edit Monster' : 'Create New Monster'}</DialogTitle>
              <DialogDescription>
                Design a monster for your campaign
              </DialogDescription>
            </DialogHeader>

            <div className="grid gap-4">
              <div className="grid grid-cols-4 gap-4">
                <div>
                  <Label htmlFor="name">Monster Name</Label>
                  <Input
                    id="name"
                    value={formData.name}
                    onChange={(e) => setFormData({...formData, name: e.target.value})}
                    placeholder="Enter monster name"
                  />
                </div>
                <div>
                  <Label htmlFor="type">Type</Label>
                  <Select value={formData.type} onValueChange={(value) => setFormData({...formData, type: value as Monster['type']})}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {monsterTypes.map((type) => (
                        <SelectItem key={type.value} value={type.value}>
                          {type.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="size">Size</Label>
                  <Select value={formData.size} onValueChange={(value) => setFormData({...formData, size: value as Monster['size']})}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {sizes.map((size) => (
                        <SelectItem key={size.value} value={size.value}>
                          {size.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="cr">Challenge Rating</Label>
                  <Select value={formData.challengeRating} onValueChange={(value) => setFormData({...formData, challengeRating: value})}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {challengeRatings.map((cr) => (
                        <SelectItem key={cr} value={cr}>
                          {cr}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div>
                <Label htmlFor="description">Description</Label>
                <Textarea
                  id="description"
                  value={formData.description}
                  onChange={(e) => setFormData({...formData, description: e.target.value})}
                  placeholder="Describe the monster's appearance and nature"
                  rows={3}
                />
              </div>

              <div className="grid grid-cols-3 gap-4">
                <div>
                  <Label htmlFor="ac">Armor Class</Label>
                  <Input
                    id="ac"
                    type="number"
                    value={formData.armorClass}
                    onChange={(e) => setFormData({...formData, armorClass: parseInt(e.target.value) || 0})}
                  />
                </div>
                <div>
                  <Label htmlFor="hp">Hit Points</Label>
                  <Input
                    id="hp"
                    type="number"
                    value={formData.hitPoints}
                    onChange={(e) => setFormData({...formData, hitPoints: parseInt(e.target.value) || 0})}
                  />
                </div>
                <div>
                  <Label htmlFor="speed">Speed</Label>
                  <Input
                    id="speed"
                    value={formData.speed}
                    onChange={(e) => setFormData({...formData, speed: e.target.value})}
                    placeholder="e.g., 30 ft, fly 60 ft"
                  />
                </div>
              </div>

              <div>
                <Label>Ability Scores</Label>
                <div className="grid grid-cols-6 gap-2">
                  {Object.entries(formData.stats || {}).map(([stat, value]) => (
                    <div key={stat}>
                      <Label className="text-xs">{stat.charAt(0).toUpperCase() + stat.slice(1, 3)}</Label>
                      <Input
                        type="number"
                        value={value}
                        onChange={(e) => setFormData({
                          ...formData,
                          stats: { ...formData.stats!, [stat]: parseInt(e.target.value) || 10 }
                        })}
                        className="text-center"
                      />
                      <div className="text-xs text-center text-muted-foreground">
                        {getStatModifier(value) >= 0 ? '+' : ''}{getStatModifier(value)}
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div>
                <Label>Special Abilities</Label>
                {formData.abilities?.map((ability, index) => (
                  <div key={index} className="grid grid-cols-12 gap-2 mb-2">
                    <Input
                      className="col-span-3"
                      value={ability.name}
                      onChange={(e) => updateAbility(index, 'name', e.target.value)}
                      placeholder="Ability name"
                    />
                    <Input
                      className="col-span-8"
                      value={ability.description}
                      onChange={(e) => updateAbility(index, 'description', e.target.value)}
                      placeholder="Ability description"
                    />
                    <Button
                      className="col-span-1"
                      type="button"
                      variant="outline"
                      size="sm"
                      onClick={() => removeAbility(index)}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                ))}
                <Button type="button" variant="outline" onClick={addAbility}>
                  <Plus className="h-4 w-4 mr-2" />
                  Add Ability
                </Button>
              </div>

              <div>
                <Label>Actions</Label>
                {formData.actions?.map((action, index) => (
                  <div key={index} className="grid gap-2 mb-2 p-2 border rounded">
                    <div className="grid grid-cols-2 gap-2">
                      <Input
                        value={action.name}
                        onChange={(e) => updateAction(index, 'name', e.target.value)}
                        placeholder="Action name"
                      />
                      <div className="flex gap-2">
                        <Input
                          value={action.toHit || ''}
                          onChange={(e) => updateAction(index, 'toHit', parseInt(e.target.value) || 0)}
                          placeholder="To hit"
                          type="number"
                        />
                        <Input
                          value={action.damage || ''}
                          onChange={(e) => updateAction(index, 'damage', e.target.value)}
                          placeholder="Damage (e.g., 1d8+3)"
                        />
                      </div>
                    </div>
                    <div className="flex gap-2">
                      <Textarea
                        value={action.description}
                        onChange={(e) => updateAction(index, 'description', e.target.value)}
                        placeholder="Action description"
                        rows={2}
                        className="flex-1"
                      />
                      <Button
                        type="button"
                        variant="outline"
                        size="sm"
                        onClick={() => removeAction(index)}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                ))}
                <Button type="button" variant="outline" onClick={addAction}>
                  <Plus className="h-4 w-4 mr-2" />
                  Add Action
                </Button>
              </div>

              <div>
                <Label htmlFor="lore">Lore & Background</Label>
                <Textarea
                  id="lore"
                  value={formData.lore}
                  onChange={(e) => setFormData({...formData, lore: e.target.value})}
                  placeholder="Background information and story hooks"
                  rows={2}
                />
              </div>

              <div className="flex gap-2">
                <Button variant="outline" onClick={generateRandomMonster}>
                  Generate Random
                </Button>
                <Button onClick={editingMonster ? handleUpdate : handleCreate}>
                  {editingMonster ? 'Update Monster' : 'Create Monster'}
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {monsters.map((monster) => (
          <Card key={monster.id} className="hover:shadow-md transition-shadow">
            <CardHeader className="pb-3">
              <div className="flex items-start justify-between">
                <div className="flex items-center space-x-2">
                  <Skull className="h-4 w-4" />
                  <CardTitle className="text-lg">{monster.name}</CardTitle>
                </div>
                <Badge className={getCRColor(monster.challengeRating)}>
                  CR {monster.challengeRating}
                </Badge>
              </div>
              <CardDescription className="flex items-center space-x-1">
                <Badge variant="outline">{monster.size} {monster.type}</Badge>
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-3">
              <p className="text-sm">{monster.description}</p>
              
              <div className="grid grid-cols-3 gap-2 text-xs">
                <div className="flex items-center">
                  <Shield className="h-3 w-3 mr-1" />
                  AC {monster.armorClass}
                </div>
                <div className="flex items-center">
                  <Heart className="h-3 w-3 mr-1" />
                  {monster.hitPoints} HP
                </div>
                <div className="flex items-center">
                  <Zap className="h-3 w-3 mr-1" />
                  {monster.speed}
                </div>
              </div>

              <div className="grid grid-cols-6 gap-1 text-xs">
                {Object.entries(monster.stats).map(([stat, value]) => (
                  <div key={stat} className="text-center">
                    <div className="font-medium">{stat.substring(0, 3).toUpperCase()}</div>
                    <div>{value} ({getStatModifier(value) >= 0 ? '+' : ''}{getStatModifier(value)})</div>
                  </div>
                ))}
              </div>

              {monster.abilities.length > 0 && (
                <div>
                  <span className="text-xs font-medium text-muted-foreground">Abilities:</span>
                  <ul className="text-xs list-disc list-inside mt-1">
                    {monster.abilities.slice(0, 2).map((ability, index) => (
                      <li key={index}>{ability.name}</li>
                    ))}
                    {monster.abilities.length > 2 && <li>+{monster.abilities.length - 2} more...</li>}
                  </ul>
                </div>
              )}

              <div className="flex justify-between items-center pt-2">
                <div className="flex space-x-1">
                  <Button size="sm" variant="outline" onClick={() => handleEdit(monster)}>
                    <Edit className="h-3 w-3" />
                  </Button>
                  <Button size="sm" variant="outline" onClick={() => handleDelete(monster.id)}>
                    <Trash2 className="h-3 w-3" />
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {monsters.length === 0 && (
        <Card className="text-center py-12">
          <CardContent>
            <Skull className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
            <h3 className="text-lg font-semibold mb-2">No Monsters Yet</h3>
            <p className="text-muted-foreground mb-4">
              Create your first monster to start building your bestiary.
            </p>
            <Button onClick={() => setIsCreateOpen(true)}>
              <Plus className="h-4 w-4 mr-2" />
              Create Your First Monster
            </Button>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
