
import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Sparkles, 
  Zap, 
  Target, 
  MapPin, 
  Users, 
  Sword, 
  Eye, 
  BookOpen,
  Clock,
  AlertTriangle,
  Lightbulb,
  RefreshCw
} from 'lucide-react';
import { useToast } from "@/hooks/use-toast";

interface SmartEncounter {
  id: string;
  title: string;
  type: 'combat' | 'social' | 'exploration' | 'puzzle' | 'mixed';
  difficulty: 'easy' | 'medium' | 'hard' | 'deadly';
  estimatedDuration: string;
  description: string;
  setup: string;
  objectives: string[];
  complications: string[];
  rewards: {
    xp: number;
    treasure: string[];
    story: string[];
  };
  npcs: Array<{
    name: string;
    role: string;
    motivation: string;
    tactics?: string;
  }>;
  environment: {
    setting: string;
    features: string[];
    hazards: string[];
    advantages: string[];
  };
  scalingOptions: {
    easier: string[];
    harder: string[];
  };
  dmTips: string[];
}

export default function SmartEncounterTab() {
  const { toast } = useToast();
  const [partyLevel, setPartyLevel] = useState('5');
  const [partySize, setPartySize] = useState('4');
  const [encounterType, setEncounterType] = useState('mixed');
  const [themeInput, setThemeInput] = useState('');
  const [difficultyPreference, setDifficultyPreference] = useState('medium');
  const [campaignContext, setCampaignContext] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [generatedEncounter, setGeneratedEncounter] = useState<SmartEncounter | null>(null);

  const encounterTypes = [
    { value: 'combat', label: 'Combat Focus', icon: Sword },
    { value: 'social', label: 'Social Interaction', icon: Users },
    { value: 'exploration', label: 'Exploration', icon: Eye },
    { value: 'puzzle', label: 'Puzzle/Mystery', icon: BookOpen },
    { value: 'mixed', label: 'Mixed Encounter', icon: Target }
  ];

  const generateSmartEncounter = async () => {
    setIsGenerating(true);
    
    // Simulate AI generation
    setTimeout(() => {
      const encounter: SmartEncounter = {
        id: Date.now().toString(),
        title: "The Merchant's Secret Cargo",
        type: 'mixed',
        difficulty: 'medium',
        estimatedDuration: '45-60 minutes',
        description: "A seemingly innocent merchant caravan has stopped at the town, but their cargo holds more than exotic goods. The party must navigate social intrigue, solve mysteries, and potentially engage in combat.",
        setup: "The party notices unusual activity around a merchant caravan that arrived this morning. Guards seem nervous, the merchant is offering unusually high prices for basic information, and strange sounds come from covered wagons.",
        objectives: [
          "Investigate the suspicious merchant caravan",
          "Uncover the true nature of their cargo",
          "Decide how to handle the discovered contraband",
          "Deal with consequences of their choices"
        ],
        complications: [
          "The cargo contains cursed artifacts that affect those nearby",
          "Local authorities are corrupt and work with the merchant",
          "The merchant has hostages among the 'hired help'",
          "A rival adventuring party is also investigating"
        ],
        rewards: {
          xp: 1800,
          treasure: ["500 gp", "Potion of Greater Healing", "Cloak of Elvenkind"],
          story: ["Reputation with local merchants", "Information about artifact smuggling ring", "Contact with underground resistance"]
        },
        npcs: [
          {
            name: "Gareth Goldtouch",
            role: "Merchant (secretly smuggler)",
            motivation: "Deliver cargo without detection, protect his operation",
            tactics: "Uses charm and bribery first, then intimidation, flees if cornered"
          },
          {
            name: "Captain Mira Blackstone",
            role: "Corrupt guard captain",
            motivation: "Maintain her profitable arrangement with smugglers",
            tactics: "Tries to redirect party attention elsewhere, threatens legal action"
          },
          {
            name: "Tam the Curious",
            role: "Street orphan witness",
            motivation: "Wants to help but fears retribution",
            tactics: "Provides cryptic clues, hides when danger appears"
          }
        ],
        environment: {
          setting: "Town marketplace and caravan staging area",
          features: ["Crowded market stalls providing cover", "Narrow alleyways between buildings", "Two-story merchant houses with balconies", "Central fountain for meetings"],
          hazards: ["Innocent bystanders in combat areas", "Slippery cobblestones when wet", "Unstable cargo that could spill"],
          advantages: ["Multiple approach routes", "NPCs willing to provide information", "Opportunities for stealth and misdirection"]
        },
        scalingOptions: {
          easier: [
            "Reduce number of guards by half",
            "Make the merchant more easily intimidated",
            "Provide obvious clues to the cargo's nature",
            "Give party an NPC ally with inside information"
          ],
          harder: [
            "Add time pressure (cargo ships out at dawn)",
            "Include magical wards on the wagons",
            "Add a rival party competing for the same goal",
            "Make the authorities fully corrupt and hostile"
          ]
        },
        dmTips: [
          "Start with social investigation, let players choose when/if to escalate",
          "Use the crowd to create dynamic environmental challenges",
          "Let player creativity drive solutions - multiple paths to success",
          "The cargo's nature can tie into your campaign's larger arc",
          "Consider long-term consequences of how they handle the situation"
        ]
      };
      
      setGeneratedEncounter(encounter);
      setIsGenerating(false);
      
      toast({
        title: "Smart Encounter Generated!",
        description: "AI has created a dynamic, scalable encounter for your session."
      });
    }, 3000);
  };

  const regenerateEncounter = () => {
    setGeneratedEncounter(null);
    generateSmartEncounter();
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold flex items-center">
            <Sparkles className="mr-2 h-6 w-6 text-amber-500" />
            Smart Encounter Generator
          </h2>
          <p className="text-muted-foreground">AI-powered encounters that adapt to your party and campaign</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Generation Controls */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Target className="mr-2 h-5 w-5" />
              Encounter Parameters
            </CardTitle>
            <CardDescription>Customize the encounter to fit your needs</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Party Level</Label>
                <Select value={partyLevel} onValueChange={setPartyLevel}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {Array.from({length: 20}, (_, i) => i + 1).map(level => (
                      <SelectItem key={level} value={level.toString()}>
                        Level {level}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>Party Size</Label>
                <Select value={partySize} onValueChange={setPartySize}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {[3, 4, 5, 6, 7, 8].map(size => (
                      <SelectItem key={size} value={size.toString()}>
                        {size} players
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="space-y-2">
              <Label>Encounter Type</Label>
              <Select value={encounterType} onValueChange={setEncounterType}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {encounterTypes.map(type => (
                    <SelectItem key={type.value} value={type.value}>
                      {type.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>Difficulty Preference</Label>
              <Select value={difficultyPreference} onValueChange={setDifficultyPreference}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="easy">Easy</SelectItem>
                  <SelectItem value="medium">Medium</SelectItem>
                  <SelectItem value="hard">Hard</SelectItem>
                  <SelectItem value="deadly">Deadly</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>Theme/Setting</Label>
              <Input
                placeholder="e.g., haunted mansion, political intrigue, wilderness survival"
                value={themeInput}
                onChange={(e) => setThemeInput(e.target.value)}
              />
            </div>

            <div className="space-y-2">
              <Label>Campaign Context</Label>
              <Textarea
                placeholder="Brief context about your campaign to help AI generate relevant encounters..."
                value={campaignContext}
                onChange={(e) => setCampaignContext(e.target.value)}
                rows={3}
              />
            </div>

            <Button 
              onClick={generateSmartEncounter} 
              disabled={isGenerating}
              className="w-full"
            >
              {isGenerating ? (
                <>
                  <Clock className="mr-2 h-4 w-4 animate-spin" />
                  Generating Encounter...
                </>
              ) : (
                <>
                  <Zap className="mr-2 h-4 w-4" />
                  Generate Smart Encounter
                </>
              )}
            </Button>

            {generatedEncounter && (
              <Button 
                onClick={regenerateEncounter} 
                variant="outline"
                className="w-full"
              >
                <RefreshCw className="mr-2 h-4 w-4" />
                Generate New Encounter
              </Button>
            )}
          </CardContent>
        </Card>

        {/* Generated Encounter Display */}
        <div className="lg:col-span-2">
          {generatedEncounter ? (
            <Card>
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-xl">{generatedEncounter.title}</CardTitle>
                  <div className="flex gap-2">
                    <Badge variant="outline">{generatedEncounter.difficulty}</Badge>
                    <Badge variant="outline">{generatedEncounter.type}</Badge>
                    <Badge variant="outline">{generatedEncounter.estimatedDuration}</Badge>
                  </div>
                </div>
                <CardDescription>{generatedEncounter.description}</CardDescription>
              </CardHeader>
              <CardContent>
                <Tabs defaultValue="overview" className="w-full">
                  <TabsList className="grid w-full grid-cols-6">
                    <TabsTrigger value="overview">Overview</TabsTrigger>
                    <TabsTrigger value="npcs">NPCs</TabsTrigger>
                    <TabsTrigger value="environment">Environment</TabsTrigger>
                    <TabsTrigger value="rewards">Rewards</TabsTrigger>
                    <TabsTrigger value="scaling">Scaling</TabsTrigger>
                    <TabsTrigger value="tips">DM Tips</TabsTrigger>
                  </TabsList>

                  <TabsContent value="overview" className="space-y-4">
                    <div>
                      <h4 className="font-semibold mb-2">Setup</h4>
                      <p className="text-sm bg-blue-50 p-3 rounded-lg">{generatedEncounter.setup}</p>
                    </div>

                    <div>
                      <h4 className="font-semibold mb-2">Objectives</h4>
                      <ul className="text-sm space-y-1">
                        {generatedEncounter.objectives.map((objective, index) => (
                          <li key={index} className="flex items-start">
                            <Target className="mr-2 h-3 w-3 mt-0.5 flex-shrink-0" />
                            {objective}
                          </li>
                        ))}
                      </ul>
                    </div>

                    <div>
                      <h4 className="font-semibold mb-2 flex items-center">
                        <AlertTriangle className="mr-2 h-4 w-4 text-amber-500" />
                        Potential Complications
                      </h4>
                      <ul className="text-sm space-y-1">
                        {generatedEncounter.complications.map((complication, index) => (
                          <li key={index} className="flex items-start">
                            <AlertTriangle className="mr-2 h-3 w-3 mt-0.5 flex-shrink-0 text-amber-500" />
                            {complication}
                          </li>
                        ))}
                      </ul>
                    </div>
                  </TabsContent>

                  <TabsContent value="npcs" className="space-y-4">
                    {generatedEncounter.npcs.map((npc, index) => (
                      <Card key={index} className="p-4">
                        <h4 className="font-semibold">{npc.name}</h4>
                        <p className="text-sm text-muted-foreground mb-2">{npc.role}</p>
                        <div className="space-y-2">
                          <div>
                            <span className="text-xs font-medium">Motivation:</span>
                            <p className="text-sm">{npc.motivation}</p>
                          </div>
                          {npc.tactics && (
                            <div>
                              <span className="text-xs font-medium">Tactics:</span>
                              <p className="text-sm">{npc.tactics}</p>
                            </div>
                          )}
                        </div>
                      </Card>
                    ))}
                  </TabsContent>

                  <TabsContent value="environment" className="space-y-4">
                    <div>
                      <h4 className="font-semibold mb-2">Setting</h4>
                      <p className="text-sm bg-green-50 p-3 rounded-lg">{generatedEncounter.environment.setting}</p>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      <div>
                        <h4 className="font-semibold text-sm mb-2">Features</h4>
                        <ul className="text-sm space-y-1">
                          {generatedEncounter.environment.features.map((feature, index) => (
                            <li key={index} className="flex items-start">
                              <MapPin className="mr-2 h-3 w-3 mt-0.5 flex-shrink-0" />
                              {feature}
                            </li>
                          ))}
                        </ul>
                      </div>

                      <div>
                        <h4 className="font-semibold text-sm mb-2">Hazards</h4>
                        <ul className="text-sm space-y-1">
                          {generatedEncounter.environment.hazards.map((hazard, index) => (
                            <li key={index} className="flex items-start">
                              <AlertTriangle className="mr-2 h-3 w-3 mt-0.5 flex-shrink-0 text-red-500" />
                              {hazard}
                            </li>
                          ))}
                        </ul>
                      </div>

                      <div>
                        <h4 className="font-semibold text-sm mb-2">Advantages</h4>
                        <ul className="text-sm space-y-1">
                          {generatedEncounter.environment.advantages.map((advantage, index) => (
                            <li key={index} className="flex items-start">
                              <Lightbulb className="mr-2 h-3 w-3 mt-0.5 flex-shrink-0 text-green-500" />
                              {advantage}
                            </li>
                          ))}
                        </ul>
                      </div>
                    </div>
                  </TabsContent>

                  <TabsContent value="rewards" className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      <Card className="p-4">
                        <h4 className="font-semibold mb-2">Experience</h4>
                        <p className="text-2xl font-bold text-blue-600">{generatedEncounter.rewards.xp} XP</p>
                      </Card>

                      <div>
                        <h4 className="font-semibold mb-2">Treasure</h4>
                        <ul className="text-sm space-y-1">
                          {generatedEncounter.rewards.treasure.map((item, index) => (
                            <li key={index}>• {item}</li>
                          ))}
                        </ul>
                      </div>

                      <div>
                        <h4 className="font-semibold mb-2">Story Rewards</h4>
                        <ul className="text-sm space-y-1">
                          {generatedEncounter.rewards.story.map((reward, index) => (
                            <li key={index}>• {reward}</li>
                          ))}
                        </ul>
                      </div>
                    </div>
                  </TabsContent>

                  <TabsContent value="scaling" className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <Card className="p-4 border-green-200">
                        <h4 className="font-semibold mb-2 text-green-700">Make It Easier</h4>
                        <ul className="text-sm space-y-1">
                          {generatedEncounter.scalingOptions.easier.map((option, index) => (
                            <li key={index}>• {option}</li>
                          ))}
                        </ul>
                      </Card>

                      <Card className="p-4 border-red-200">
                        <h4 className="font-semibold mb-2 text-red-700">Make It Harder</h4>
                        <ul className="text-sm space-y-1">
                          {generatedEncounter.scalingOptions.harder.map((option, index) => (
                            <li key={index}>• {option}</li>
                          ))}
                        </ul>
                      </Card>
                    </div>
                  </TabsContent>

                  <TabsContent value="tips" className="space-y-4">
                    <Card className="p-4 border-purple-200 bg-purple-50">
                      <h4 className="font-semibold mb-3 text-purple-800">DM Tips & Advice</h4>
                      <ul className="space-y-2">
                        {generatedEncounter.dmTips.map((tip, index) => (
                          <li key={index} className="flex items-start text-sm">
                            <Lightbulb className="mr-2 h-4 w-4 mt-0.5 flex-shrink-0 text-purple-600" />
                            {tip}
                          </li>
                        ))}
                      </ul>
                    </Card>
                  </TabsContent>
                </Tabs>
              </CardContent>
            </Card>
          ) : (
            <Card className="h-96 flex items-center justify-center">
              <div className="text-center text-muted-foreground">
                <Sparkles className="mx-auto h-12 w-12 mb-4 opacity-50" />
                <h3 className="text-lg font-semibold mb-2">Generate Your First Smart Encounter</h3>
                <p className="text-sm max-w-md">
                  Set your party parameters and let AI create a dynamic, scalable encounter 
                  that adapts to your campaign needs.
                </p>
              </div>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}
