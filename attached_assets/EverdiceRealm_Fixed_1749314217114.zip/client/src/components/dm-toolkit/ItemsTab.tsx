import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Package, Plus, Edit, Trash2, Sword, Shield, Sparkles } from 'lucide-react';
import { useToast } from "@/hooks/use-toast";

interface MagicItem {
  id: string;
  name: string;
  type: 'weapon' | 'armor' | 'accessory' | 'consumable' | 'wondrous' | 'tool';
  rarity: 'common' | 'uncommon' | 'rare' | 'very_rare' | 'legendary' | 'artifact';
  description: string;
  properties: string[];
  attunement: boolean;
  charges?: number;
  value: number;
  weight: number;
  mechanics: string;
  lore: string;
}

const itemTypes = [
  { value: 'weapon', label: 'Weapon', icon: Sword },
  { value: 'armor', label: 'Armor', icon: Shield },
  { value: 'accessory', label: 'Accessory', icon: Sparkles },
  { value: 'consumable', label: 'Consumable', icon: Sparkles },
  { value: 'wondrous', label: 'Wondrous Item', icon: Sparkles },
  { value: 'tool', label: 'Tool', icon: Package }
];

const rarities = [
  { value: 'common', label: 'Common', color: 'bg-gray-100 text-gray-800' },
  { value: 'uncommon', label: 'Uncommon', color: 'bg-green-100 text-green-800' },
  { value: 'rare', label: 'Rare', color: 'bg-blue-100 text-blue-800' },
  { value: 'very_rare', label: 'Very Rare', color: 'bg-purple-100 text-purple-800' },
  { value: 'legendary', label: 'Legendary', color: 'bg-orange-100 text-orange-800' },
  { value: 'artifact', label: 'Artifact', color: 'bg-red-100 text-red-800' }
];

export default function ItemsTab() {
  const { toast } = useToast();
  const [items, setItems] = useState<MagicItem[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  // Load items from server
  React.useEffect(() => {
    const loadItems = async () => {
      try {
        const response = await fetch('/api/dm-toolkit/items', {
          credentials: 'include'
        });
        if (response.ok) {
          const serverItems = await response.json();
          const formattedItems = serverItems.map((item: any) => ({
            id: item.id.toString(),
            name: item.title,
            description: item.description,
            ...JSON.parse(item.details)
          }));
          setItems(formattedItems);
        }
      } catch (error) {
        console.error('Failed to load items:', error);
        toast({
          title: "Error",
          description: "Failed to load magic items",
          variant: "destructive"
        });
      } finally {
        setIsLoading(false);
      }
    };

    loadItems();
  }, [toast]);

  const [isCreateOpen, setIsCreateOpen] = useState(false);
  const [editingItem, setEditingItem] = useState<MagicItem | null>(null);
  const [formData, setFormData] = useState<Partial<MagicItem>>({
    name: '',
    type: 'wondrous',
    rarity: 'uncommon',
    description: '',
    properties: [''],
    attunement: false,
    charges: undefined,
    value: 0,
    weight: 0,
    mechanics: '',
    lore: ''
  });

  const [generationPrompt, setGenerationPrompt] = useState('');

  const handleCreate = async () => {
    if (!formData.name || !formData.description) {
      toast({
        title: "Error",
        description: "Name and description are required",
        variant: "destructive"
      });
      return;
    }

    try {
      const itemPayload = {
        name: formData.name,
        description: formData.description,
        type: formData.type,
        rarity: formData.rarity,
        properties: formData.properties,
        attunement: formData.attunement,
        charges: formData.charges,
        value: formData.value,
        weight: formData.weight,
        mechanics: formData.mechanics,
        lore: formData.lore
      };

      const response = await fetch('/api/dm-toolkit/items', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify(itemPayload)
      });

      if (response.ok) {
        const serverItem = await response.json();
        const newItem: MagicItem = {
          id: serverItem.id.toString(),
          name: serverItem.title,
          description: serverItem.description,
          ...JSON.parse(serverItem.details)
        };

        setItems([...items, newItem]);
        resetForm();
        setIsCreateOpen(false);

        toast({
          title: "Item Created",
          description: `${newItem.name} has been added to your item collection.`
        });
      } else {
        throw new Error('Failed to create item');
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to create magic item",
        variant: "destructive"
      });
    }
  };

  const resetForm = () => {
    setFormData({
      name: '',
      description: '',
      type: 'wondrous',
      rarity: 'uncommon',
      properties: [],
      attunement: false,
      value: 0,
      weight: 0,
      mechanics: '',
      lore: ''
    });
    setEditingItem(null);
    setGenerationPrompt('');
    setIsCreateOpen(false);
  };

  const handleEdit = (item: MagicItem) => {
    setEditingItem(item);
    setFormData(item);
    setIsCreateOpen(true);
  };

  const handleUpdate = async () => {
    if (!editingItem) return;

    try {
      const response = await fetch(`/api/dm-toolkit/items/${editingItem.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify(formData)
      });

      if (response.ok) {
        const updatedServerItem = await response.json();
        const updatedItem: MagicItem = {
          id: updatedServerItem.id.toString(),
          name: updatedServerItem.title,
          description: updatedServerItem.description,
          ...JSON.parse(updatedServerItem.details)
        };

        const updatedItems = items.map(item =>
          item.id === editingItem.id ? updatedItem : item
        );
        setItems(updatedItems);
        setEditingItem(null);
        setIsCreateOpen(false);

        toast({
          title: "Item Updated",
          description: `${updatedItem.name} has been updated.`
        });
      } else {
        throw new Error('Failed to update item');
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to update magic item",
        variant: "destructive"
      });
    }
  };

  const handleDelete = async (id: string) => {
    try {
      const response = await fetch(`/api/dm-toolkit/items/${id}`, {
        method: 'DELETE',
        credentials: 'include'
      });

      if (response.ok) {
        setItems(items.filter(item => item.id !== id));
        toast({
          title: "Item Deleted",
          description: "Item has been removed from your collection."
        });
      } else {
        throw new Error('Failed to delete item');
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to delete magic item",
        variant: "destructive"
      });
    }
  };

  const addProperty = () => {
    setFormData({
      ...formData,
      properties: [...(formData.properties || []), '']
    });
  };

  const updateProperty = (index: number, value: string) => {
    const properties = [...(formData.properties || [])];
    properties[index] = value;
    setFormData({ ...formData, properties });
  };

  const removeProperty = (index: number) => {
    const properties = formData.properties?.filter((_, i) => i !== index) || [];
    setFormData({ ...formData, properties });
  };

  const generateRandomItem = () => {
    const templates = {
      weapon: {
        names: ['Flamebrand', 'Frostbite', 'Stormcutter', 'Shadowstrike'],
        descriptions: ['A magical sword that glows with inner fire', 'A blade that radiates cold energy', 'A weapon crackling with lightning'],
        properties: ['Magical weapon', '+1 to attack and damage rolls', 'Additional elemental damage']
      },
      armor: {
        names: ['Plate of the Guardian', 'Robe of Stars', 'Cloak of Elvenkind'],
        descriptions: ['Gleaming armor blessed by celestials', 'A robe that shimmers like the night sky', 'A cloak woven by elven masters'],
        properties: ['Magical armor', '+1 AC', 'Additional protective properties']
      },
      accessory: {
        names: ['Ring of Protection', 'Amulet of Health', 'Bracers of Defense'],
        descriptions: ['A simple band that pulses with protective magic', 'An amulet that radiates vitality', 'Bracers inscribed with defensive runes'],
        properties: ['Requires attunement', 'Protective enchantment', 'Beneficial magic effect']
      }
    };

    const itemType = formData.type as keyof typeof templates;
    const template = templates[itemType] || templates.accessory;
    const randomName = template.names[Math.floor(Math.random() * template.names.length)];
    const randomDesc = template.descriptions[Math.floor(Math.random() * template.descriptions.length)];

    setFormData({
      ...formData,
      name: randomName,
      description: randomDesc,
      properties: template.properties,
      value: Math.floor(Math.random() * 5000) + 500,
      weight: Math.floor(Math.random() * 10) + 1,
      mechanics: 'Provides beneficial magical effects as described.',
      lore: 'An item of mysterious origin with a storied past.'
    });
  };

  const getTypeIcon = (type: string) => {
    const typeInfo = itemTypes.find(t => t.value === type);
    const IconComponent = typeInfo?.icon || Package;
    return <IconComponent className="h-4 w-4" />;
  };

  const getRarityColor = (rarity: string) => {
    const rarityInfo = rarities.find(r => r.value === rarity);
    return rarityInfo?.color || 'bg-gray-100 text-gray-800';
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-fantasy font-bold">Magic Items</h2>
          <p className="text-muted-foreground">Create and manage magical items for your campaigns</p>
        </div>
        <Dialog open={isCreateOpen} onOpenChange={setIsCreateOpen}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="h-4 w-4 mr-2" />
              Create Item
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-3xl max-h-[80vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>{editingItem ? 'Edit Magic Item' : 'Create New Magic Item'}</DialogTitle>
              <DialogDescription>
                Design a magical item for your campaign
              </DialogDescription>
            </DialogHeader>

            <div className="grid gap-4">
              <div className="grid grid-cols-3 gap-4">
                <div>
                  <Label htmlFor="name">Item Name</Label>
                  <Input
                    id="name"
                    value={formData.name}
                    onChange={(e) => setFormData({...formData, name: e.target.value})}
                    placeholder="Enter item name"
                  />
                </div>
                <div>
                  <Label htmlFor="type">Item Type</Label>
                  <Select value={formData.type} onValueChange={(value) => setFormData({...formData, type: value as MagicItem['type']})}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {itemTypes.map((type) => (
                        <SelectItem key={type.value} value={type.value}>
                          <div className="flex items-center">
                            <type.icon className="h-4 w-4 mr-2" />
                            {type.label}
                          </div>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="rarity">Rarity</Label>
                  <Select value={formData.rarity} onValueChange={(value) => setFormData({...formData, rarity: value as MagicItem['rarity']})}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {rarities.map((rarity) => (
                        <SelectItem key={rarity.value} value={rarity.value}>
                          {rarity.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div>
                <Label htmlFor="description">Description</Label>
                <Textarea
                  id="description"
                  value={formData.description}
                  onChange={(e) => setFormData({...formData, description: e.target.value})}
                  placeholder="Describe the item's appearance and basic function"
                  rows={3}
                />
              </div>

              <div>
                <Label>Properties & Features</Label>
                {formData.properties?.map((property, index) => (
                  <div key={index} className="flex gap-2 mb-2">
                    <Input
                      value={property}
                      onChange={(e) => updateProperty(index, e.target.value)}
                      placeholder={`Property ${index + 1}`}
                    />
                    <Button
                      type="button"
                      variant="outline"
                      size="sm"
                      onClick={() => removeProperty(index)}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                ))}
                <Button type="button" variant="outline" onClick={addProperty}>
                  <Plus className="h-4 w-4 mr-2" />
                  Add Property
                </Button>
              </div>

              <div className="grid grid-cols-4 gap-4">
                <div className="flex items-center space-x-2">
                  <input
                    type="checkbox"
                    id="attunement"
                    checked={formData.attunement}
                    onChange={(e) => setFormData({...formData, attunement: e.target.checked})}
                  />
                  <Label htmlFor="attunement">Requires Attunement</Label>
                </div>
                <div>
                  <Label htmlFor="charges">Charges (optional)</Label>
                  <Input
                    id="charges"
                    type="number"
                    value={formData.charges || ''}
                    onChange={(e) => setFormData({...formData, charges: e.target.value ? parseInt(e.target.value) : undefined})}
                    placeholder="e.g., 3"
                  />
                </div>
                <div>
                  <Label htmlFor="value">Value (gold)</Label>
                  <Input
                    id="value"
                    type="number"
                    value={formData.value}
                    onChange={(e) => setFormData({...formData, value: parseInt(e.target.value) || 0})}
                  />
                </div>
                <div>
                  <Label htmlFor="weight">Weight (lbs)</Label>
                  <Input
                    id="weight"
                    type="number"
                    step="0.1"
                    value={formData.weight}
                    onChange={(e) => setFormData({...formData, weight: parseFloat(e.target.value) || 0})}
                  />
                </div>
              </div>

              <div>
                <Label htmlFor="mechanics">Game Mechanics</Label>
                <Textarea
                  id="mechanics"
                  value={formData.mechanics}
                  onChange={(e) => setFormData({...formData, mechanics: e.target.value})}
                  placeholder="Detailed mechanical effects and rules"
                  rows={3}
                />
              </div>

              <div>
                <Label htmlFor="lore">Lore & History</Label>
                <Textarea
                  id="lore"
                  value={formData.lore}
                  onChange={(e) => setFormData({...formData, lore: e.target.value})}
                  placeholder="Background story and historical significance"
                  rows={2}
                />
              </div>

              <div className="flex gap-2">
                <Button variant="outline" onClick={generateRandomItem}>
                  Generate Random
                </Button>
                <Button onClick={editingItem ? handleUpdate : handleCreate}>
                  {editingItem ? 'Update Item' : 'Create Item'}
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {items.map((item) => (
          <Card key={item.id} className="hover:shadow-md transition-shadow">
            <CardHeader className="pb-3">
              <div className="flex items-start justify-between">
                <div className="flex items-center space-x-2">
                  {getTypeIcon(item.type)}
                  <CardTitle className="text-lg">{item.name}</CardTitle>
                </div>
                <Badge className={getRarityColor(item.rarity)}>
                  {rarities.find(r => r.value === item.rarity)?.label}
                </Badge>
              </div>
              <CardDescription className="flex items-center space-x-1">
                <Badge variant="outline">{itemTypes.find(t => t.value === item.type)?.label}</Badge>
                {item.attunement && <Badge variant="outline">Attunement</Badge>}
                {item.charges && <Badge variant="outline">{item.charges} charges</Badge>}
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-3">
              <p className="text-sm">{item.description}</p>

              {item.properties.length > 0 && (
                <div>
                  <span className="text-xs font-medium text-muted-foreground">Properties:</span>
                  <ul className="text-xs list-disc list-inside mt-1">
                    {item.properties.map((property, index) => (
                      <li key={index}>{property}</li>
                    ))}
                  </ul>
                </div>
              )}

              <div className="flex justify-between text-xs text-muted-foreground">
                <span>Value: {item.value} gp</span>
                <span>Weight: {item.weight} lbs</span>
              </div>

              {item.mechanics && (
                <div>
                  <span className="text-xs font-medium text-muted-foreground">Mechanics:</span>
                  <p className="text-xs">{item.mechanics}</p>
                </div>
              )}

              <div className="flex justify-between items-center pt-2">
                <div className="flex space-x-1">
                  <Button size="sm" variant="outline" onClick={() => handleEdit(item)}>
                    <Edit className="h-3 w-3" />
                  </Button>
                  <Button size="sm" variant="outline" onClick={() => handleDelete(item.id)}>
                    <Trash2 className="h-3 w-3" />
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {items.length === 0 && (
        <Card className="text-center py-12">
          <CardContent>
            <Package className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
            <h3 className="text-lg font-semibold mb-2">No Items Yet</h3>
            <p className="text-muted-foreground mb-4">
              Create your first magic item to start building a treasure collection.
            </p>
            <Button onClick={() => setIsCreateOpen(true)}>
              <Plus className="h-4 w-4 mr-2" />
              Create Your First Item
            </Button>
          </CardContent>
        </Card>
      )}
    </div>
  );
}