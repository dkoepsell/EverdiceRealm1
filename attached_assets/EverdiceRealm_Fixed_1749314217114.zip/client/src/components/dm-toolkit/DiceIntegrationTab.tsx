
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { 
  Dice6, 
  Camera, 
  Smartphone, 
  Wifi, 
  Users, 
  CheckCircle, 
  AlertCircle,
  Settings,
  Play,
  RotateCcw
} from 'lucide-react';
import { useToast } from "@/hooks/use-toast";

interface DiceRoll {
  id: string;
  playerId: string;
  playerName: string;
  diceType: string;
  result: number;
  timestamp: Date;
  context: string; // What the roll was for
  validated: boolean;
}

interface ConnectedPlayer {
  id: string;
  name: string;
  connected: boolean;
  lastRoll?: DiceRoll;
}

export default function DiceIntegrationTab() {
  const { toast } = useToast();
  const [integrationMethod, setIntegrationMethod] = useState<'camera' | 'app' | 'manual'>('camera');
  const [isListening, setIsListening] = useState(false);
  const [connectedPlayers, setConnectedPlayers] = useState<ConnectedPlayer[]>([
    { id: '1', name: 'Alex', connected: true },
    { id: '2', name: 'Jordan', connected: false },
    { id: '3', name: 'Sam', connected: true },
    { id: '4', name: 'Taylor', connected: true }
  ]);
  const [recentRolls, setRecentRolls] = useState<DiceRoll[]>([]);
  const [currentContext, setCurrentContext] = useState('');
  const [roomCode, setRoomCode] = useState('');

  useEffect(() => {
    // Generate room code
    setRoomCode(Math.random().toString(36).substring(2, 8).toUpperCase());
  }, []);

  const startDiceSession = () => {
    setIsListening(true);
    toast({
      title: "Dice Session Started",
      description: "Players can now submit their physical dice rolls."
    });
  };

  const stopDiceSession = () => {
    setIsListening(false);
    toast({
      title: "Dice Session Ended",
      description: "No longer accepting dice rolls."
    });
  };

  const validateRoll = (rollId: string) => {
    setRecentRolls(prev => prev.map(roll => 
      roll.id === rollId ? { ...roll, validated: true } : roll
    ));
    toast({
      title: "Roll Validated",
      description: "The dice roll has been confirmed and recorded."
    });
  };

  const simulatePlayerRoll = () => {
    const players = connectedPlayers.filter(p => p.connected);
    if (players.length === 0) return;
    
    const player = players[Math.floor(Math.random() * players.length)];
    const diceTypes = ['d20', 'd12', 'd10', 'd8', 'd6', 'd4'];
    const diceType = diceTypes[Math.floor(Math.random() * diceTypes.length)];
    const maxValue = parseInt(diceType.substring(1));
    const result = Math.floor(Math.random() * maxValue) + 1;
    
    const newRoll: DiceRoll = {
      id: Date.now().toString(),
      playerId: player.id,
      playerName: player.name,
      diceType,
      result,
      timestamp: new Date(),
      context: currentContext || 'General Roll',
      validated: false
    };
    
    setRecentRolls(prev => [newRoll, ...prev.slice(0, 9)]);
    
    toast({
      title: `${player.name} rolled a ${diceType}`,
      description: `Result: ${result}${currentContext ? ` for ${currentContext}` : ''}`
    });
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold flex items-center">
            <Dice6 className="mr-2 h-6 w-6 text-blue-500" />
            Physical Dice Integration
          </h2>
          <p className="text-muted-foreground">Connect real dice rolls to your digital game</p>
        </div>
        <div className="flex gap-2">
          {!isListening ? (
            <Button onClick={startDiceSession} className="flex items-center">
              <Play className="mr-2 h-4 w-4" />
              Start Dice Session
            </Button>
          ) : (
            <Button onClick={stopDiceSession} variant="destructive" className="flex items-center">
              <RotateCcw className="mr-2 h-4 w-4" />
              End Session
            </Button>
          )}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Connection Methods */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Settings className="mr-2 h-5 w-5" />
              Connection Methods
            </CardTitle>
            <CardDescription>Choose how players submit dice rolls</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-3">
              <div className="flex items-center space-x-3 p-3 border rounded-lg cursor-pointer hover:bg-secondary/50">
                <Camera className="h-5 w-5" />
                <div>
                  <p className="font-medium">Camera Recognition</p>
                  <p className="text-xs text-muted-foreground">Scan dice with phone camera</p>
                </div>
              </div>
              
              <div className="flex items-center space-x-3 p-3 border rounded-lg cursor-pointer hover:bg-secondary/50">
                <Smartphone className="h-5 w-5" />
                <div>
                  <p className="font-medium">Mobile App</p>
                  <p className="text-xs text-muted-foreground">Use companion app for rolling</p>
                </div>
              </div>
              
              <div className="flex items-center space-x-3 p-3 border rounded-lg bg-primary/10 border-primary">
                <Wifi className="h-5 w-5" />
                <div>
                  <p className="font-medium">Manual Entry</p>
                  <p className="text-xs text-muted-foreground">Players type results (demo)</p>
                </div>
              </div>
            </div>

            <Separator />

            <div className="space-y-2">
              <Label>Room Code</Label>
              <div className="flex items-center space-x-2">
                <Input value={roomCode} readOnly className="font-mono" />
                <Button size="sm" variant="outline">Share</Button>
              </div>
              <p className="text-xs text-muted-foreground">
                Players enter this code to connect their dice
              </p>
            </div>

            <div className="space-y-2">
              <Label>Current Context</Label>
              <Input
                placeholder="e.g., Initiative, Attack Roll, Saving Throw"
                value={currentContext}
                onChange={(e) => setCurrentContext(e.target.value)}
              />
              <p className="text-xs text-muted-foreground">
                What are players rolling for?
              </p>
            </div>

            <Button 
              onClick={simulatePlayerRoll} 
              variant="outline" 
              className="w-full"
              disabled={!isListening}
            >
              Simulate Player Roll
            </Button>
          </CardContent>
        </Card>

        {/* Connected Players */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Users className="mr-2 h-5 w-5" />
              Connected Players
            </CardTitle>
            <CardDescription>
              {connectedPlayers.filter(p => p.connected).length} of {connectedPlayers.length} players connected
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {connectedPlayers.map(player => (
                <div key={player.id} className="flex items-center justify-between p-2 border rounded-lg">
                  <div className="flex items-center space-x-3">
                    <div className={`w-3 h-3 rounded-full ${player.connected ? 'bg-green-500' : 'bg-gray-300'}`} />
                    <span className="font-medium">{player.name}</span>
                  </div>
                  <div className="text-right">
                    {player.connected ? (
                      <Badge variant="outline" className="text-green-600 border-green-600">
                        <Wifi className="mr-1 h-3 w-3" />
                        Connected
                      </Badge>
                    ) : (
                      <Badge variant="outline" className="text-gray-500">
                        Offline
                      </Badge>
                    )}
                  </div>
                </div>
              ))}
            </div>

            <Separator className="my-4" />

            <div className="space-y-2">
              <Label>Quick Actions</Label>
              <div className="grid grid-cols-2 gap-2">
                <Button size="sm" variant="outline">
                  Call for Initiative
                </Button>
                <Button size="sm" variant="outline">
                  Request Saving Throws
                </Button>
                <Button size="sm" variant="outline">
                  Attack Rolls
                </Button>
                <Button size="sm" variant="outline">
                  Ability Checks
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Recent Rolls */}
        <Card>
          <CardHeader>
            <CardTitle>Recent Rolls</CardTitle>
            <CardDescription>Real-time dice roll submissions</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-3 max-h-96 overflow-y-auto">
              {recentRolls.length === 0 ? (
                <div className="text-center py-8 text-muted-foreground">
                  <Dice6 className="mx-auto h-12 w-12 mb-2 opacity-50" />
                  <p>No dice rolls yet</p>
                  <p className="text-xs">Start a session to begin tracking rolls</p>
                </div>
              ) : (
                recentRolls.map(roll => (
                  <div key={roll.id} className="flex items-center justify-between p-3 border rounded-lg">
                    <div>
                      <div className="flex items-center space-x-2">
                        <span className="font-medium">{roll.playerName}</span>
                        <Badge variant="outline">{roll.diceType}</Badge>
                        <span className="text-lg font-bold text-primary">{roll.result}</span>
                      </div>
                      <p className="text-xs text-muted-foreground">{roll.context}</p>
                      <p className="text-xs text-muted-foreground">
                        {roll.timestamp.toLocaleTimeString()}
                      </p>
                    </div>
                    <div>
                      {roll.validated ? (
                        <CheckCircle className="h-5 w-5 text-green-500" />
                      ) : (
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => validateRoll(roll.id)}
                        >
                          <CheckCircle className="h-4 w-4" />
                        </Button>
                      )}
                    </div>
                  </div>
                ))
              )}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Instructions */}
      <Card className="border-blue-200 bg-blue-50/50">
        <CardHeader>
          <CardTitle className="text-blue-800">How Physical Dice Integration Works</CardTitle>
        </CardHeader>
        <CardContent className="text-blue-700">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <h4 className="font-semibold mb-2">1. Start a Session</h4>
              <p className="text-sm">Click "Start Dice Session" and share the room code with your players.</p>
            </div>
            <div>
              <h4 className="font-semibold mb-2">2. Players Connect</h4>
              <p className="text-sm">Players use the room code to connect their devices or dice apps.</p>
            </div>
            <div>
              <h4 className="font-semibold mb-2">3. Roll & Validate</h4>
              <p className="text-sm">Physical rolls are submitted and you validate them for authenticity.</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
