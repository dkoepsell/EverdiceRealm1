
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dice6, Map, Swords, Star } from "lucide-react";

const encounters = {
  forest: {
    easy: ["1d4 Wolves", "1 Brown Bear", "2d4 Bandits", "1 Giant Spider"],
    medium: ["1 Owlbear", "2d4 Orcs", "1 Displacer Beast", "3d4 Wolves"],
    hard: ["1 Shambling Mound", "1 Troll", "2d4 Dire Wolves", "1 Green Dragon Wyrmling"],
    deadly: ["1 Adult Green Dragon", "2 Trolls", "1 Treant (hostile)", "4d4 Owlbears"]
  },
  dungeon: {
    easy: ["2d4 Goblins", "1d4 Skeletons", "1 Gelatinous Cube", "2 Giant Rats"],
    medium: ["1d4 Hobgoblins", "2d4 Zombies", "1 Minotaur", "1 Rust Monster"],
    hard: ["1 Beholder", "2d4 Ghouls", "1 Mind Flayer", "1 Aboleth"],
    deadly: ["1 Lich", "1 Ancient Black Dragon", "2 Beholders", "1 Kraken"]
  },
  city: {
    easy: ["1d4 Thugs", "2d4 Commoners (riot)", "1 Spy", "1d4 Guards"],
    medium: ["1 Assassin", "2d4 Cultists", "1 Mage", "1d4 Veterans"],
    hard: ["1 Archmage", "2d4 Gladiators", "1 Crime Boss", "1 Noble with bodyguards"],
    deadly: ["1 Ancient Dragon (disguised)", "1 Powerful Lich", "Army of cultists", "1 Demon Lord"]
  },
  wilderness: {
    easy: ["1d4 Giant Eagles", "2 Hippogriffs", "1d4 Elk", "1 Pegasus"],
    medium: ["1 Griffon", "2d4 Centaurs", "1 Wyvern", "1d4 Giant Eagles"],
    hard: ["1 Roc", "2 Young Dragons", "1 Storm Giant", "4d4 Centaurs"],
    deadly: ["1 Ancient Dragon", "2 Adult Dragons", "1 Tarrasque", "Army of giants"]
  }
};

const treasures = {
  easy: ["50-100 gp", "1d4 gems (50 gp each)", "Potion of Healing", "Silvered weapon"],
  medium: ["200-500 gp", "Magic weapon +1", "Ring of Protection", "Bag of Holding"],
  hard: ["1000-2000 gp", "Magic armor +1", "Wand of Magic Missiles", "Cloak of Elvenkind"],
  deadly: ["5000+ gp", "Legendary magic item", "Artifact fragment", "Wish scroll"]
};

const complications = [
  "The weather suddenly changes", "NPCs are not what they seem", "Time is running out",
  "Someone is watching", "A rival group appears", "The ground is unstable",
  "Magic doesn't work properly here", "The encounter is a distraction", "Innocent bystanders are present",
  "The real threat is hidden"
];

export default function EncounterGenerator() {
  const [encounter, setEncounter] = useState<any>(null);
  const [environment, setEnvironment] = useState<string>("");
  const [difficulty, setDifficulty] = useState<string>("");

  const generateEncounter = () => {
    if (!environment || !difficulty) return;

    const encounterList = encounters[environment as keyof typeof encounters][difficulty as keyof typeof encounters['forest']];
    const treasureList = treasures[difficulty as keyof typeof treasures];
    
    const newEncounter = {
      environment,
      difficulty,
      enemies: encounterList[Math.floor(Math.random() * encounterList.length)],
      treasure: treasureList[Math.floor(Math.random() * treasureList.length)],
      complication: complications[Math.floor(Math.random() * complications.length)],
      description: generateDescription(environment)
    };
    
    setEncounter(newEncounter);
  };

  const generateDescription = (env: string) => {
    const descriptions = {
      forest: "Dense trees create shadows that shift and move. The air is thick with the scent of moss and decay.",
      dungeon: "Stone corridors echo with distant sounds. Torchlight flickers against damp walls covered in ancient runes.",
      city: "Narrow alleyways wind between tall buildings. The sounds of city life mask approaching danger.",
      wilderness: "Open terrain stretches to the horizon. The wind carries scents and sounds from far away."
    };
    return descriptions[env as keyof typeof descriptions];
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Swords className="h-5 w-5" />
          Random Encounter Generator
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid grid-cols-2 gap-4">
          <Select value={environment} onValueChange={setEnvironment}>
            <SelectTrigger>
              <SelectValue placeholder="Environment" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="forest">Forest</SelectItem>
              <SelectItem value="dungeon">Dungeon</SelectItem>
              <SelectItem value="city">City</SelectItem>
              <SelectItem value="wilderness">Wilderness</SelectItem>
            </SelectContent>
          </Select>

          <Select value={difficulty} onValueChange={setDifficulty}>
            <SelectTrigger>
              <SelectValue placeholder="Difficulty" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="easy">Easy</SelectItem>
              <SelectItem value="medium">Medium</SelectItem>
              <SelectItem value="hard">Hard</SelectItem>
              <SelectItem value="deadly">Deadly</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <Button onClick={generateEncounter} className="w-full" disabled={!environment || !difficulty}>
          <Dice6 className="h-4 w-4 mr-2" />
          Generate Encounter
        </Button>

        {encounter && (
          <div className="space-y-4">
            <div className="flex items-center gap-2">
              <Badge variant="outline">{encounter.environment}</Badge>
              <Badge className={
                encounter.difficulty === 'easy' ? 'bg-green-500' :
                encounter.difficulty === 'medium' ? 'bg-yellow-500' :
                encounter.difficulty === 'hard' ? 'bg-orange-500' : 'bg-red-500'
              }>
                {encounter.difficulty}
              </Badge>
            </div>

            <div className="space-y-2">
              <p><span className="font-medium">Setting:</span> {encounter.description}</p>
              <p><span className="font-medium">Enemies:</span> {encounter.enemies}</p>
              <p><span className="font-medium">Potential Treasure:</span> {encounter.treasure}</p>
              <p><span className="font-medium">Complication:</span> {encounter.complication}</p>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
