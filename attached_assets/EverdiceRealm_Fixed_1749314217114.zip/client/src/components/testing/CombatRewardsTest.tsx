import React from 'react';
import { Button } from '@/components/ui/button';
import { apiRequest } from '@/lib/queryClient';
import { queryClient } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';

interface CombatRewardsTestProps {
  campaignId: number;
}

export function CombatRewardsTest({ campaignId }: CombatRewardsTestProps) {
  const { toast } = useToast();
  
  const testRewards = {
    xp: 250,
    gold: 75,
    items: [
      {
        id: 1001,
        name: "Healing Potion",
        description: "Restores 2d4+2 hit points when consumed.",
        rarity: "common",
        type: "potion"
      },
      {
        id: 1002,
        name: "Moon-Touched Sword",
        description: "This sword glows with moonlight, creating dim light in a 15-foot radius.",
        rarity: "common",
        type: "weapon",
        slot: "weapon",
        equipped: false
      }
    ]
  };

  const handleTestRewards = async () => {
    try {
      // Call the character rewards API
      const response = await apiRequest('POST', `/api/campaigns/${campaignId}/character/reward`, testRewards);
      
      // Show success message
      toast({
        title: "Combat Rewards Test Successful",
        description: `Added ${testRewards.xp} XP, ${testRewards.gold} gold, and ${testRewards.items.length} items to your character.`,
        variant: "default"
      });
      
      // Invalidate character queries to refresh data
      queryClient.invalidateQueries({ queryKey: ['/api/characters'] });
      
      console.log('Combat rewards test response:', response);
    } catch (error) {
      // Show error message
      toast({
        title: "Combat Rewards Test Failed",
        description: "Failed to apply combat rewards. Check the console for details.",
        variant: "destructive"
      });
      
      console.error('Combat rewards test error:', error);
    }
  };
  
  return (
    <Button 
      onClick={handleTestRewards}
      className="fixed bottom-4 right-4 z-50 bg-green-600 hover:bg-green-700"
    >
      Test Combat Rewards
    </Button>
  );
}