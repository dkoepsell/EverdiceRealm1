import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/hooks/use-toast';
import { useMutation } from '@tanstack/react-query';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { apiRequest } from '@/lib/queryClient';
import { Badge } from '@/components/ui/badge';
import { MessageSquare, User, Dice1 } from 'lucide-react';
import { RulesReference } from '@/components/ui/rules-reference';
import { rollDice } from '@/lib/diceUtils';
import { cn } from '@/lib/utils';

// NPC interaction types
interface NPC {
  id: number;
  name: string;
  race: string;
  occupation: string | null;
  personality: string | null;
  description: string | null;
  location: string | null;
  portraitUrl: string | null;
}

interface NPCInteractionHandlerProps {
  campaignId: number;
  sessionId: number;
  npc: NPC;
  characterId?: number;
  isOpen: boolean;
  onClose: () => void;
  onInteractionComplete: (result: any) => void;
}

export function NPCInteractionHandler({
  campaignId,
  sessionId,
  npc,
  characterId,
  isOpen,
  onClose,
  onInteractionComplete
}: NPCInteractionHandlerProps) {
  const [playerInput, setPlayerInput] = useState('');
  const [conversation, setConversation] = useState<{
    speaker: 'player' | 'npc';
    text: string;
    timestamp: Date;
    diceRoll?: {
      type: string;
      result: number;
      success: boolean;
    };
  }[]>([
    {
      speaker: 'npc',
      text: `*${npc.name} notices your approach*`,
      timestamp: new Date()
    }
  ]);
  const [isGeneratingResponse, setIsGeneratingResponse] = useState(false);
  const [showPredefinedResponses, setShowPredefinedResponses] = useState(true);
  const [activeSkillCheck, setActiveSkillCheck] = useState<string | null>(null);
  
  const { toast } = useToast();
  
  // Common D&D dialogue options based on skills
  const predefinedResponses = [
    { text: "Hello there! I'm looking for information.", skill: null },
    { text: "Do you know anything about recent events in this area?", skill: null },
    { text: `Tell me about yourself, ${npc.name}.`, skill: null },
    { text: "I'd like to ask you about the local threats.", skill: null },
    { text: "I'm looking for work. Do you have any tasks that need doing?", skill: null },
    { text: "I'd like to negotiate a better price. [Persuasion]", skill: "persuasion" },
    { text: "I think you're hiding something from me. [Insight]", skill: "insight" },
    { text: "Perhaps you'd be willing to share more for some coin... [Intimidation]", skill: "intimidation" },
    { text: "I've heard rumors about you. [Deception]", skill: "deception" }
  ];
  
  // Handle NPC response generation with OpenAI
  const generateResponseMutation = useMutation({
    mutationFn: async (input: string) => {
      const response = await apiRequest('POST', '/api/npc/generate-response', {
        campaignId,
        npcId: npc.id,
        playerAction: input,
        playerCharacterId: characterId
      });
      return await response.json();
    },
    onSuccess: (data) => {
      setConversation(prev => [
        ...prev,
        {
          speaker: 'npc',
          text: data.response,
          timestamp: new Date()
        }
      ]);
      setIsGeneratingResponse(false);
      setPlayerInput('');
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to generate response",
        description: error.message,
        variant: "destructive"
      });
      setIsGeneratingResponse(false);
      
      // Fallback response
      setConversation(prev => [
        ...prev,
        {
          speaker: 'npc',
          text: `*${npc.name} seems unsure how to respond and remains silent.*`,
          timestamp: new Date()
        }
      ]);
    }
  });
  
  // Handle skill check for certain interactions
  const handleSkillCheck = (skill: string) => {
    setActiveSkillCheck(skill);
    
    // Roll for the skill check (d20 + skill modifier)
    // For demo purposes, we'll use a simple modifier
    const skillModifiers: Record<string, number> = {
      'persuasion': 2,
      'insight': 1, 
      'intimidation': 3,
      'deception': 2
    };
    
    const modifier = skillModifiers[skill] || 0;
    const { result, total } = rollDice('d20', modifier);
    
    // Determine success based on difficulty class (DC)
    // DC varies by skill and situation, but we'll use 15 as a standard value
    const DC = 15;
    const success = total >= DC;
    
    // Add the skill check to the conversation
    setConversation(prev => [
      ...prev,
      {
        speaker: 'player',
        text: `*${skill.charAt(0).toUpperCase() + skill.slice(1)} Check*`,
        timestamp: new Date(),
        diceRoll: {
          type: `1d20+${modifier}`,
          result: total,
          success
        }
      }
    ]);
    
    // After short delay, add the NPC response
    setTimeout(() => {
      // Generate NPC response based on skill check result
      const playerAction = `I rolled a ${total} on my ${skill} check (${success ? 'success' : 'failure'} against DC ${DC}) and want to ${
        skill === 'persuasion' ? 'persuade you to help me' :
        skill === 'insight' ? 'understand your true intentions' :
        skill === 'intimidation' ? 'intimidate you into cooperation' :
        skill === 'deception' ? 'deceive you' : 'interact with you'
      }.`;
      
      setActiveSkillCheck(null);
      setIsGeneratingResponse(true);
      generateResponseMutation.mutate(playerAction);
    }, 1500);
  };
  
  // Submit a custom player message
  const handleSubmitMessage = () => {
    if (!playerInput.trim() || isGeneratingResponse) return;
    
    // Add player message to conversation
    setConversation(prev => [
      ...prev, 
      {
        speaker: 'player',
        text: playerInput,
        timestamp: new Date()
      }
    ]);
    
    // Generate NPC response
    setIsGeneratingResponse(true);
    generateResponseMutation.mutate(playerInput);
  };
  
  // Use a predefined response
  const handlePredefinedResponse = (response: string, skill: string | null) => {
    if (isGeneratingResponse) return;
    
    // Add player message to conversation
    setConversation(prev => [
      ...prev, 
      {
        speaker: 'player',
        text: response,
        timestamp: new Date()
      }
    ]);
    
    // If this response requires a skill check
    if (skill) {
      handleSkillCheck(skill);
      return;
    }
    
    // Otherwise generate normal NPC response
    setIsGeneratingResponse(true);
    generateResponseMutation.mutate(response);
  };
  
  // Complete the interaction
  const handleCompleteInteraction = () => {
    onInteractionComplete({
      npcId: npc.id,
      conversation,
      completedAt: new Date().toISOString()
    });
    onClose();
  };
  
  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-3xl max-h-[90vh] overflow-hidden flex flex-col">
        <DialogHeader>
          <DialogTitle className="flex items-center">
            <span>Conversation with {npc.name}</span>
            <Badge variant="outline" className="ml-2">
              {npc.race} {npc.occupation}
            </Badge>
          </DialogTitle>
          <DialogDescription>
            {npc.description || `A ${npc.race} found in ${npc.location || 'this area'}.`}
          </DialogDescription>
        </DialogHeader>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 overflow-hidden flex-grow">
          {/* Left side - NPC portrait and info */}
          <div className="hidden md:block">
            <Card className="h-full">
              <CardContent className="p-4 flex flex-col items-center justify-between h-full">
                <div className="space-y-2 w-full">
                  <div className="w-full aspect-square overflow-hidden rounded-lg bg-muted mb-4">
                    {npc.portraitUrl ? (
                      <img 
                        src={npc.portraitUrl} 
                        alt={npc.name}
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center bg-muted text-muted-foreground">
                        <User className="h-16 w-16 opacity-40" />
                      </div>
                    )}
                  </div>
                  
                  <div className="space-y-1">
                    <h3 className="font-semibold">{npc.name}</h3>
                    <p className="text-sm text-muted-foreground">{npc.race} {npc.occupation}</p>
                    {npc.personality && (
                      <p className="text-xs italic">"{npc.personality}"</p>
                    )}
                  </div>
                </div>
                
                <div className="space-y-2 w-full mt-4">
                  <Button 
                    variant="outline" 
                    size="sm"
                    className="w-full"
                    onClick={handleCompleteInteraction}
                  >
                    End Conversation
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
          
          {/* Right side - Conversation */}
          <div className="col-span-1 md:col-span-2 flex flex-col overflow-hidden">
            <Card className="flex flex-col h-full overflow-hidden">
              <CardHeader className="bg-primary text-primary-foreground py-2">
                <CardTitle className="text-sm flex items-center">
                  <MessageSquare className="h-4 w-4 mr-1" />
                  Conversation
                </CardTitle>
              </CardHeader>
              
              <CardContent className="flex-grow overflow-y-auto p-4 space-y-3 bg-card-parchment min-h-[300px]">
                {conversation.map((message, index) => (
                  <div 
                    key={index}
                    className={cn(
                      "p-3 rounded-lg max-w-[85%]",
                      message.speaker === 'npc' 
                        ? "bg-muted ml-0 mr-auto" 
                        : "bg-primary/10 ml-auto mr-0"
                    )}
                  >
                    <div className="font-semibold text-xs mb-1">
                      {message.speaker === 'npc' ? npc.name : 'You'}
                    </div>
                    
                    <div>
                      {message.diceRoll ? (
                        <div className="space-y-1">
                          <div className="text-sm">{message.text}</div>
                          <div className="flex items-center text-xs bg-background/50 p-1 rounded">
                            <Dice1 className="h-3 w-3 mr-1" />
                            <span>{message.diceRoll.type}: </span>
                            <span 
                              className={cn(
                                "font-mono ml-1",
                                message.diceRoll.success ? "text-green-600" : "text-red-600"
                              )}
                            >
                              {message.diceRoll.result}
                            </span>
                            <span className="ml-1">
                              ({message.diceRoll.success ? "Success" : "Failure"})
                            </span>
                          </div>
                        </div>
                      ) : (
                        <div className="text-sm">{message.text}</div>
                      )}
                    </div>
                  </div>
                ))}
                
                {isGeneratingResponse && (
                  <div className="bg-muted p-3 rounded-lg ml-0 mr-auto max-w-[85%]">
                    <div className="font-semibold text-xs mb-1">{npc.name}</div>
                    <div className="flex space-x-2">
                      <div className="h-2 w-2 bg-primary/50 rounded-full animate-bounce" style={{ animationDelay: '0ms' }}></div>
                      <div className="h-2 w-2 bg-primary/50 rounded-full animate-bounce" style={{ animationDelay: '200ms' }}></div>
                      <div className="h-2 w-2 bg-primary/50 rounded-full animate-bounce" style={{ animationDelay: '400ms' }}></div>
                    </div>
                  </div>
                )}
              </CardContent>
              
              <CardFooter className="bg-card p-4 border-t">
                <div className="w-full space-y-3">
                  {/* Common response options */}
                  {showPredefinedResponses && (
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-2 mb-2">
                      {predefinedResponses.slice(0, 6).map((response, index) => (
                        <Button
                          key={index}
                          variant="outline"
                          size="sm"
                          className="justify-start overflow-hidden"
                          onClick={() => handlePredefinedResponse(response.text, response.skill)}
                          disabled={isGeneratingResponse || !!activeSkillCheck}
                        >
                          <span className="truncate">{response.text}</span>
                        </Button>
                      ))}
                    </div>
                  )}
                  
                  <div className="flex items-end gap-2">
                    <div className="flex-grow">
                      <Textarea 
                        placeholder="Type your message..."
                        value={playerInput}
                        onChange={(e) => setPlayerInput(e.target.value)}
                        disabled={isGeneratingResponse || !!activeSkillCheck}
                        className="resize-none"
                        rows={2}
                        onKeyDown={(e) => {
                          if (e.key === 'Enter' && !e.shiftKey) {
                            e.preventDefault();
                            handleSubmitMessage();
                          }
                        }}
                      />
                    </div>
                    
                    <div className="flex flex-col gap-2">
                      <Button
                        onClick={handleSubmitMessage}
                        disabled={!playerInput.trim() || isGeneratingResponse || !!activeSkillCheck}
                        size="sm"
                      >
                        Send
                      </Button>
                      
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => setShowPredefinedResponses(!showPredefinedResponses)}
                        title={showPredefinedResponses ? "Hide suggestions" : "Show suggestions"}
                      >
                        {showPredefinedResponses ? "Hide" : "Suggest"}
                      </Button>
                    </div>
                  </div>
                  
                  <div className="text-xs text-muted-foreground">
                    <RulesReference term="ability-check">
                      Skill checks like Persuasion or Insight
                    </RulesReference> can influence NPC interactions. Use the suggested dialogues or write your own.
                  </div>
                </div>
              </CardFooter>
            </Card>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}