import React, { useState } from 'react';
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Sword, User, MapPin, Book, DollarSign } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { RulesReference } from "@/components/ui/rules-reference";
import CombatEncounterHandler from "./CombatEncounterHandler";
import { NPCInteractionHandler } from "./NPCInteractionHandler";
import { rollDice } from "@/lib/diceUtils";

interface CampaignInteractionHandlerProps {
  campaignId: number;
  sessionId: number;
  narrative: string;
  location: string;
  choices: Array<{
    action: string;
    description: string;
    requiresDiceRoll?: boolean;
    diceType?: string;
    rollDC?: number;
    abilityType?: string;
    rollModifier?: number;
    requiresRoll?: boolean;
  }>;
  onStoryAdvance: (nextSegment: any) => void;
}

export function CampaignInteractionHandler({
  campaignId,
  sessionId,
  narrative,
  location,
  choices,
  onStoryAdvance
}: CampaignInteractionHandlerProps) {
  const [isAdvancingStory, setIsAdvancingStory] = useState(false);
  const [currentEncounter, setCurrentEncounter] = useState<any>(null);
  const [currentNpc, setCurrentNpc] = useState<any>(null);
  const [customAction, setCustomAction] = useState('');
  const [activeSkillCheck, setActiveSkillCheck] = useState<{
    action: string;
    description: string;
    diceType: string;
    rollDC: number;
    abilityType: string;
    rollModifier: number;
    result?: {
      roll: number;
      total: number;
      success: boolean;
    }
  } | null>(null);
  const [isStreaming, setIsStreaming] = useState(false);
  const [narrativeBuffer, setNarrativeBuffer] = useState('');
  const [lastDiceRoll, setLastDiceRoll] = useState<any>(null);

  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Advance story mutation
  const advanceStoryMutation = useMutation({
    mutationFn: async (actionData: { 
      action: string; 
      skillCheckResult?: any;
      requestCombat?: boolean;
      combatOutcome?: string;
      npcInteraction?: any;
    }) => {
      // Prepare payload
      const payload = {
        campaignId,
        sessionId,
        action: actionData.action,
        location,
        requestCombat: actionData.requestCombat || false,
        skillCheckResult: actionData.skillCheckResult,
        combatOutcome: actionData.combatOutcome || null,
        npcInteraction: actionData.npcInteraction || null
      };

      // Send request to advance story
      const response = await apiRequest('POST', '/api/campaigns/advance-story', payload);
      return await response.json();
    },
    onSuccess: (data) => {
      // Check if the story advancement triggers a combat encounter
      if (data.encounterTriggered) {
        setCurrentEncounter(data.encounter);
      }
      // Check if the story advancement triggers an NPC interaction
      else if (data.npcInteraction) {
        setCurrentNpc(data.npc);
      }
      // Otherwise, just advance the story
      else {
        onStoryAdvance(data);
      }

      setIsAdvancingStory(false);
      setCustomAction('');
      setActiveSkillCheck(null);
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to advance story",
        description: error.message,
        variant: "destructive"
      });
      setIsAdvancingStory(false);
    }
  });

  // Handle player choice selection
  const handleChoiceSelected = async (choice: any) => {
    if (isAdvancingStory) return;
    setIsAdvancingStory(true);

    if (choice.requiresDiceRoll || choice.requiresRoll) {
      handleDiceRoll(choice);
    } else {
      setCustomAction(choice.action);
      handleCustomActionStreaming();
    }
  };

  const handleCustomActionSubmit = async () => {
    if (!customAction.trim() || isAdvancingStory) return;
    setIsAdvancingStory(true);
    handleCustomActionStreaming();
  };

  const handleCustomActionStreaming = async () => {
    setIsStreaming(true);
    setNarrativeBuffer("");

    try {
      const response = await fetch('/api/dm/stream', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          sessionHistory: [],
          location,
          narrative,
          characters: 'A party of adventurers',
          lastChoice: {
            action: customAction,
            skillCheckResult: lastDiceRoll?.skillCheckResult
          }
        })
      });

      if (!response.body) {
        throw new Error('Response body is empty');
      }

      const reader = response.body.getReader();
      const decoder = new TextDecoder();
      let buffer = '';

      const processStream = async () => {
        try {
          const { done, value } = await reader.read();

          if (done) {
            setIsStreaming(false);
            try {
              const dmResponse = JSON.parse(buffer);
              onStoryAdvance(dmResponse);
            } catch (error) {
              console.error("Failed to parse full JSON:", error);
              toast({
                title: "DM Error",
                description: "Failed to parse the AI response. Please try again.",
                variant: "destructive"
              });
            } finally {
              setIsAdvancingStory(false);
              setCustomAction('');
            }
            return;
          }

          buffer += decoder.decode(value);
          setNarrativeBuffer(buffer);
          processStream();
        } catch (error) {
          console.error("Streaming error:", error);
          toast({
            title: "DM Error", 
            description: "Failed to process your action. Please try again.",
            variant: "destructive"
          });
          setIsAdvancingStory(false);
          setIsStreaming(false);
          setCustomAction('');
          reader.cancel();
        }
      };

      processStream();

    } catch (error) {
      toast({
        title: "DM Error",
        description: "Failed to process your action. Please try again.",
        variant: "destructive"
      });
      setIsAdvancingStory(false);
      setIsStreaming(false);
      setCustomAction('');
    }
  };

  const handleDiceRoll = async (choice: any) => {
    const result = await rollDice({
      diceType: choice.diceType || 'd20',
      rollDC: choice.rollDC,
      rollModifier: choice.rollModifier,
      action: choice.action
    });

    if (result) {
      const rollTotal = result.total;
      const dc = choice.rollDC || 15;
      setLastChoice({
        action: choice.action,
        skillCheckResult: {
          abilityType: choice.abilityType || 'ability',
          roll: result.rolls[0],
          dc: dc,
          success: rollTotal >= dc
        }
      });
      setCustomAction(choice.action);
      handleCustomActionStreaming();
    }
  };

  const handleChoiceSelected = async (choice: any) => {
    if (isAdvancingStory) return;

    setIsAdvancingStory(true);
    setCustomAction(choice.action);

    if (choice.requiresDiceRoll || choice.requiresRoll) {
      const rollRequest = {
        diceType: choice.diceType || "d20",
        count: 1,
        modifier: choice.rollModifier || 0,
        purpose: `${choice.abilityType || 'Ability'} Check for "${choice.action}"`,
        characterId: null
      };

      try {
        const response = await fetch('/api/dice/roll', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(rollRequest)
        });

        const rollResult = await response.json();
        const success = rollResult.total >= (choice.rollDC || 15);

        setLastChoice({
          action: choice.action,
          skillCheckResult: {
            roll: rollResult.rolls[0],
            dc: choice.rollDC || 15,
            success,
            abilityType: choice.abilityType || 'wisdom'
          }
        });

        await handleCustomActionStreaming();
      } catch (error) {
        console.error("Dice roll failed", error);
        toast({ 
          title: "Dice Roll Error", 
          description: error.message,
          variant: "destructive"
        });
        setIsAdvancingStory(false);
      }
    } else {
      setLastChoice({ 
        action: choice.action,
        skillCheckResult: null
      });
      await handleCustomActionStreaming();
    }
  };

  const handleCustomActionSubmit = async () => {
    if (!customAction.trim() || isAdvancingStory) return;
    setIsAdvancingStory(true);
    setLastChoice({
      action: customAction,
      skillCheckResult: null
    });
    await handleCustomActionStreaming();
  };

  const handleCustomActionStreaming = async () => {
    setIsStreaming(true);
    setNarrativeBuffer('');

    try {
      const response = await fetch('/api/dm/stream', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          sessionHistory: sessionHistory?.slice(-3) || [],
          location,
          narrative,
          characters: 'A party of adventurers',
          lastChoice: {
            action: lastChoice?.action || customAction,
            skillCheckResult: lastChoice?.skillCheckResult || null
          }
        })
      });

      if (!response.body) {
        throw new Error('Response body is empty');
      }

      const reader = response.body.getReader();
      const decoder = new TextDecoder();
      let buffer = '';

      const processStream = async () => {
        try {
          const { done, value } = await reader.read();

          if (done) {
            setIsStreaming(false);
            try {
              const dmResponse = JSON.parse(buffer);
              // Replace advance story mutation with direct state update
              onStoryAdvance(dmResponse);
            } catch (error) {
              console.error('Failed to parse GPT response:', error);
              toast({
                title: 'DM Error',
                description: 'Failed to process the story response. Please try again.',
                variant: 'destructive'
              });
            } finally {
              setIsAdvancingStory(false);
              setCustomAction('');
              setLastChoice(null);
            }
            return;
          }

          buffer += decoder.decode(value);
          setNarrativeBuffer(buffer);
          processStream();
        } catch (error) {
          console.error('GPT streaming error:', error);
          toast({
            title: 'DM Error',
            description: 'Failed to process your action. Please try again.',
            variant: 'destructive'
          });
          setIsAdvancingStory(false);
          setIsStreaming(false);
          setCustomAction('');
          reader.cancel();
        }
      };

      processStream();
    } catch (error) {
      console.error('GPT streaming request failed:', error);
      toast({
        title: 'DM Error',
        description: 'Failed to process your action. Please try again.',
        variant: 'destructive'
      });
      setIsAdvancingStory(false);
      setIsStreaming(false);
      setCustomAction('');
    }
  };

  // Handle combat resolution
  const handleCombatResolved = (outcome: string, rewards: any) => {
    // When combat is over, advance the story with the outcome
    advanceStoryMutation.mutate({ 
      action: `Combat ${outcome === 'victory' ? 'won' : outcome === 'defeat' ? 'lost' : 'fled'}`,
      combatOutcome: outcome,
      rewards
    });

    // Only apply rewards for victories
    if (outcome === 'victory' && rewards) {
      // Send rewards to server to update character
      apiRequest('POST', `/api/campaigns/${campaignId}/character/reward`, {
        xp: rewards.xp || 0,
        gold: rewards.gold || 0,
        items: rewards.items || []
      }).then(() => {
        toast({
          title: "Rewards Applied",
          description: "XP, gold, and items have been added to your character.",
          variant: "default"
        });
      }).catch(error => {
        console.error("Failed to apply rewards:", error);
        toast({
          title: "Failed to Apply Rewards",
          description: "There was an error updating your character. Please try again.",
          variant: "destructive"
        });
      });
    }

    setCurrentEncounter(null);
  };

  // Handle NPC interaction completion
  const handleNpcInteractionComplete = (result: any) => {
    // When NPC interaction is complete, advance the story with the result
    advanceStoryMutation.mutate({ 
      action: `Spoke with ${result.npcName || 'an NPC'}`,
      npcInteraction: result
    });

    setCurrentNpc(null);
  };

  // If we're in a combat encounter, render the combat handler
  if (currentEncounter) {
    return (
      <CombatEncounterHandler
        campaignId={campaignId}
        sessionId={sessionId}
        onCombatResolved={handleCombatResolved}
      />
    );
  }

  // If we're in an NPC interaction, render the NPC handler
  if (currentNpc) {
    return (
      <NPCInteractionHandler
        campaignId={campaignId}
        sessionId={sessionId}
        npc={currentNpc}
        characterId={1} // This should be the current player's character ID
        isOpen={true}
        onClose={() => setCurrentNpc(null)}
        onInteractionComplete={handleNpcInteractionComplete}
      />
    );
  }

  return (
    <div className="space-y-4">
      {/* Narrative Display */}
      <Card className="bg-parchment border-amber-800">
        <CardHeader className="pb-2 border-b border-amber-200">
          <div className="flex justify-between items-center">
            <CardTitle className="text-amber-900 flex items-center">
              <Book className="mr-2 h-5 w-5" />
              Journey
            </CardTitle>
            <Badge variant="outline" className="bg-amber-100">
              <MapPin className="h-3 w-3 mr-1" />
              {location}
            </Badge>
          </div>
        </CardHeader>
        <CardContent className="pt-4 font-fantasy text-lg">
          <p>{isStreaming ? narrativeBuffer : narrative}</p>
        </CardContent>
      </Card>

      {/* Skill Check Display */}
      {activeSkillCheck && (
        <Card className="border-2 border-blue-600 bg-blue-50">
          <CardHeader className="pb-2">
            <CardTitle className="text-blue-800 flex items-center text-base">
              <RulesReference term="ability-check">Ability Check</RulesReference>: {
                activeSkillCheck.abilityType.charAt(0).toUpperCase() + activeSkillCheck.abilityType.slice(1)
              }
            </CardTitle>
          </CardHeader>
          <CardContent className="pb-2">
            <p className="text-sm mb-2">{activeSkillCheck.description}</p>

            {activeSkillCheck.result ? (
              <div className="bg-white p-3 rounded-md border border-blue-200">
                <div className="flex items-center justify-between">
                  <span className="font-medium">Result: {activeSkillCheck.result.total}</span>
                  <Badge 
                    variant={activeSkillCheck.result.success ? "success" : "destructive"}
                    className={activeSkillCheck.result.success ? "bg-green-100 text-green-800" : "bg-red-100 text-red-800"}
                  >
                    {activeSkillCheck.result.success ? "Success" : "Failure"}
                  </Badge>
                </div>
                <div className="text-xs mt-1 text-muted-foreground">
                  Rolled {activeSkillCheck.result.roll} + {activeSkillCheck.rollModifier} modifier vs DC {activeSkillCheck.rollDC}
                </div>
              </div>
            ) : (
              <div className="flex justify-center py-2">
                <div className="animate-pulse flex space-x-4">
                  <div className="rounded-full bg-blue-200 h-8 w-8"></div>
                  <div className="flex-1 space-y-2 py-1">
                    <div className="h-2 bg-blue-200 rounded"></div>
                    <div className="h-2 bg-blue-200 rounded w-5/6"></div>
                  </div>
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      )}

      {/* Choices */}
      {!isAdvancingStory && !activeSkillCheck && (
        <Card className="border-amber-300">
          <CardHeader className="pb-2">
            <CardTitle className="text-amber-800 text-base">What will you do?</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            {choices.map((choice, index) => (
              <Button 
                key={index}
                variant="outline"
                className="w-full justify-start"
                onClick={() => handleChoiceSelected(choice)}
              >
                <div className="flex items-center">
                  {choice.requiresDiceRoll ? (
                    <div className="h-4 w-4 mr-2 text-amber-500">🎲</div>
                  ) : (
                    <Sword className="h-4 w-4 mr-2 text-amber-500" />
                  )}
                </div>
                <div className="text-left">
                  <div>{choice.action}</div>
                  {choice.description && (
                    <div className="text-xs text-muted-foreground">{choice.description}</div>
                  )}
                </div>
                {choice.requiresDiceRoll && (
                  <Badge className="ml-auto" variant="outline">
                    {choice.diceType || 'd20'} {choice.abilityType || 'check'}
                  </Badge>
                )}
              </Button>
            ))}

            <div className="pt-2 border-t border-amber-100">
              <div className="text-sm text-muted-foreground mb-2">Or enter your own action:</div>
              <div className="flex space-x-2">
                <Textarea 
                  placeholder="Describe what you want to do..."
                  value={customAction}
                  onChange={(e) => setCustomAction(e.target.value)}
                  className="resize-none"
                />
                <Button 
                  onClick={handleCustomActionSubmit}
                  disabled={!customAction.trim() || isAdvancingStory}
                >
                  {isStreaming ? 'Processing...' : 'Act'}
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Loading State */}
      {isAdvancingStory && !activeSkillCheck && (
        <Card className="border-amber-300">
          <CardContent className="py-8">
            <div className="flex flex-col items-center justify-center">
              <div className="animate-spin h-8 w-8 border-4 border-amber-500 border-t-transparent rounded-full mb-4"></div>
              <p className="text-amber-800">The story unfolds...</p>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}