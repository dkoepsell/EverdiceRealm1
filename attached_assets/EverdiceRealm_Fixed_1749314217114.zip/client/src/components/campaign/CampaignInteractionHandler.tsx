import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Play, 
  Pause, 
  RotateCcw, 
  Send, 
  Dice6, 
  Scroll, 
  Users, 
  Crown,
  Sword,
  Shield,
  Heart,
  Star,
  MapPin,
  ChevronRight,
  Sparkles,
  TreePine,
  Castle,
  Mountain,
  BookOpen,
  DiceD20,
  Swords,
  Wand2,
  User,
  Map,
  HelpCircle,
  Search,
  FileText
} from "lucide-react";
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { DiceRoller } from '@/components/ui/dice-roller';
import { useToast } from '@/hooks/use-toast';
import { NPCInteractionHandler } from './NPCInteractionHandler';
import { SpecialEncounterHandler } from './SpecialEncounterHandler';
import { TurnManager } from './TurnManager';
import CombatEncounterHandler from './CombatEncounterHandler';
import { SceneManager } from './SceneManager';
import { InlineTip } from "@/components/learning/DnDRulesGuide";
import DNDMechanics from "@/components/ui/dnd-mechanics";

interface CampaignInteractionHandlerProps {
  sessionHistory: string[];
  location: string;
  narrative: string;
  characters: string;
  campaignId: number;
  onStoryAdvance: (next: any) => void;
}

// Helper function to extract environmental keywords for anti-repetition
const extractEnvironmentalKeywords = (narrative: string): string[] => {
  const keywords = [];
  const environmental = ['canopy', 'sunlight', 'shadows', 'corruption', 'glow', 'whisper', 'ancient', 'mist'];

  environmental.forEach(keyword => {
    if (narrative.toLowerCase().includes(keyword)) {
      keywords.push(keyword);
    }
  });

  return keywords;
};

// Detect repetition patterns (e.g., repeated keywords, phrases)
const detectRepetitionPatterns = (sessionHistory: string[], currentNarrative: string): string[] => {
  const patterns: string[] = [];

  // Combine narratives for analysis
  const combinedNarratives = [...sessionHistory, currentNarrative].join(' ');

  // Simple pattern detection (can be expanded)
  const words = combinedNarratives.toLowerCase().split(/\s+/);
  const wordCounts: { [word: string]: number } = {};

  words.forEach(word => {
    wordCounts[word] = (wordCounts[word] || 0) + 1;
  });

  for (const word in wordCounts) {
    if (wordCounts[word] > 3 && word.length > 3) { // Adjust thresholds as needed
      patterns.push(word);
    }
  }

  return patterns;
};

export function CampaignInteractionHandler({
  sessionHistory,
  location,
  narrative,
  characters,
  campaignId,
  onStoryAdvance
}: CampaignInteractionHandlerProps) {
  const [customAction, setCustomAction] = useState('');
  const [isAdvancingStory, setIsAdvancingStory] = useState(false);
  const [lastChoice, setLastChoice] = useState<any>(null);
  const { toast } = useToast();
  const [user, setUser] = useState<any>(null); // Added user state, ensure it's populated from auth context or similar

  useEffect(() => {
    const fetchAdventureCompletions = async () => {
      try {
        const response = await fetch('/api/adventure-completions');
        if (response.ok) {
          const completions = await response.json();
          // Handle completions
        } else {
          console.warn('Adventure completions endpoint returned:', response.status);
        }
      } catch (error) {
        console.error('Error fetching adventure completions:', error);
        // Continue without blocking the app
      }
    };

    if (user) {
      fetchAdventureCompletions();
    }
  }, [user]);

  // Detect special encounters based on narrative content
  const detectSpecialEncounter = () => {
    const narrativeLower = narrative.toLowerCase();

    // Check for combat encounters first
    if (narrativeLower.includes('growl') || narrativeLower.includes('wolves') || 
        narrativeLower.includes('spectral wolves') || narrativeLower.includes('emerge from the shadows') ||
        narrativeLower.includes('fangs') || narrativeLower.includes('encircle')) {
      console.log("🐺 Combat encounter detected: Wolves");
      // This should trigger the CombatEncounterHandler instead
      return null; // Let combat handler take over
    }

    if (narrativeLower.includes('corrupted oak') || narrativeLower.includes('ancient oak')) {
      return {
        type: 'corrupted_oak' as const,
        state: {
          corruption_level: narrativeLower.includes('heavily corrupted') ? 80 : 
                           narrativeLower.includes('corrupted') ? 50 : 20,
          investigation_attempts: sessionHistory?.filter(h => 
            h.toLowerCase().includes('investigate') || h.toLowerCase().includes('examine')
          ).length || 0
        }
      };
    }

    if (narrativeLower.includes('unicorn') && (narrativeLower.includes('distressed') || narrativeLower.includes('wary'))) {
      return {
        type: 'distressed_unicorn' as const,
        state: {
          trust_level: narrativeLower.includes('trusting') ? 70 :
                      narrativeLower.includes('wary') ? 30 : 50,
          investigation_attempts: 0
        }
      };
    }

    if ((narrativeLower.includes('altar') && narrativeLower.includes('ancient')) ||
        (narrativeLower.includes('guardian') && (narrativeLower.includes('stag') || narrativeLower.includes('owl')))) {
      return {
        type: 'ancient_altar' as const,
        state: {
          ritual_progress: narrativeLower.includes('activated') ? 100 :
                          narrativeLower.includes('glowing') ? 50 : 0
        }
      };
    }

    return null;
  };

  const specialEncounter = detectSpecialEncounter();

  // NEW: Use GPT streaming instead of advance-story
  const handleGPTStreaming = async () => {
    if (!customAction.trim()) return;
    setIsAdvancingStory(true);
    console.log("🎯 Calling GPT streaming /api/dm with lastChoice:", lastChoice);

    try {
      // Enhanced payload with anti-repetition context
      const repetitionPatterns = detectRepetitionPatterns(sessionHistory?.slice(-5) || [], narrative);
      const recentNarratives = sessionHistory?.slice(-3) || [];

      const response = await fetch('/api/dm', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: lastChoice?.action || customAction,
          campaignId,
          sessionHistory: sessionHistory?.slice(-8) || [],
          location,
          narrative,
          characters,
          lastChoice: {
            action: lastChoice?.action || customAction,
            skillCheckResult: lastChoice?.skillCheckResult || null,
            combatOutcome: lastChoice?.combatOutcome || null,
            rewards: lastChoice?.rewards || null
          },
          antiRepetition: {
            recentLocations: sessionHistory?.slice(-4).map(s => s.location || 'Unknown') || [],
            recentActions: sessionHistory?.slice(-4).map(s => s.action || 'Unknown') || [],
            environmentalState: extractEnvironmentalKeywords(narrative),
            repetitionPatterns,
            recentNarratives: recentNarratives.map(s => s.substring(0, 200) + '...'), // Truncated recent stories
            shouldProgressStory: repetitionPatterns.length > 2 // Force story progression if too repetitive
          }
        })
      });

      if (!response.ok) {
        const errorText = await response.text();
        throw new Error(`Server responded with ${response.status}: ${errorText}`);
      }

      // Handle streaming response
      const reader = response.body?.getReader();
      if (!reader) throw new Error('No response body');

      let accumulatedText = '';
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;

        const chunk = new TextDecoder().decode(value);
        accumulatedText += chunk;
      }

      try {
        const result = JSON.parse(accumulatedText);
        console.log("✅ GPT streaming result:", result);
        onStoryAdvance(result);
      } catch {
        // If not JSON, treat as narrative text
        console.log("📝 GPT streaming text response:", accumulatedText);
        onStoryAdvance({
          narrative: accumulatedText,
          location,
          choices: []
        });
      }

    } catch (err) {
      console.error("🛑 GPT Streaming failed:", err);
      toast({ 
        title: "Story Error", 
        description: "The DM couldn't continue the story. Please try again.",
        variant: "destructive"
      });
    } finally {
      setIsAdvancingStory(false);
      setCustomAction('');
    }
  };

  // Handle player choice selection with streaming
  const handleChoiceSelected = async (choice: any) => {
    if (isAdvancingStory) return;
    setIsAdvancingStory(true);

    if (choice.requiresDiceRoll || choice.requiresRoll) {
      const rollRequest = {
        diceType: choice.diceType || "d20",
        count: 1,
        modifier: choice.rollModifier || 0,
        purpose: `${choice.abilityType || 'Ability'} Check for "${choice.action}"`,
        characterId: null
      };

      try {
        const rollResponse = await fetch('/api/dice/roll', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(rollRequest)
        });

        if (!rollResponse.ok) {
          const errorData = await rollResponse.json();
          throw new Error(`Dice roll failed: ${errorData.message}`);
        }

        const rollResult = await rollResponse.json();
        const success = rollResult.total >= (choice.rollDC || 15);

        console.log(`🎲 ${choice.abilityType} Check: ${rollResult.total} vs DC ${choice.rollDC} = ${success ? 'SUCCESS' : 'FAILURE'}`);

        setLastChoice({
          action: choice.action,
          skillCheckResult: {
            abilityType: choice.abilityType || 'ability',
            roll: rollResult.total,
            dc: choice.rollDC || 15,
            success,
            actionContext: choice.action
          }
        });

        // Immediately call GPT streaming with the choice action
        await callGPTStreamingWithChoice(choice.action);
      } catch (error) {
        console.error("Dice roll failed:", error);
        toast({
          title: "Roll Error",
          description: "Failed to process dice roll",
          variant: "destructive"
        });
        setIsAdvancingStory(false);
      }
    } else {
      setLastChoice({ action: choice.action });
      // Immediately call GPT streaming with the choice action
      await callGPTStreamingWithChoice(choice.action);
    }
  };

  // Dedicated function for calling GPT streaming with a specific action
  const callGPTStreamingWithChoice = async (action: string) => {
    console.log("🎯 Calling GPT streaming /api/dm with action:", action);

    try {
      const repetitionPatterns = detectRepetitionPatterns(sessionHistory?.slice(-5) || [], narrative);
      const recentNarratives = sessionHistory?.slice(-3) || [];

      const response = await fetch('/api/dm', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: action,
          campaignId,
          sessionHistory: sessionHistory?.slice(-8) || [],
          location,
          narrative,
          characters,
          lastChoice: {
            action: lastChoice?.action || action,
            skillCheckResult: lastChoice?.skillCheckResult || null,
            combatOutcome: lastChoice?.combatOutcome || null,
            rewards: lastChoice?.rewards || null
          },
          antiRepetition: {
            recentLocations: sessionHistory?.slice(-4).map((s: any) => s.location || 'Unknown') || [],
            recentActions: sessionHistory?.slice(-4).map((s: any) => s.action || 'Unknown') || [],
            environmentalState: extractEnvironmentalKeywords(narrative),
            repetitionPatterns,
            recentNarratives: recentNarratives.map((s: any) => s.substring(0, 200) + '...'),
            shouldProgressStory: repetitionPatterns.length > 2
          }
        })
      });

      if (!response.ok) {
        const errorText = await response.text();
        throw new Error(`Server responded with ${response.status}: ${errorText}`);
      }

      const reader = response.body?.getReader();
      if (!reader) throw new Error('No response body');

      let accumulatedText = '';
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;

        const chunk = new TextDecoder().decode(value);
        accumulatedText += chunk;
      }

      try {
        const result = JSON.parse(accumulatedText);
        console.log("✅ GPT streaming result:", result);
        onStoryAdvance(result);
      } catch {
        console.log("📝 GPT streaming text response:", accumulatedText);
        onStoryAdvance({
          narrative: accumulatedText,
          location,
          choices: []
        });
      }

    } catch (err) {
      console.error("🛑 GPT Streaming failed:", err);
      toast({ 
        title: "Story Error", 
        description: "The DM couldn't continue the story. Please try again.",
        variant: "destructive"
      });
    } finally {
      setIsAdvancingStory(false);
      setCustomAction('');
    }
  };

  const handleCustomActionSubmit = async () => {
    if (!customAction.trim() || isAdvancingStory) return;
    setLastChoice({ action: customAction });
    await handleGPTStreaming();
  };

  // Handle combat resolution with streaming
  const handleCombatResolved = async (outcome: string, rewards: any) => {
    setLastChoice({ 
      action: `Combat ${outcome === 'victory' ? 'won' : outcome === 'defeat' ? 'lost' : 'fled'}`,
      combatOutcome: outcome,
      rewards
    });

    setCustomAction(`Combat resolved: ${outcome}`);
    await handleGPTStreaming();

    // Apply rewards for victories
    if (outcome === 'victory' && rewards) {
      try {
        await fetch(`/api/campaigns/${campaignId}/character/reward`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            xp: rewards.xp || 0,
            gold: rewards.gold || 0,
            items: rewards.items || []
          })
        });

        toast({
          title: "Rewards Applied",
          description: "XP, gold, and items have been added to your character.",
        });
      } catch (error) {
        console.error("Failed to apply rewards:", error);
        toast({
          title: "Failed to Apply Rewards",
          description: "There was an error updating your character.",
          variant: "destructive"
        });
      }
    }
  };

  // If this is a special encounter, use the specialized handler
  if (specialEncounter) {
    return (
      <div className="space-y-4">
        <Card className="bg-parchment border-amber-800">
          <CardHeader className="pb-2 border-b border-amber-200">
            <CardTitle className="text-amber-900">Adventure</CardTitle>
          </CardHeader>
          <CardContent className="pt-4 font-fantasy text-lg">
            <p>{narrative}</p>
          </CardContent>
        </Card>

        <SpecialEncounterHandler
          encounterType={specialEncounter.type}
          encounterState={specialEncounter.state}
          onActionSubmit={handleChoiceSelected}
          isProcessing={isAdvancingStory}
        />
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <Card className="bg-parchment border-amber-800">
        <CardHeader className="pb-2 border-b border-amber-200">
          <CardTitle className="text-amber-900">Adventure</CardTitle>
        </CardHeader>
        <CardContent className="pt-4 font-fantasy text-lg">
          <p>{narrative}</p>
        </CardContent>
      </Card>

      <Card className="border-amber-300">
        <CardHeader className="pb-2">
          <CardTitle className="text-amber-800 text-base">What will you do?</CardTitle>
        </CardHeader>
        <CardContent className="space-y-2">
          <div className="pt-2 border-t border-amber-100">
            <div className="text-sm text-muted-foreground mb-2">Enter your action:</div>
            <div className="flex space-x-2">
              <Textarea
                placeholder="Describe what you want to do..."
                value={customAction}
                onChange={(e) => setCustomAction(e.target.value)}
                className="resize-none"
              />
              <Button onClick={handleCustomActionSubmit} disabled={!customAction.trim() || isAdvancingStory}>
                {isAdvancingStory ? "Processing..." : "Act"}
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}