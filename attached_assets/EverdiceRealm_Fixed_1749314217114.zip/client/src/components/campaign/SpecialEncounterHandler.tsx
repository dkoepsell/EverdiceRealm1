import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/hooks/use-toast';
import { Textarea } from '@/components/ui/textarea';
import { Progress } from '@/components/ui/progress';
import { Dice1, Sparkles, Shield, Heart, Eye, Zap, Dice6 } from 'lucide-react';
import { cn } from '@/lib/utils';

interface SpecialEncounterProps {
  encounterType: 'corrupted_oak' | 'distressed_unicorn' | 'ancient_altar' | 'mystical_pool';
  encounterState: {
    corruption_level?: number;
    trust_level?: number;
    ritual_progress?: number;
    investigation_attempts?: number;
    last_interaction?: string;
  };
  onActionSubmit: (action: any) => void;
  isProcessing: boolean;
}

export function SpecialEncounterHandler({ 
  encounterType, 
  encounterState, 
  onActionSubmit, 
  isProcessing 
}: SpecialEncounterProps) {
  const [customAction, setCustomAction] = useState('');
  const [selectedApproach, setSelectedApproach] = useState<string | null>(null);
  const { toast } = useToast();

  // Define encounter-specific actions based on D&D mechanics
  const encounterActions = {
    corrupted_oak: [
      {
        action: "Cast Detect Magic to analyze the corruption",
        description: "Use arcane knowledge to understand the nature of the corruption",
        skillCheck: { ability: "arcana", dc: 15, advantage: false },
        icon: <Sparkles className="h-4 w-4" />,
        consequences: "Reveals the source and nature of the corruption"
      },
      {
        action: "Touch the oak to commune with its spirit",
        description: "Attempt to connect directly with the tree's essence",
        skillCheck: { ability: "nature", dc: 18, advantage: false },
        icon: <Heart className="h-4 w-4" />,
        consequences: "Risk corruption damage but gain deep insight"
      },
      {
        action: "Perform a cleansing ritual",
        description: "Use divine magic or nature magic to purify the tree",
        skillCheck: { ability: "religion", dc: 16, advantage: encounterState.ritual_progress ? true : false },
        icon: <Shield className="h-4 w-4" />,
        consequences: "May reduce corruption but requires specific components"
      },
      {
        action: "Search for the corruption's source",
        description: "Investigate the surrounding area for clues",
        skillCheck: { ability: "investigation", dc: 13, advantage: false },
        icon: <Eye className="h-4 w-4" />,
        consequences: "Discover what's causing the corruption"
      }
    ],
    distressed_unicorn: [
      {
        action: "Approach slowly with peaceful intentions",
        description: "Move carefully to avoid startling the magical creature",
        skillCheck: { ability: "animal_handling", dc: 14, advantage: false },
        icon: <Heart className="h-4 w-4" />,
        consequences: "Build trust or risk the unicorn fleeing"
      },
      {
        action: "Cast Speak with Animals",
        description: "Use magic to communicate directly with the unicorn",
        skillCheck: { ability: "nature", dc: 12, advantage: true },
        icon: <Sparkles className="h-4 w-4" />,
        consequences: "Learn what's troubling the unicorn"
      },
      {
        action: "Offer healing or comfort",
        description: "Attempt to tend to any wounds or distress",
        skillCheck: { ability: "medicine", dc: 15, advantage: encounterState.trust_level && encounterState.trust_level > 50 },
        icon: <Heart className="h-4 w-4" />,
        consequences: "May heal the unicorn and gain its favor"
      },
      {
        action: "Stand guard and protect the unicorn",
        description: "Position yourself defensively to shield the creature",
        skillCheck: { ability: "perception", dc: 13, advantage: false },
        icon: <Shield className="h-4 w-4" />,
        consequences: "Detect approaching threats and earn trust"
      }
    ],
    ancient_altar: [
      {
        action: "Examine the altar's inscriptions",
        description: "Study ancient runes and symbols for meaning",
        skillCheck: { ability: "history", dc: 16, advantage: false },
        icon: <Eye className="h-4 w-4" />,
        consequences: "Understand the altar's purpose and activation"
      },
      {
        action: "Place hands on the altar to activate it",
        description: "Channel your energy into the ancient magic",
        skillCheck: { ability: "arcana", dc: 17, advantage: false },
        icon: <Zap className="h-4 w-4" />,
        consequences: "Risk magical backlash but may awaken its power"
      },
      {
        action: "Offer a sacrifice or tribute",
        description: "Present something valuable to appease ancient spirits",
        skillCheck: { ability: "religion", dc: 14, advantage: false },
        icon: <Sparkles className="h-4 w-4" />,
        consequences: "May unlock the altar's blessing or curse"
      }
    ]
  };

  const handleSpecialAction = (action: any) => {
    setSelectedApproach(action.action);

    // Enhanced action with D&D mechanics
    const enhancedAction = {
      ...action,
      encounterType,
      encounterState,
      requiresDiceRoll: true,
      diceType: 'd20',
      rollDC: action.skillCheck.dc,
      abilityType: action.skillCheck.ability,
      rollModifier: action.skillCheck.advantage ? 5 : 0, // Advantage simulation
      specialMechanics: {
        advantage: action.skillCheck.advantage,
        environmentalFactors: getEnvironmentalFactors(encounterType),
        potentialOutcomes: action.consequences
      }
    };

    onActionSubmit(enhancedAction);
  };

  const handleCustomAction = () => {
    if (!customAction.trim()) return;

    const action = {
      action: customAction,
      encounterType,
      encounterState,
      requiresDiceRoll: true,
      diceType: 'd20',
      rollDC: 15, // Default DC for custom actions
      abilityType: 'ability', // Let the DM determine the appropriate ability
      rollModifier: 0,
      specialMechanics: {
        isCustom: true,
        environmentalFactors: getEnvironmentalFactors(encounterType)
      }
    };

    onActionSubmit(action);
    setCustomAction('');
  };

  const getEnvironmentalFactors = (type: string) => {
    const factors = {
      corrupted_oak: ['magical_corruption', 'shadowy_mist', 'twisted_energy'],
      distressed_unicorn: ['sacred_grove', 'moonlight_blessing', 'pure_magic'],
      ancient_altar: ['divine_presence', 'ancient_magic', 'ritual_circle']
    };
    return factors[type] || [];
  };

  const getEncounterTitle = () => {
    const titles = {
      corrupted_oak: 'The Corrupted Ancient Oak',
      distressed_unicorn: 'The Distressed Unicorn',
      ancient_altar: 'The Ancient Ritual Altar',
      mystical_pool: 'The Mystical Pool'
    };
    return titles[encounterType] || 'Special Encounter';
  };

  const getEncounterDescription = () => {
    const descriptions = {
      corrupted_oak: 'A massive oak tree wreathed in shadowy tendrils. Dark energy pulses through its bark, and the very air around it feels heavy with corruption.',
      distressed_unicorn: 'A magnificent unicorn with an iridescent coat stands before you, its eyes filled with distress and wariness. Its horn dims with each labored breath.',
      ancient_altar: 'An ornate stone altar covered in glowing runes stands in the center of a ritual circle. Ancient magic thrums through the air around it.',
      mystical_pool: 'A perfectly still pool of water reflects not the sky above, but swirling cosmos and distant stars. The water seems to pulse with otherworldly energy.'
    };
    return descriptions[encounterType] || 'A mysterious encounter awaits your action.';
  };

  const actions = encounterActions[encounterType] || [];

  // Distressed Unicorn encounter
  if (encounterType === 'distressed_unicorn') {
    const trustLevel = encounterState.trust_level || 30;
    const lastInteraction = encounterState.last_interaction || 'none';

    const getUnicornChoices = () => {
      const baseChoices = [
        {
          action: "Approach the unicorn slowly and speak softly",
          description: "Move carefully with gentle words to avoid startling the magical creature",
          requiresDiceRoll: true,
          diceType: "d20",
          rollDC: 13,
          abilityType: "animal_handling",
          rollModifier: trustLevel > 50 ? 2 : (trustLevel < 20 ? -2 : 0)
        },
        {
          action: "Remain still and let the unicorn approach you",
          description: "Show patience and let the creature decide whether to trust you",
          requiresDiceRoll: true,
          diceType: "d20",
          rollDC: 15,
          abilityType: "insight",
          rollModifier: 0
        },
        {
          action: "Examine the corruption affecting the unicorn's forest home",
          description: "Investigate the source of the unicorn's distress",
          requiresDiceRoll: true,
          diceType: "d20",
          rollDC: 14,
          abilityType: "investigation",
          rollModifier: 0
        }
      ];

      // Add trust-dependent choices
      if (trustLevel > 40) {
        baseChoices.push({
          action: "Offer to help cleanse the corruption from the grove",
          description: "With growing trust, propose to aid in healing the forest",
          requiresDiceRoll: true,
          diceType: "d20",
          rollDC: 12,
          abilityType: "nature",
          rollModifier: 1
        });
      }

      if (trustLevel < 20) {
        baseChoices.push({
          action: "Back away slowly to give the unicorn space",
          description: "Retreat to calm the frightened creature",
          requiresDiceRoll: false
        });
      }

      return baseChoices;
    };

    return (
      <div className="space-y-4">
      <Card className="border-2 border-blue-300 bg-gradient-to-br from-blue-50 to-purple-50">
        <CardHeader className="border-b border-blue-200">
          <CardTitle className="text-blue-800 flex items-center gap-2">
            <Sparkles className="h-5 w-5" />
            Mystical Encounter: Distressed Unicorn
          </CardTitle>
          <CardDescription className="text-blue-700">
            A creature of legend stands before you, its magical presence both beautiful and troubled.
            Trust Level: {trustLevel}% | Last Interaction: {lastInteraction}
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4 pt-4">
          <div className="grid gap-3">
            {getUnicornChoices().map((choice, index) => (
              <Button
                key={index}
                onClick={() => onActionSubmit(choice)}
                disabled={isProcessing}
                variant="outline"
                className="text-left h-auto p-4 border-blue-200 hover:bg-blue-50 hover:border-blue-300"
              >
                <div>
                  <div className="font-medium text-blue-800">{choice.action}</div>
                  <div className="text-sm text-blue-600 mt-1">{choice.description}</div>
                  {choice.requiresDiceRoll && (
                    <div className="flex items-center gap-2 text-xs text-blue-500 mt-2">
                      <Dice6 className="h-3 w-3" />
                      {choice.abilityType} check (DC {choice.rollDC})
                      {choice.rollModifier !== 0 && (
                        <span className={choice.rollModifier > 0 ? "text-green-600" : "text-red-600"}>
                          {choice.rollModifier > 0 ? '+' : ''}{choice.rollModifier}
                        </span>
                      )}
                    </div>
                  )}
                </div>
              </Button>
            ))}
          </div>

          <div className="bg-blue-100 p-3 rounded-lg border border-blue-200">
            <p className="text-sm text-blue-800">
              <strong>Unicorn's Mood:</strong> {
                trustLevel > 60 ? "Cautiously trusting - shows interest in your presence" :
                trustLevel > 30 ? "Wary but curious - watches you carefully" :
                "Distressed and skittish - ready to flee at sudden movements"
              }
            </p>
          </div>
        </CardContent>
      </Card>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <Card className="border-2 border-amber-400 bg-gradient-to-br from-amber-50 to-yellow-50">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2 font-fantasy text-xl">
            <Sparkles className="h-6 w-6 text-amber-600" />
            <span>{getEncounterTitle()}</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-gray-700 font-fantasy text-lg mb-4">
            {getEncounterDescription()}
          </p>

          {/* Encounter State Indicators */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
            {encounterState.corruption_level !== undefined && (
              <div>
                <div className="flex justify-between text-sm mb-1">
                  <span>Corruption Level</span>
                  <span>{encounterState.corruption_level}%</span>
                </div>
                <Progress value={encounterState.corruption_level} className="h-2" />
              </div>
            )}
            {encounterState.trust_level !== undefined && (
              <div>
                <div className="flex justify-between text-sm mb-1">
                  <span>Trust Level</span>
                  <span>{encounterState.trust_level}%</span>
                </div>
                <Progress value={encounterState.trust_level} className="h-2 bg-green-100" />
              </div>
            )}
            {encounterState.ritual_progress !== undefined && (
              <div>
                <div className="flex justify-between text-sm mb-1">
                  <span>Ritual Progress</span>
                  <span>{encounterState.ritual_progress}%</span>
                </div>
                <Progress value={encounterState.ritual_progress} className="h-2 bg-blue-100" />
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Available Actions</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          {actions.map((action, index) => (
            <div key={index} className="border rounded-lg p-3 hover:bg-gray-50 transition-colors">
              <div className="flex items-start space-x-3">
                <div className="mt-1">{action.icon}</div>
                <div className="flex-grow">
                  <div className="flex items-center space-x-2 mb-1">
                    <h4 className="font-semibold">{action.action}</h4>
                    <Badge variant="outline" className="text-xs">
                      {action.skillCheck.ability.toUpperCase()} DC {action.skillCheck.dc}
                    </Badge>
                    {action.skillCheck.advantage && (
                      <Badge variant="default" className="text-xs bg-green-100 text-green-800">
                        Advantage
                      </Badge>
                    )}
                  </div>
                  <p className="text-sm text-gray-600 mb-2">{action.description}</p>
                  <p className="text-xs text-blue-600 italic">Potential outcome: {action.consequences}</p>
                </div>
                <Button
                  size="sm"
                  onClick={() => handleSpecialAction(action)}
                  disabled={isProcessing}
                  className={cn(
                    selectedApproach === action.action && "ring-2 ring-blue-500"
                  )}
                >
                  <Dice1 className="h-4 w-4 mr-1" />
                  Roll
                </Button>
              </div>
            </div>
          ))}

          {/* Custom Action */}
          <div className="border-t pt-3 mt-4">
            <h4 className="font-semibold mb-2">Custom Action</h4>
            <div className="flex space-x-2">
              <Textarea
                placeholder="Describe your unique approach to this encounter..."
                value={customAction}
                onChange={(e) => setCustomAction(e.target.value)}
                className="resize-none"
                rows={2}
              />
              <Button
                onClick={handleCustomAction}
                disabled={!customAction.trim() || isProcessing}
              >
                Act
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}