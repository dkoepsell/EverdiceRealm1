import React from 'react';
import { 
  Dialog, DialogContent, DialogDescription, 
  DialogHeader, DialogTitle, DialogFooter,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Award, TrendingUp, Sword, Sparkle, Package, ArrowUp } from 'lucide-react';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';

export interface LootItem {
  id: number;
  name: string;
  description: string;
  rarity: 'common' | 'uncommon' | 'rare' | 'very rare' | 'legendary';
  type: string;
}

interface CombatRewardsModalProps {
  isOpen: boolean;
  onClose: () => void;
  outcome: 'victory' | 'defeat' | 'fled';
  rewards: {
    xp: number;
    items?: LootItem[];
    gold?: number;
  };
  levelUp?: boolean;
  newLevel?: number;
}

const rarityColors = {
  'common': 'bg-gray-100 text-gray-800 border-gray-300',
  'uncommon': 'bg-green-100 text-green-800 border-green-300',
  'rare': 'bg-blue-100 text-blue-800 border-blue-300',
  'very rare': 'bg-purple-100 text-purple-800 border-purple-300',
  'legendary': 'bg-amber-100 text-amber-800 border-amber-300'
};

export function CombatRewardsModal({ 
  isOpen, 
  onClose, 
  outcome, 
  rewards,
  levelUp = false,
  newLevel = 0
}: CombatRewardsModalProps) {
  
  const hasItems = rewards.items && rewards.items.length > 0;
  
  // Title and content based on outcome
  let title = '';
  let description = '';
  
  switch(outcome) {
    case 'victory':
      title = 'Victory!';
      description = 'You have defeated your enemies and earned rewards!';
      break;
    case 'defeat':
      title = 'Defeat';
      description = 'Your party has been defeated. Better luck next time.';
      break;
    case 'fled':
      title = 'Escaped Combat';
      description = 'Your party has fled from battle. You earn a small amount of experience.';
      break;
    default:
      title = 'Combat Results';
      description = 'The battle has concluded.';
  }

  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle className={`text-2xl font-bold flex items-center ${
            outcome === 'victory' ? 'text-green-600' : 
            outcome === 'defeat' ? 'text-red-600' : 'text-blue-600'
          }`}>
            {outcome === 'victory' ? <Award className="h-6 w-6 mr-2" /> : 
             outcome === 'defeat' ? <Sword className="h-6 w-6 mr-2" /> :
             <ArrowUp className="h-6 w-6 mr-2" />}
            {title}
          </DialogTitle>
          <DialogDescription>{description}</DialogDescription>
        </DialogHeader>
        
        <div className="mt-2 space-y-4">
          {/* XP Reward */}
          <div className="flex items-center justify-between p-4 rounded-md bg-blue-50 border border-blue-200">
            <div className="flex items-center">
              <TrendingUp className="h-5 w-5 mr-2 text-blue-600" />
              <span className="font-medium text-blue-800">Experience Points</span>
            </div>
            <span className="text-xl font-bold text-blue-700">+{rewards.xp}</span>
          </div>
          
          {/* Gold Reward - if any */}
          {rewards.gold && rewards.gold > 0 && (
            <div className="flex items-center justify-between p-4 rounded-md bg-yellow-50 border border-yellow-200">
              <div className="flex items-center">
                <Sparkle className="h-5 w-5 mr-2 text-yellow-600" />
                <span className="font-medium text-yellow-800">Gold Pieces</span>
              </div>
              <span className="text-xl font-bold text-yellow-700">+{rewards.gold}</span>
            </div>
          )}
          
          {/* Level Up Alert - if applicable */}
          {levelUp && (
            <Alert className="bg-gradient-to-r from-amber-50 to-orange-50 border-amber-300">
              <ArrowUp className="h-4 w-4 text-amber-600" />
              <AlertTitle className="text-amber-800 font-bold">Level Up!</AlertTitle>
              <AlertDescription className="text-amber-700">
                Your character has advanced to level {newLevel}! Visit your character sheet to see new abilities.
              </AlertDescription>
            </Alert>
          )}
          
          {/* Items Reward - if any */}
          {hasItems && (
            <Card className="border-emerald-200">
              <CardHeader className="pb-2">
                <CardTitle className="text-emerald-700 flex items-center text-lg">
                  <Package className="h-5 w-5 mr-2" />
                  Loot Discovered
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ScrollArea className="h-[200px] pr-4">
                  <div className="space-y-3">
                    {rewards.items.map((item, index) => (
                      <div key={index} className={`p-3 rounded-md border ${rarityColors[item.rarity]}`}>
                        <div className="flex justify-between items-start">
                          <div>
                            <div className="font-semibold">{item.name}</div>
                            <div className="text-sm capitalize">{item.type} • {item.rarity}</div>
                          </div>
                        </div>
                        <Separator className="my-2 opacity-30" />
                        <div className="text-sm">{item.description}</div>
                      </div>
                    ))}
                  </div>
                </ScrollArea>
              </CardContent>
            </Card>
          )}
        </div>
        
        <DialogFooter className="mt-4">
          <Button 
            onClick={onClose}
            className={`${
              outcome === 'victory' ? 'bg-green-600 hover:bg-green-700' : 
              outcome === 'defeat' ? 'bg-red-600 hover:bg-red-700' : 
              'bg-blue-600 hover:bg-blue-700'
            }`}
          >
            Continue Adventure
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}