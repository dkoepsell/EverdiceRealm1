
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { MapPin, Target, Clock } from 'lucide-react';

interface StoryProgressTrackerProps {
  storyArc?: {
    title: string;
    currentPhase: number;
    phases: Array<{
      title: string;
      isComplete: boolean;
    }>;
  };
  continuityMetrics?: {
    progressPercentage: number;
    estimatedSessionsRemaining: number;
    endingApproaching: boolean;
  };
  currentLocation: string;
}

export function StoryProgressTracker({ 
  storyArc, 
  continuityMetrics, 
  currentLocation 
}: StoryProgressTrackerProps) {
  if (!storyArc || !continuityMetrics) {
    return null;
  }

  return (
    <Card className="w-full">
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center gap-2 text-sm">
          <Target className="h-4 w-4" />
          Story Progress
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Main Progress */}
        <div className="space-y-2">
          <div className="flex justify-between text-sm">
            <span className="font-medium">{storyArc.title}</span>
            <span>{Math.round(continuityMetrics.progressPercentage)}%</span>
          </div>
          <Progress value={continuityMetrics.progressPercentage} className="h-2" />
        </div>

        {/* Current Phase */}
        <div className="space-y-2">
          <div className="flex items-center gap-2">
            <span className="text-sm font-medium">Current Phase:</span>
            <Badge variant={continuityMetrics.endingApproaching ? "destructive" : "default"}>
              {storyArc.phases[storyArc.currentPhase]?.title || 'Unknown'}
            </Badge>
          </div>
          
          {/* Phase Progress */}
          <div className="flex gap-1">
            {storyArc.phases.map((phase, index) => (
              <div
                key={index}
                className={`h-2 flex-1 rounded ${
                  index < storyArc.currentPhase 
                    ? 'bg-green-500' 
                    : index === storyArc.currentPhase 
                      ? 'bg-blue-500' 
                      : 'bg-gray-200'
                }`}
              />
            ))}
          </div>
        </div>

        {/* Location & Time Remaining */}
        <div className="flex justify-between text-sm text-muted-foreground">
          <div className="flex items-center gap-1">
            <MapPin className="h-3 w-3" />
            <span>{currentLocation}</span>
          </div>
          <div className="flex items-center gap-1">
            <Clock className="h-3 w-3" />
            <span>
              {continuityMetrics.endingApproaching 
                ? 'Approaching climax'
                : `~${continuityMetrics.estimatedSessionsRemaining} sessions remaining`
              }
            </span>
          </div>
        </div>

        {/* Ending Approach Warning */}
        {continuityMetrics.endingApproaching && (
          <div className="text-xs p-2 bg-orange-50 border border-orange-200 rounded text-orange-800">
            The story is building toward its climax. Your choices now will determine the campaign's conclusion.
          </div>
        )}
      </CardContent>
    </Card>
  );
}
