import React, { useState, useEffect } from 'react';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Dice1 } from 'lucide-react';
import { rollDice } from '@/lib/diceUtils';
import { NPCInteractionHandler } from './NPCInteractionHandler';
import CombatEncounterHandler from './CombatEncounterHandler';
import { ScrollText, Scroll } from 'lucide-react';
import { Textarea } from "@/components/ui/textarea"

enum SceneType {
  Narrative = 'narrative',
  Combat = 'combat',
  NpcInteraction = 'npc',
  Rest = 'rest',
  Exploration = 'exploration'
}

interface QuestRewards {
  xp: number;
  gold: number;
  items: Array<{
    id: number;
    name: string;
    description: string;
    rarity: string;
    type: string;
  }>;
}

interface QuestStage {
  id: number;
  title: string;
  description: string;
  isComplete: boolean;
  nextStages?: number[];
}

interface Quest {
  id: number;
  title: string;
  description: string;
  stages: QuestStage[];
  currentStage: number;
  rewards: QuestRewards;
  isComplete: boolean;
}

interface StoryArc {
  id: number;
  title: string;
  description: string;
  currentPhase: number;
  phases: {
    id: number;
    title: string;
    description: string;
    objectives: string[];
    isComplete: boolean;
  }[];
  isComplete: boolean;
}

interface SceneManagerProps {
  campaignId: number;
  sessionId: number;
  narrative: string;
  location: string;
  choices: any[];
  onAdvance: (result: any) => void;
  activeQuest?: Quest;
  storyArc?: StoryArc;
}

export function SceneManager({
  campaignId,
  sessionId,
  narrative,
  location,
  choices,
  onAdvance,
  activeQuest,
  storyArc
}: SceneManagerProps) {
  const [currentScene, setCurrentScene] = useState<SceneType>(SceneType.Narrative);
  const [isProcessing, setIsProcessing] = useState(false);
  const [currentNpc, setCurrentNpc] = useState<any>(null);
  const [activeSkillCheck, setActiveSkillCheck] = useState<any>(null);
  const [customAction, setCustomAction] = useState('');

  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Reset scene when narrative changes
  useEffect(() => {
    setCurrentScene(SceneType.Narrative);
    setCurrentNpc(null);
    setActiveSkillCheck(null);
    setCustomAction('');
  }, [narrative, sessionId]);

  // Process player choice and determine next scene
  const processChoiceMutation = useMutation({
    mutationFn: async ({ action, skillResult = null }: { action: string; skillResult?: any }) => {
      const response = await apiRequest('POST', '/api/campaigns/advance-story', {
        campaignId,
        sessionId,
        action,
        skillResult
      });
      return await response.json();
    },
    onSuccess: (data) => {
      setIsProcessing(false);

      // Based on the response, determine what scene to show next
      if (data.encounterTriggered) {
        setCurrentScene(SceneType.Combat);
      } else if (data.npcInteraction) {
        setCurrentNpc(data.npc);
        setCurrentScene(SceneType.NpcInteraction);
      } else {
        // Regular story advancement
        onAdvance(data);
      }
    },
    onError: (error: Error) => {
      setIsProcessing(false);
      toast({
        title: "Failed to process action",
        description: error.message,
        variant: "destructive"
      });
    }
  });

  // Handle player choice
  const handleChoice = (choice: any) => {
    if (isProcessing) return;

    setIsProcessing(true);

    // Track choice impact on story progression
    const choiceContext = {
      activeQuest: activeQuest,
      storyArc: storyArc,
      currentLocation: location,
      choice: choice,
      environment: process.env.NODE_ENV
    };

    // If this choice requires a skill check
    if (choice.requiresDiceRoll) {
      setActiveSkillCheck({
        ...choice,
        inProgress: true
      });

      // Simulate rolling dice for the skill check
      setTimeout(() => {
        const { total, rolls } = rollDice(choice.diceType || 'd20', choice.rollModifier || 0);
        const success = total >= (choice.rollDC || 10);

        // Update the active skill check with results
        setActiveSkillCheck({
          ...choice,
          inProgress: false,
          result: {
            roll: rolls[0],
            total,
            success
          }
        });

        // After showing the result, process the choice with the skill check result
        setTimeout(() => {
          processChoiceMutation.mutate({ 
            action: choice.action,
            skillResult: {
              success,
              roll: total,
              rollDC: choice.rollDC || 10,
              ability: choice.abilityType || 'dexterity'
            }
          });
        }, 1500);
      }, 1000);
    } else {
      // No skill check needed, just process the choice
      processChoiceMutation.mutate({ action: choice.action });
    }
  };

  // Handle custom action submission
  const handleCustomAction = () => {
    if (!customAction.trim() || isProcessing) return;

    setIsProcessing(true);
    processChoiceMutation.mutate({ action: customAction });
    setCustomAction('');
  };

  // Handle combat resolution
  const handleCombatResolved = (outcome: string, rewards: any) => {
    processChoiceMutation.mutate({ 
      action: `Combat ${outcome === 'victory' ? 'won' : 'fled'}`,
      skillResult: {
        combatOutcome: outcome,
        rewards
      }
    });
  };

  // Handle NPC interaction completion
  const handleNpcInteractionComplete = (result: any) => {
    processChoiceMutation.mutate({ 
      action: `Spoke with ${result.npcName || 'NPC'}`,
      skillResult: {
        npcInteraction: result
      }
    });
    setCurrentNpc(null);
  };

  // Render combat scene
  if (currentScene === SceneType.Combat) {
    return (
      <CombatEncounterHandler
        campaignId={campaignId}
        sessionId={sessionId}
        onCombatResolved={handleCombatResolved}
      />
    );
  }

  // Render NPC interaction scene
  if (currentScene === SceneType.NpcInteraction && currentNpc) {
    return (
      <NPCInteractionHandler
        campaignId={campaignId}
        sessionId={sessionId}
        npc={currentNpc}
        isOpen={true}
        onClose={() => setCurrentNpc(null)}
        onInteractionComplete={handleNpcInteractionComplete}
      />
    );
  }

  // Render narrative scene (default)
  const renderQuestProgress = () => {
    if (!activeQuest) return null;

    const currentStage = activeQuest.stages.find(s => s.id === activeQuest?.currentStage);

    return (
      <Card className="bg-primary/5 border-primary/20">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-lg">
            <ScrollText className="h-5 w-5" />
            {activeQuest.title}
          </CardTitle>
          <CardDescription>{activeQuest.description}</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="space-y-2">
              <h4 className="font-medium">Current Objective:</h4>
              <p className="text-sm">{currentStage?.description}</p>
            </div>

            <div className="space-y-2">
              <h4 className="font-medium">Progress:</h4>
              <div className="space-y-1">
                {activeQuest.stages.map((stage) => (
                  <div 
                    key={stage.id}
                    className={`flex items-center gap-2 text-sm ${
                      stage.isComplete ? 'text-primary' : 'text-muted-foreground'
                    }`}
                  >
                    {stage.isComplete ? '✓' : '○'} {stage.title}
                  </div>
                ))}
              </div>
            </div>

            <div className="space-y-2">
              <h4 className="font-medium">Quest Rewards:</h4>
              <div className="text-sm space-y-1">
                <p>• {activeQuest.rewards.xp} XP</p>
                <p>• {activeQuest.rewards.gold} Gold</p>
                {activeQuest.rewards.items.map((item, i) => (
                  <p key={i} className="flex items-center gap-1">
                    • {item.name} <Badge variant="outline">{item.rarity}</Badge>
                  </p>
                ))}
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  };

  return (
    <div className="space-y-4 mx-auto max-w-4xl">
      {renderQuestProgress()}
      {/* Narrative Display */}
      <Card className="bg-parchment border-amber-800 shadow-lg">
        <CardHeader className="pb-4 border-b border-amber-300">
          <div className="flex items-center justify-between">
            <CardTitle className="text-xl font-fantasy text-amber-900">{location}</CardTitle>
            <Badge variant="outline" className="bg-amber-100 border-amber-300">
              Session {sessionId}
            </Badge>
          </div>
        </CardHeader>
        <CardContent className="pt-6 pb-8 font-serif text-lg">
          <p className="leading-relaxed whitespace-pre-line">{narrative}</p>
        </CardContent>
      </Card>

      {/* Skill Check Display */}
      {activeSkillCheck && (
        <Card className="border-2 border-blue-600 bg-blue-50 shadow-md">
          <CardHeader className="pb-2">
            <CardTitle className="text-blue-800 flex items-center">
              <Dice1 className="mr-2 h-5 w-5" />
              {activeSkillCheck.abilityType 
                ? `${activeSkillCheck.abilityType.charAt(0).toUpperCase() + activeSkillCheck.abilityType.slice(1)} Check`
                : 'Skill Check'}
            </CardTitle>
            <CardDescription>{activeSkillCheck.description || activeSkillCheck.action}</CardDescription>
          </CardHeader>
          <CardContent className="pb-4">
            {activeSkillCheck.inProgress ? (
              <div className="flex justify-center py-4">
                <div className="animate-bounce text-4xl">🎲</div>
              </div>
            ) : activeSkillCheck.result ? (
              <div className="bg-white p-4 rounded-md border border-blue-200">
                <div className="flex items-center justify-between">
                  <div className="font-medium">Roll: {activeSkillCheck.result.total}</div>
                  <Badge 
                    variant={activeSkillCheck.result.success ? "default" : "destructive"}
                    className={activeSkillCheck.result.success 
                      ? "bg-green-100 text-green-800 border-green-300" 
                      : "bg-red-100 text-red-800 border-red-300"
                    }
                  >
                    {activeSkillCheck.result.success ? "Success" : "Failure"}
                  </Badge>
                </div>
                <div className="mt-2 text-sm text-gray-500">
                  {activeSkillCheck.result.success 
                    ? (activeSkillCheck.successText || `You succeeded in your ${activeSkillCheck.action}`) 
                    : (activeSkillCheck.failureText || `You failed in your ${activeSkillCheck.action}`)}
                </div>
              </div>
            ) : null}
          </CardContent>
        </Card>
      )}

      {/* Action choices */}
      {!isProcessing && !activeSkillCheck && (
        <Card className="border-amber-300 shadow-md">
          <CardHeader className="pb-2">
            <CardTitle className="text-amber-800 text-lg">What do you do next?</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {/* Predefined choices */}
            <div className="space-y-2">
              {choices.map((choice, index) => (
                <Button 
                  key={index}
                  variant="outline"
                  className="w-full justify-start overflow-hidden group transition-all hover:border-amber-500"
                  onClick={() => handleChoice(choice)}
                >
                  <div className="flex items-center w-full">
                    <span className="mr-2 text-amber-600 group-hover:text-amber-800">
                      {choice.requiresDiceRoll ? '🎲' : '→'}
                    </span>
                    <div className="flex-1 text-left">
                      <div className="font-medium">{choice.action}</div>
                      {choice.description && (
                        <div className="text-xs text-muted-foreground">{choice.description}</div>
                      )}
                    </div>
                    {choice.requiresDiceRoll && (
                      <Badge className="ml-auto" variant="outline">
                        {choice.diceType || 'd20'} 
                        {choice.abilityType && ` (${choice.abilityType})`}
                      </Badge>
                    )}
                  </div>
                </Button>
              ))}
            </div>

            {/* Custom action input */}
            <div className="pt-3 border-t border-amber-100 mt-4">
              <div className="flex justify-between items-center mb-2">
                <div className="text-sm font-medium">What would you like to do?</div>
                <div className="flex gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setCustomAction("I want to make an Insight check to read their intentions")}
                  >
                    Insight Check
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setCustomAction("I want to make a Perception check to search the area")}
                  >
                    Perception Check
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setCustomAction("I want to attempt to persuade them")}
                  >
                    Persuasion
                  </Button>
                </div>
              </div>
              <div className="space-y-2">
                <Textarea
                  value={customAction}
                  onChange={(e) => setCustomAction(e.target.value)}
                  placeholder="Describe your action (e.g. 'I search the room for traps', 'I try to intimidate the guard', 'I want to climb the wall'...)"
                  className="w-full rounded-md border border-input px-3 py-2 text-sm min-h-[80px]"
                />
                <div className="flex justify-between items-center">
                  <div className="text-xs text-muted-foreground">
                    Be specific - your choices affect your character's development!
                  </div>
                  <Button 
                    onClick={handleCustomAction}
                    disabled={!customAction.trim()}
                    className="bg-amber-600 hover:bg-amber-700"
                  >
                    Take Action
                  </Button>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Loading State */}
      {isProcessing && !activeSkillCheck && (
        <Card className="border-amber-300">
          <CardContent className="py-8">
            <div className="flex flex-col items-center justify-center">
              <div className="animate-spin h-8 w-8 border-4 border-amber-500 border-t-transparent rounded-full mb-4"></div>
              <p className="text-amber-800">Your story continues...</p>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}