import React, { useState } from 'react';
import { 
  Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter 
} from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { ScrollArea } from "@/components/ui/scroll-area";
import { 
  Sword, Shield, Droplets as Potion, 
  Gem, Package, Sparkles, 
  CheckCircle2, Circle, Eye, 
  ArrowUp, AlertCircle, Info, 
  X, Clipboard
} from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from '@/lib/queryClient';

// Inventory Item interface - matches what's defined in CharacterSheet
interface InventoryItem {
  id: number;
  name: string;
  description: string;
  rarity: 'common' | 'uncommon' | 'rare' | 'very rare' | 'legendary';
  type: string;
  equipped?: boolean;
  slot?: string;
  attunement?: boolean;
  attuned?: boolean;
}

interface EquipmentManagerProps {
  characterId: number;
  inventory: InventoryItem[];
  gold?: number;
  onInventoryChange: (inventory: InventoryItem[]) => void;
  onUseItem?: (item: InventoryItem) => void;
}

// Helper for item type icons
const getItemIcon = (type: string) => {
  switch (type.toLowerCase()) {
    case 'weapon':
      return <Sword className="h-5 w-5" />;
    case 'armor':
      return <Shield className="h-5 w-5" />;
    case 'potion':
      return <Potion className="h-5 w-5" />;
    case 'ring':
      return <Gem className="h-5 w-5" />;
    case 'wondrous item':
      return <Sparkles className="h-5 w-5" />;
    default:
      return <Package className="h-5 w-5" />;
  }
};

// Helper for rarity colors
const getRarityColor = (rarity: string) => {
  switch (rarity) {
    case 'common':
      return 'bg-gray-100 text-gray-800 border-gray-300';
    case 'uncommon':
      return 'bg-green-100 text-green-800 border-green-300';
    case 'rare':
      return 'bg-blue-100 text-blue-800 border-blue-300';
    case 'very rare':
      return 'bg-purple-100 text-purple-800 border-purple-300';
    case 'legendary':
      return 'bg-amber-100 text-amber-800 border-amber-300';
    default:
      return 'bg-gray-100 text-gray-800 border-gray-300';
  }
};

export default function EquipmentManager({ 
  characterId,
  inventory,
  gold = 0,
  onInventoryChange,
  onUseItem
}: EquipmentManagerProps) {
  const { toast } = useToast();
  const [activeItemId, setActiveItemId] = useState<number | null>(null);
  const [detailsOpen, setDetailsOpen] = useState<boolean>(false);
  const [confirmAction, setConfirmAction] = useState<{
    open: boolean;
    item: InventoryItem | null;
    action: 'equip' | 'unequip' | 'attune' | 'unattune' | 'discard';
  }>({
    open: false,
    item: null,
    action: 'equip'
  });

  // Get item by ID
  const getItemById = (id: number) => {
    return inventory.find(item => item.id === id) || null;
  };

  // Count of attuned items
  const attunedItemsCount = inventory.filter(item => item.attuned).length;
  const MAX_ATTUNED_ITEMS = 3; // D&D rules limit attunement to 3 items

  // Equipment slots
  const getEquippedItemBySlot = (slot: string) => {
    return inventory.find(item => item.equipped && item.slot === slot);
  };

  // Open item details dialog
  const viewItemDetails = (itemId: number) => {
    setActiveItemId(itemId);
    setDetailsOpen(true);
  };

  // Open confirmation dialog for various actions
  const openConfirmAction = (item: InventoryItem, action: 'equip' | 'unequip' | 'attune' | 'unattune' | 'discard') => {
    setConfirmAction({
      open: true,
      item,
      action
    });
  };

  // Process equipment/attunement changes
  const handleEquipmentChange = async (item: InventoryItem, action: string) => {
    setConfirmAction({ open: false, item: null, action: 'equip' });
    
    try {
      let updatedInventory = [...inventory];
      const itemIndex = updatedInventory.findIndex(i => i.id === item.id);
      
      if (itemIndex === -1) return;
      
      switch (action) {
        case 'equip':
          // Unequip any item in the same slot
          if (item.slot) {
            const existingItem = getEquippedItemBySlot(item.slot);
            if (existingItem) {
              const existingIndex = updatedInventory.findIndex(i => i.id === existingItem.id);
              if (existingIndex !== -1) {
                updatedInventory[existingIndex] = { ...updatedInventory[existingIndex], equipped: false };
              }
            }
          }
          
          // Equip the new item
          updatedInventory[itemIndex] = { ...updatedInventory[itemIndex], equipped: true };
          break;
          
        case 'unequip':
          updatedInventory[itemIndex] = { ...updatedInventory[itemIndex], equipped: false };
          break;
          
        case 'attune':
          if (attunedItemsCount >= MAX_ATTUNED_ITEMS) {
            toast({
              title: "Attunement Limit Reached",
              description: "You cannot attune to more than 3 items at once.",
              variant: "destructive"
            });
            return;
          }
          updatedInventory[itemIndex] = { ...updatedInventory[itemIndex], attuned: true };
          break;
          
        case 'unattune':
          updatedInventory[itemIndex] = { ...updatedInventory[itemIndex], attuned: false };
          break;
          
        case 'discard':
          updatedInventory = updatedInventory.filter(i => i.id !== item.id);
          break;
          
        default:
          break;
      }
      
      // Update local state
      onInventoryChange(updatedInventory);
      
      // Persist to server (if needed)
      await apiRequest('POST', `/api/characters/${characterId}/inventory`, { 
        inventory: updatedInventory 
      });
      
      toast({
        title: "Equipment Updated",
        description: `Successfully ${action}ed ${item.name}.`,
        variant: "default"
      });
    } catch (error) {
      toast({
        title: "Update Failed",
        description: "Failed to update equipment. Please try again.",
        variant: "destructive"
      });
    }
  };

  // Use an item (like a potion)
  const handleUseItem = (item: InventoryItem) => {
    if (onUseItem) {
      onUseItem(item);
      
      // If it's a consumable like a potion, remove it after use
      if (item.type.toLowerCase() === 'potion') {
        const updatedInventory = inventory.filter(i => i.id !== item.id);
        onInventoryChange(updatedInventory);
        
        toast({
          title: "Item Used",
          description: `You used ${item.name}.`,
          variant: "default"
        });
      }
    }
  };

  // Filter items by type for different tabs
  const weapons = inventory.filter(item => item.type.toLowerCase() === 'weapon');
  const armor = inventory.filter(item => item.type.toLowerCase() === 'armor');
  const potions = inventory.filter(item => item.type.toLowerCase() === 'potion');
  const wondrous = inventory.filter(item => 
    item.type.toLowerCase() === 'wondrous item' || 
    item.type.toLowerCase() === 'ring'
  );
  const misc = inventory.filter(item => 
    !['weapon', 'armor', 'potion', 'wondrous item', 'ring'].includes(item.type.toLowerCase())
  );

  const activeItem = activeItemId ? getItemById(activeItemId) : null;

  return (
    <div className="equipment-manager">
      <Card className="bg-secondary-light rounded-lg shadow-md">
        <CardHeader className="pb-2">
          <div className="flex justify-between items-center">
            <CardTitle className="font-fantasy text-lg text-primary">Equipment & Inventory</CardTitle>
            <Badge variant="outline" className="flex items-center gap-1 bg-amber-50">
              <Sparkles className="h-3 w-3 text-amber-600" />
              <span className="text-amber-700">{gold} Gold</span>
            </Badge>
          </div>
          <CardDescription>
            Manage your equipment, weapons, armor, and magical items
          </CardDescription>
        </CardHeader>
        
        <CardContent className="p-0">
          <Tabs defaultValue="all">
            <TabsList className="w-full rounded-none px-4 pt-2">
              <TabsTrigger value="all">All</TabsTrigger>
              <TabsTrigger value="weapons">Weapons</TabsTrigger>
              <TabsTrigger value="armor">Armor</TabsTrigger>
              <TabsTrigger value="magic">Magic Items</TabsTrigger>
              <TabsTrigger value="potions">Potions</TabsTrigger>
            </TabsList>
            
            <TabsContent value="all" className="pt-0">
              <div className="p-4">
                <h3 className="text-sm font-medium mb-2 text-muted-foreground">Equipped Items</h3>
                {inventory.some(item => item.equipped) ? (
                  <div className="space-y-2 mb-4">
                    {inventory.filter(item => item.equipped).map(item => (
                      <ItemCard 
                        key={item.id} 
                        item={item} 
                        onViewDetails={() => viewItemDetails(item.id)}
                        onEquip={() => openConfirmAction(item, 'unequip')}
                        onAttune={item.attunement && !item.attuned ? () => openConfirmAction(item, 'attune') : undefined}
                        onUnattune={item.attuned ? () => openConfirmAction(item, 'unattune') : undefined}
                        equipped={true}
                        attuned={item.attuned}
                        onUse={item.type.toLowerCase() === 'potion' ? () => handleUseItem(item) : undefined}
                      />
                    ))}
                  </div>
                ) : (
                  <div className="border border-dashed rounded-md p-3 text-center mb-4">
                    <p className="text-sm text-muted-foreground">No equipped items</p>
                  </div>
                )}
                
                <Separator className="my-3" />
                
                <h3 className="text-sm font-medium mb-2 text-muted-foreground">All Items ({inventory.length})</h3>
                <ScrollArea className="h-[300px] pr-4">
                  <div className="space-y-2">
                    {inventory.length > 0 ? inventory.map(item => (
                      <ItemCard 
                        key={item.id} 
                        item={item} 
                        onViewDetails={() => viewItemDetails(item.id)}
                        onEquip={!item.equipped ? () => openConfirmAction(item, 'equip') : undefined}
                        onAttune={item.attunement && !item.attuned ? () => openConfirmAction(item, 'attune') : undefined}
                        onUnattune={item.attuned ? () => openConfirmAction(item, 'unattune') : undefined}
                        equipped={item.equipped}
                        attuned={item.attuned}
                        onUse={item.type.toLowerCase() === 'potion' ? () => handleUseItem(item) : undefined}
                        onDiscard={() => openConfirmAction(item, 'discard')}
                      />
                    )) : (
                      <div className="border border-dashed rounded-md p-6 text-center">
                        <Package className="h-8 w-8 mx-auto mb-2 text-muted-foreground opacity-50" />
                        <p className="text-sm text-muted-foreground">No items in inventory</p>
                      </div>
                    )}
                  </div>
                </ScrollArea>
              </div>
            </TabsContent>
            
            <TabsContent value="weapons" className="pt-0">
              <div className="p-4">
                <ScrollArea className="h-[360px] pr-4">
                  <div className="space-y-2">
                    {weapons.length > 0 ? weapons.map(item => (
                      <ItemCard 
                        key={item.id} 
                        item={item} 
                        onViewDetails={() => viewItemDetails(item.id)}
                        onEquip={!item.equipped ? () => openConfirmAction(item, 'equip') : 
                                 () => openConfirmAction(item, 'unequip')}
                        onAttune={item.attunement && !item.attuned ? () => openConfirmAction(item, 'attune') : undefined}
                        onUnattune={item.attuned ? () => openConfirmAction(item, 'unattune') : undefined}
                        equipped={item.equipped}
                        attuned={item.attuned}
                        onDiscard={() => openConfirmAction(item, 'discard')}
                      />
                    )) : (
                      <div className="border border-dashed rounded-md p-6 text-center">
                        <Sword className="h-8 w-8 mx-auto mb-2 text-muted-foreground opacity-50" />
                        <p className="text-sm text-muted-foreground">No weapons in inventory</p>
                      </div>
                    )}
                  </div>
                </ScrollArea>
              </div>
            </TabsContent>
            
            <TabsContent value="armor" className="pt-0">
              <div className="p-4">
                <ScrollArea className="h-[360px] pr-4">
                  <div className="space-y-2">
                    {armor.length > 0 ? armor.map(item => (
                      <ItemCard 
                        key={item.id} 
                        item={item} 
                        onViewDetails={() => viewItemDetails(item.id)}
                        onEquip={!item.equipped ? () => openConfirmAction(item, 'equip') : 
                                 () => openConfirmAction(item, 'unequip')}
                        onAttune={item.attunement && !item.attuned ? () => openConfirmAction(item, 'attune') : undefined}
                        onUnattune={item.attuned ? () => openConfirmAction(item, 'unattune') : undefined}
                        equipped={item.equipped}
                        attuned={item.attuned}
                        onDiscard={() => openConfirmAction(item, 'discard')}
                      />
                    )) : (
                      <div className="border border-dashed rounded-md p-6 text-center">
                        <Shield className="h-8 w-8 mx-auto mb-2 text-muted-foreground opacity-50" />
                        <p className="text-sm text-muted-foreground">No armor in inventory</p>
                      </div>
                    )}
                  </div>
                </ScrollArea>
              </div>
            </TabsContent>
            
            <TabsContent value="magic" className="pt-0">
              <div className="p-4">
                <div className="bg-blue-50 border border-blue-200 rounded-md p-3 mb-4">
                  <div className="flex items-start">
                    <Info className="h-5 w-5 text-blue-500 mr-2 mt-0.5" />
                    <div>
                      <h4 className="text-sm font-medium text-blue-800">Attunement ({attunedItemsCount}/3)</h4>
                      <p className="text-xs text-blue-700">
                        Some magic items require attunement. You can be attuned to no more than three magic items at a time.
                      </p>
                    </div>
                  </div>
                </div>
                
                <ScrollArea className="h-[300px] pr-4">
                  <div className="space-y-2">
                    {wondrous.length > 0 ? wondrous.map(item => (
                      <ItemCard 
                        key={item.id} 
                        item={item} 
                        onViewDetails={() => viewItemDetails(item.id)}
                        onEquip={!item.equipped ? () => openConfirmAction(item, 'equip') : 
                                 () => openConfirmAction(item, 'unequip')}
                        onAttune={item.attunement && !item.attuned ? () => openConfirmAction(item, 'attune') : undefined}
                        onUnattune={item.attuned ? () => openConfirmAction(item, 'unattune') : undefined}
                        equipped={item.equipped}
                        attuned={item.attuned}
                        onDiscard={() => openConfirmAction(item, 'discard')}
                      />
                    )) : (
                      <div className="border border-dashed rounded-md p-6 text-center">
                        <Sparkles className="h-8 w-8 mx-auto mb-2 text-muted-foreground opacity-50" />
                        <p className="text-sm text-muted-foreground">No magic items in inventory</p>
                      </div>
                    )}
                  </div>
                </ScrollArea>
              </div>
            </TabsContent>
            
            <TabsContent value="potions" className="pt-0">
              <div className="p-4">
                <ScrollArea className="h-[360px] pr-4">
                  <div className="space-y-2">
                    {potions.length > 0 ? potions.map(item => (
                      <ItemCard 
                        key={item.id} 
                        item={item} 
                        onViewDetails={() => viewItemDetails(item.id)}
                        onUse={() => handleUseItem(item)}
                        equipped={false}
                        attuned={false}
                        onDiscard={() => openConfirmAction(item, 'discard')}
                      />
                    )) : (
                      <div className="border border-dashed rounded-md p-6 text-center">
                        <Potion className="h-8 w-8 mx-auto mb-2 text-muted-foreground opacity-50" />
                        <p className="text-sm text-muted-foreground">No potions in inventory</p>
                      </div>
                    )}
                  </div>
                </ScrollArea>
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
      
      {/* Item Details Dialog */}
      {activeItem && (
        <Dialog open={detailsOpen} onOpenChange={setDetailsOpen}>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <div className="flex justify-between items-start">
                <DialogTitle className="font-fantasy">{activeItem.name}</DialogTitle>
                <Badge className={getRarityColor(activeItem.rarity)}>
                  {activeItem.rarity.charAt(0).toUpperCase() + activeItem.rarity.slice(1)}
                </Badge>
              </div>
              <DialogDescription>
                {activeItem.type.charAt(0).toUpperCase() + activeItem.type.slice(1)}
                {activeItem.attunement && " (requires attunement)"}
              </DialogDescription>
            </DialogHeader>
            
            <div className="space-y-4">
              <div className="flex justify-center">
                <div className={`w-16 h-16 rounded-full ${getRarityColor(activeItem.rarity)} flex items-center justify-center`}>
                  {getItemIcon(activeItem.type)}
                </div>
              </div>
              
              <p className="text-gray-700">{activeItem.description}</p>
              
              {(activeItem.equipped || activeItem.attuned) && (
                <div className="flex space-x-2 pt-2">
                  {activeItem.equipped && (
                    <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                      <CheckCircle2 className="h-3 w-3 mr-1" /> Equipped
                    </Badge>
                  )}
                  
                  {activeItem.attuned && (
                    <Badge variant="outline" className="bg-purple-50 text-purple-700 border-purple-200">
                      <Sparkles className="h-3 w-3 mr-1" /> Attuned
                    </Badge>
                  )}
                </div>
              )}
            </div>
            
            <DialogFooter className="sm:justify-between">
              <Button
                variant="outline"
                size="sm"
                onClick={() => {
                  navigator.clipboard.writeText(activeItem.description);
                  toast({
                    title: "Copied",
                    description: "Item description copied to clipboard",
                    variant: "default",
                  });
                }}
              >
                <Clipboard className="h-4 w-4 mr-1" />
                Copy
              </Button>
              <Button onClick={() => setDetailsOpen(false)}>Close</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}
      
      {/* Confirmation Dialog */}
      {confirmAction.item && (
        <Dialog open={confirmAction.open} onOpenChange={(open) => !open && setConfirmAction({...confirmAction, open})}>
          <DialogContent className="max-w-sm">
            <DialogHeader>
              <DialogTitle>
                {confirmAction.action === 'discard' ? 'Discard Item?' : 
                 confirmAction.action === 'equip' ? 'Equip Item?' :
                 confirmAction.action === 'unequip' ? 'Unequip Item?' :
                 confirmAction.action === 'attune' ? 'Attune to Item?' : 'Remove Attunement?'}
              </DialogTitle>
              <DialogDescription>
                {confirmAction.action === 'discard' ? 'This will permanently remove the item from your inventory.' : 
                 confirmAction.action === 'equip' ? 'This will equip the item, replacing any item in the same slot.' :
                 confirmAction.action === 'unequip' ? 'This will unequip the item.' :
                 confirmAction.action === 'attune' ? `This will attune you to this item (${attunedItemsCount}/3 attunements used).` : 
                 'This will remove your attunement to this item.'}
              </DialogDescription>
            </DialogHeader>
            
            <div className="py-3">
              <p className="font-medium">{confirmAction.item.name}</p>
              <p className="text-sm text-muted-foreground">{confirmAction.item.type}</p>
            </div>
            
            <DialogFooter>
              <Button 
                variant="ghost" 
                onClick={() => setConfirmAction({...confirmAction, open: false})}
              >
                Cancel
              </Button>
              <Button 
                variant={confirmAction.action === 'discard' ? 'destructive' : 'default'}
                onClick={() => handleEquipmentChange(confirmAction.item!, confirmAction.action)}
              >
                Confirm
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
}

// Item card component used in the equipment manager
function ItemCard({ 
  item, 
  onViewDetails, 
  onEquip, 
  onAttune,
  onUnattune,
  equipped = false,
  attuned = false,
  onUse,
  onDiscard
}: { 
  item: InventoryItem; 
  onViewDetails?: () => void;
  onEquip?: () => void;
  onAttune?: () => void;
  onUnattune?: () => void;
  equipped?: boolean;
  attuned?: boolean;
  onUse?: () => void;
  onDiscard?: () => void;
}) {
  return (
    <div className={`border rounded-md p-3 ${equipped ? 'bg-green-50 border-green-200' : 'bg-white'}`}>
      <div className="flex justify-between items-center">
        <div className="flex items-center space-x-3">
          <div className={`rounded-full p-2 ${getRarityColor(item.rarity)}`}>
            {getItemIcon(item.type)}
          </div>
          <div>
            <div className="font-medium flex items-center space-x-1">
              <span>{item.name}</span>
              {item.attunement && (
                <TooltipProvider>
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <span>
                        {attuned ? (
                          <Sparkles className="h-3.5 w-3.5 text-purple-500" />
                        ) : (
                          <Circle className="h-3.5 w-3.5 text-gray-400" />
                        )}
                      </span>
                    </TooltipTrigger>
                    <TooltipContent>
                      {attuned ? "Attuned" : "Requires Attunement"}
                    </TooltipContent>
                  </Tooltip>
                </TooltipProvider>
              )}
            </div>
            <div className="text-xs text-gray-500 flex items-center space-x-1">
              <span>{item.type}</span>
              {equipped && (
                <>
                  <span>•</span>
                  <span className="text-green-600 font-medium flex items-center">
                    <CheckCircle2 className="h-3 w-3 mr-0.5" />
                    Equipped
                  </span>
                </>
              )}
            </div>
          </div>
        </div>
        
        <div className="flex items-center space-x-1">
          {onUse && (
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button size="icon" variant="ghost" onClick={onUse} className="h-7 w-7">
                    <Potion className="h-4 w-4" />
                  </Button>
                </TooltipTrigger>
                <TooltipContent>
                  <p>Use Item</p>
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
          )}
          
          {onViewDetails && (
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button size="icon" variant="ghost" onClick={onViewDetails} className="h-7 w-7">
                    <Eye className="h-4 w-4" />
                  </Button>
                </TooltipTrigger>
                <TooltipContent>
                  <p>View Details</p>
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
          )}
          
          {onEquip && (
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button 
                    size="icon" 
                    variant={equipped ? "outline" : "ghost"} 
                    onClick={onEquip} 
                    className="h-7 w-7"
                  >
                    {equipped ? <X className="h-4 w-4" /> : <CheckCircle2 className="h-4 w-4" />}
                  </Button>
                </TooltipTrigger>
                <TooltipContent>
                  <p>{equipped ? "Unequip" : "Equip"}</p>
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
          )}
          
          {onAttune && (
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button size="icon" variant="ghost" onClick={onAttune} className="h-7 w-7">
                    <Sparkles className="h-4 w-4" />
                  </Button>
                </TooltipTrigger>
                <TooltipContent>
                  <p>Attune</p>
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
          )}
          
          {onUnattune && (
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button size="icon" variant="outline" onClick={onUnattune} className="h-7 w-7">
                    <Sparkles className="h-4 w-4 text-purple-500" />
                  </Button>
                </TooltipTrigger>
                <TooltipContent>
                  <p>Remove Attunement</p>
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
          )}
          
          {onDiscard && (
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button size="icon" variant="ghost" onClick={onDiscard} className="h-7 w-7 text-red-500 hover:text-red-600 hover:bg-red-50">
                    <X className="h-4 w-4" />
                  </Button>
                </TooltipTrigger>
                <TooltipContent>
                  <p>Discard Item</p>
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
          )}
        </div>
      </div>
    </div>
  );
}