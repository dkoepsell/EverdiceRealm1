import React from 'react';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { Info } from 'lucide-react';
import { Button } from './button';

export function RulesReference({ term, children }: { term: string; children: React.ReactNode }) {
  const ruleInfo = getDndRuleInfo(term);
  
  return (
    <Tooltip delayDuration={200}>
      <TooltipTrigger asChild>
        <span className="border-b border-dotted border-primary cursor-help">
          {children}
        </span>
      </TooltipTrigger>
      <TooltipContent className="w-80 p-4 rounded-lg">
        <div className="space-y-2">
          <div className="font-bold text-lg text-primary">{ruleInfo.title}</div>
          <p className="text-sm">{ruleInfo.description}</p>
          {ruleInfo.example && (
            <div className="text-sm text-muted-foreground">
              <span className="font-semibold">Example: </span>
              {ruleInfo.example}
            </div>
          )}
        </div>
      </TooltipContent>
    </Tooltip>
  );
}

export function RulesReferenceCard({ term }: { term: string }) {
  const ruleInfo = getDndRuleInfo(term);
  
  return (
    <div className="bg-secondary/50 border border-border rounded-lg p-4 mb-4 shadow-sm">
      <div className="flex items-center space-x-2 mb-2">
        <Info className="h-5 w-5 text-primary" />
        <h4 className="font-bold text-lg">{ruleInfo.title}</h4>
      </div>
      <p className="text-sm mb-2">{ruleInfo.description}</p>
      {ruleInfo.example && (
        <div className="text-sm text-muted-foreground mt-2 p-2 bg-background/50 rounded border border-border">
          <span className="font-semibold">Example: </span>
          {ruleInfo.example}
        </div>
      )}
    </div>
  );
}

export function RulesInfoButton({ term }: { term: string }) {
  const ruleInfo = getDndRuleInfo(term);
  
  return (
    <TooltipProvider>
      <Tooltip delayDuration={200}>
        <TooltipTrigger asChild>
          <Button variant="ghost" size="sm" className="h-7 w-7 p-0">
            <Info className="h-4 w-4" />
          </Button>
        </TooltipTrigger>
        <TooltipContent className="w-80 p-4">
          <div className="space-y-2">
            <div className="font-bold text-lg text-primary">{ruleInfo.title}</div>
            <p className="text-sm">{ruleInfo.description}</p>
            {ruleInfo.example && (
              <div className="text-sm text-muted-foreground">
                <span className="font-semibold">Example: </span>
                {ruleInfo.example}
              </div>
            )}
          </div>
        </TooltipContent>
      </Tooltip>
    </TooltipProvider>
  );
}

function getDndRuleInfo(term: string): { title: string; description: string; example?: string } {
  const rules: Record<string, { title: string; description: string; example?: string }> = {
    ability_check: {
      title: "Ability Check",
      description: "When attempting a task that has a chance of failure, the DM may ask for an ability check. Roll a d20 and add your ability modifier. If the total equals or exceeds the difficulty class (DC), you succeed.",
      example: "To climb a slippery cliff, you might make a Strength (Athletics) check against a DC of 15."
    },
    advantage: {
      title: "Advantage",
      description: "When you have advantage on an ability check, attack roll, or saving throw, you roll two d20s and take the higher result.",
      example: "A rogue attacking a creature that is surprised has advantage on the attack roll."
    },
    disadvantage: {
      title: "Disadvantage",
      description: "When you have disadvantage on an ability check, attack roll, or saving throw, you roll two d20s and take the lower result.",
      example: "Attacking a target you can't see gives you disadvantage on the roll."
    },
    attack_roll: {
      title: "Attack Roll",
      description: "When you make an attack, roll a d20 and add your attack modifier. If the total equals or exceeds the target's Armor Class (AC), you hit.",
      example: "A fighter with +7 to hit rolls a 12, for a total of 19. If the target's AC is 18 or lower, the attack hits."
    },
    damage_roll: {
      title: "Damage Roll",
      description: "When you hit with an attack, roll the weapon's damage die and add relevant modifiers to determine how much damage you deal.",
      example: "A longsword deals 1d8 slashing damage. With a +3 Strength modifier, you would deal 1d8+3 damage on a hit."
    },
    critical_hit: {
      title: "Critical Hit",
      description: "When you roll a 20 on an attack roll, you score a critical hit, which means you roll extra damage dice for the attack's damage.",
      example: "If your attack normally does 1d8+3 damage, a critical hit would deal 2d8+3 damage."
    },
    saving_throw: {
      title: "Saving Throw",
      description: "When you are subjected to a harmful effect, you might be allowed a saving throw to resist it. Roll a d20 and add your saving throw modifier for the ability being tested.",
      example: "A wizard casts Fireball, forcing creatures in the area to make a Dexterity saving throw (DC 15) or take full damage."
    },
    initiative: {
      title: "Initiative",
      description: "At the start of combat, everyone rolls initiative (a Dexterity check) to determine the order of turns. The highest roll goes first, followed by the next highest, and so on.",
      example: "Your character has a +2 Dexterity modifier. You roll a 15 on the d20, for a total initiative of 17."
    },
    proficiency: {
      title: "Proficiency Bonus",
      description: "Your proficiency bonus applies to ability checks, saving throws, and attack rolls you're proficient with. It starts at +2 at 1st level and increases as you gain levels.",
      example: "A 5th-level character has a +3 proficiency bonus, which is added to any skill or saving throw they're proficient in."
    },
    spell_save_dc: {
      title: "Spell Save DC",
      description: "The difficulty class for a saving throw against your spell equals 8 + your spellcasting ability modifier + your proficiency bonus.",
      example: "A wizard with an Intelligence of 16 (+3) and a proficiency bonus of +2 would have a spell save DC of 8 + 3 + 2 = 13."
    },
    conditions: {
      title: "Conditions",
      description: "Conditions alter a creature's capabilities in various ways. Examples include blinded, charmed, frightened, paralyzed, poisoned, and stunned.",
      example: "A creature that is poisoned has disadvantage on attack rolls and ability checks."
    },
    skill_check: {
      title: "Skill Check",
      description: "A skill check is a type of ability check that measures your proficiency in a specific skill. If you're proficient in a skill, you add your proficiency bonus to the ability check.",
      example: "When trying to find hidden traps, you make a Wisdom (Perception) check, adding both your Wisdom modifier and your proficiency bonus if you're proficient in Perception."
    },
    death_saving_throw: {
      title: "Death Saving Throw",
      description: "When you start your turn with 0 hit points, you make a death saving throw. Roll a d20 with no modifiers. On a 10 or higher, you succeed; on a 9 or lower, you fail. Three successes: you stabilize. Three failures: you die.",
      example: "After falling unconscious in battle, you roll a 12 on your first death save, which counts as one success."
    },
    concentration: {
      title: "Concentration",
      description: "Some spells require concentration to maintain their effects. If you take damage while concentrating, you must make a Constitution saving throw to maintain concentration.",
      example: "While maintaining Fly on an ally, you take 10 damage and must make a Constitution saving throw with a DC of 10 to maintain concentration."
    },
    persuasion: {
      title: "Persuasion (Charisma)",
      description: "Used when you attempt to influence someone or a group of people with tact, social graces, or good nature. Typically used for honest social interaction.",
      example: "Convincing a guard to let you through a checkpoint, or negotiating lower prices with a merchant."
    },
    intimidation: {
      title: "Intimidation (Charisma)",
      description: "When you attempt to influence others through overt threats, hostile actions, or physical violence. Also used to determine if you can coerce information out of someone.",
      example: "Trying to scare bandits into revealing where they've hidden their treasure, or making a show of force to prevent a bar fight."
    },
    deception: {
      title: "Deception (Charisma)",
      description: "Your ability to convincingly hide the truth, either verbally or through your actions. Includes everything from misleading others through ambiguity to telling outright lies.",
      example: "Trying to bluff your way past a guard, disguising yourself as someone else, or telling a convincing lie."
    },
    insight: {
      title: "Insight (Wisdom)",
      description: "Determines whether you can determine the true intentions of a creature, detect a lie, or predict someone's next move by reading body language and speech habits.",
      example: "Determining if a merchant is being honest about an item's value or sensing if someone is hiding information from you."
    },
    short_rest: {
      title: "Short Rest",
      description: "A period of downtime, at least 1 hour long, during which characters do nothing more strenuous than eating, drinking, reading, and tending to wounds. A character can spend hit dice during a short rest to regain hit points.",
      example: "After a skirmish, your party takes a short rest. Your character spends 2 hit dice to recover some hit points."
    },
    long_rest: {
      title: "Long Rest",
      description: "A period of extended downtime, at least 8 hours long, during which characters sleep or perform light activity. After a long rest, characters regain all hit points and half their maximum hit dice.",
      example: "After a day of adventuring, your party sets up camp for the night, taking a long rest to fully recover."
    },
    armor_class: {
      title: "Armor Class (AC)",
      description: "Represents how difficult it is to land a damaging blow on a creature. AC is determined by armor worn, Dexterity modifier, and sometimes other factors like shields or spells.",
      example: "A character wearing studded leather armor (AC 12) with a Dexterity modifier of +2 would have an AC of 14."
    },
    difficult_terrain: {
      title: "Difficult Terrain",
      description: "Areas that require greater effort to move through. Each foot of movement in difficult terrain costs 1 extra foot (2 total), reflecting slower speed.",
      example: "Walking through a dense forest, rubble-filled ruins, or waist-deep water would count as difficult terrain."
    },
    opportunity_attack: {
      title: "Opportunity Attack",
      description: "When a creature you can see moves out of your reach, you can use your reaction to make one melee attack against it.",
      example: "An enemy tries to run past your fighter to attack your wizard. As they leave your weapon's reach, you make an opportunity attack."
    },
    disengage: {
      title: "Disengage Action",
      description: "If you take the Disengage action, your movement doesn't provoke opportunity attacks for the rest of the turn.",
      example: "A rogue wants to retreat from melee combat without risking an opportunity attack, so they use their action to Disengage before moving away."
    },
    dash: {
      title: "Dash Action",
      description: "When you take the Dash action, you gain extra movement for the current turn equal to your speed, after applying any modifiers.",
      example: "A character with a speed of 30 feet who takes the Dash action can move up to 60 feet on that turn."
    },
    dodge: {
      title: "Dodge Action",
      description: "When you take the Dodge action, you focus on avoiding attacks. Until the start of your next turn, attack rolls against you have disadvantage.",
      example: "Surrounded by enemies, a fighter takes the Dodge action to increase their chances of survival until allies can reach them."
    },
    readied_action: {
      title: "Ready Action",
      description: "You can ready an action to trigger in response to a specific circumstance. When the trigger occurs, you can use your reaction to take the readied action.",
      example: "\"I ready my bow to shoot if the goblin steps out from behind the rock.\""
    },
  };

  return rules[term] || {
    title: term.charAt(0).toUpperCase() + term.slice(1).replace('_', ' '),
    description: "No specific rule information available for this term.",
  };
}