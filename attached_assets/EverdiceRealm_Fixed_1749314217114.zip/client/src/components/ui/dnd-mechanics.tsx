
import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  Dice1, Dice2, Dice3, Dice4, Dice5, Dice6,
  Zap, Shield, Heart, Brain, Eye, Smile,
  TrendingUp, TrendingDown, Minus
} from "lucide-react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { 
  makeAbilityCheck, 
  makeSavingThrow, 
  getAbilityModifier, 
  formatModifier, 
  DifficultyClass,
  AbilityScores 
} from '@/lib/diceUtils';

interface DNDMechanicsProps {
  character: {
    strength: number;
    dexterity: number;
    constitution: number;
    intelligence: number;
    wisdom: number;
    charisma: number;
    level: number;
    proficiencies?: string[];
  };
  onRollComplete?: (result: any) => void;
}

const abilityIcons = {
  [AbilityScores.STRENGTH]: Zap,
  [AbilityScores.DEXTERITY]: Dice6,
  [AbilityScores.CONSTITUTION]: Heart,
  [AbilityScores.INTELLIGENCE]: Brain,
  [AbilityScores.WISDOM]: Eye,
  [AbilityScores.CHARISMA]: Smile,
};

const abilityNames = {
  [AbilityScores.STRENGTH]: 'Strength',
  [AbilityScores.DEXTERITY]: 'Dexterity', 
  [AbilityScores.CONSTITUTION]: 'Constitution',
  [AbilityScores.INTELLIGENCE]: 'Intelligence',
  [AbilityScores.WISDOM]: 'Wisdom',
  [AbilityScores.CHARISMA]: 'Charisma',
};

export function DNDMechanics({ character, onRollComplete }: DNDMechanicsProps) {
  const [selectedAbility, setSelectedAbility] = useState<string>(AbilityScores.STRENGTH);
  const [selectedDC, setSelectedDC] = useState<number>(DifficultyClass.MEDIUM);
  const [advantage, setAdvantage] = useState<'normal' | 'advantage' | 'disadvantage'>('normal');
  const [rollType, setRollType] = useState<'check' | 'save'>('check');
  const [lastRoll, setLastRoll] = useState<any>(null);

  const handleRoll = () => {
    const abilityScore = character[selectedAbility as keyof typeof character] as number;
    const isProficient = character.proficiencies?.includes(selectedAbility) || false;
    
    let result;
    if (rollType === 'check') {
      result = makeAbilityCheck(abilityScore, isProficient, character.level, advantage);
      result.type = 'Ability Check';
      result.success = result.total >= selectedDC;
      result.dc = selectedDC;
    } else {
      result = makeSavingThrow(abilityScore, isProficient, character.level, selectedDC, advantage);
      result.type = 'Saving Throw';
    }
    
    result.ability = selectedAbility;
    result.abilityName = abilityNames[selectedAbility as keyof typeof abilityNames];
    
    setLastRoll(result);
    onRollComplete?.(result);
  };

  const getAdvantageIcon = () => {
    switch (advantage) {
      case 'advantage': return <TrendingUp className="h-4 w-4 text-green-500" />;
      case 'disadvantage': return <TrendingDown className="h-4 w-4 text-red-500" />;
      default: return <Minus className="h-4 w-4 text-gray-500" />;
    }
  };

  const getDifficultyText = (dc: number) => {
    if (dc <= 10) return 'Easy';
    if (dc <= 15) return 'Medium';
    if (dc <= 20) return 'Hard';
    if (dc <= 25) return 'Very Hard';
    return 'Nearly Impossible';
  };

  const renderRollResult = (roll: any) => {
    if (typeof roll === 'object') {
      return (
        <div className="text-center">
          <div className="text-sm text-muted-foreground">
            Rolled: {roll.roll1}, {roll.roll2}
          </div>
          <div className="text-lg font-bold">
            Result: {roll.result}
          </div>
        </div>
      );
    }
    return <div className="text-lg font-bold">Rolled: {roll}</div>;
  };

  return (
    <Card className="w-full max-w-md">
      <CardHeader>
        <CardTitle className="flex items-center">
          <Dice1 className="h-5 w-5 mr-2" />
          D&D Mechanics
        </CardTitle>
        <CardDescription>
          Make ability checks and saving throws with proper D&D 5e rules
        </CardDescription>
      </CardHeader>
      
      <CardContent className="space-y-4">
        {/* Roll Type Selection */}
        <div>
          <label className="text-sm font-medium">Roll Type</label>
          <Select value={rollType} onValueChange={(value: 'check' | 'save') => setRollType(value)}>
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="check">Ability Check</SelectItem>
              <SelectItem value="save">Saving Throw</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* Ability Selection */}
        <div>
          <label className="text-sm font-medium">Ability</label>
          <Select value={selectedAbility} onValueChange={setSelectedAbility}>
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {Object.entries(abilityNames).map(([key, name]) => {
                const score = character[key as keyof typeof character] as number;
                const modifier = getAbilityModifier(score);
                const Icon = abilityIcons[key as keyof typeof abilityIcons];
                
                return (
                  <SelectItem key={key} value={key}>
                    <div className="flex items-center">
                      <Icon className="h-4 w-4 mr-2" />
                      {name} ({score}) {formatModifier(modifier)}
                    </div>
                  </SelectItem>
                );
              })}
            </SelectContent>
          </Select>
        </div>

        {/* Difficulty Class */}
        <div>
          <label className="text-sm font-medium">Difficulty Class</label>
          <Select value={selectedDC.toString()} onValueChange={(value) => setSelectedDC(parseInt(value))}>
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value={DifficultyClass.TRIVIAL.toString()}>
                DC {DifficultyClass.TRIVIAL} (Trivial)
              </SelectItem>
              <SelectItem value={DifficultyClass.EASY.toString()}>
                DC {DifficultyClass.EASY} (Easy)
              </SelectItem>
              <SelectItem value={DifficultyClass.MEDIUM.toString()}>
                DC {DifficultyClass.MEDIUM} (Medium)
              </SelectItem>
              <SelectItem value={DifficultyClass.HARD.toString()}>
                DC {DifficultyClass.HARD} (Hard)
              </SelectItem>
              <SelectItem value={DifficultyClass.VERY_HARD.toString()}>
                DC {DifficultyClass.VERY_HARD} (Very Hard)
              </SelectItem>
              <SelectItem value={DifficultyClass.NEARLY_IMPOSSIBLE.toString()}>
                DC {DifficultyClass.NEARLY_IMPOSSIBLE} (Nearly Impossible)
              </SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* Advantage/Disadvantage */}
        <div>
          <label className="text-sm font-medium">Advantage/Disadvantage</label>
          <Select value={advantage} onValueChange={(value: 'normal' | 'advantage' | 'disadvantage') => setAdvantage(value)}>
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="normal">
                <div className="flex items-center">
                  <Minus className="h-4 w-4 mr-2 text-gray-500" />
                  Normal Roll
                </div>
              </SelectItem>
              <SelectItem value="advantage">
                <div className="flex items-center">
                  <TrendingUp className="h-4 w-4 mr-2 text-green-500" />
                  Advantage (roll twice, take higher)
                </div>
              </SelectItem>
              <SelectItem value="disadvantage">
                <div className="flex items-center">
                  <TrendingDown className="h-4 w-4 mr-2 text-red-500" />
                  Disadvantage (roll twice, take lower)
                </div>
              </SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* Roll Result */}
        {lastRoll && (
          <Card className={`border-2 ${lastRoll.success ? 'border-green-500 bg-green-50' : 'border-red-500 bg-red-50'}`}>
            <CardContent className="pt-4">
              <div className="text-center space-y-2">
                <div className="flex items-center justify-center space-x-2">
                  {getAdvantageIcon()}
                  <h4 className="font-semibold">
                    {lastRoll.abilityName} {lastRoll.type}
                  </h4>
                </div>
                
                {renderRollResult(lastRoll.roll)}
                
                <div className="text-sm space-y-1">
                  <div>
                    Ability Modifier: {formatModifier(lastRoll.abilityModifier)}
                  </div>
                  {lastRoll.proficiencyBonus > 0 && (
                    <div>
                      Proficiency Bonus: +{lastRoll.proficiencyBonus}
                    </div>
                  )}
                  <div className="font-semibold">
                    Total: {lastRoll.total}
                  </div>
                </div>
                
                <div className="flex items-center justify-center space-x-2">
                  <Badge variant={lastRoll.success ? "default" : "destructive"}>
                    {lastRoll.success ? "SUCCESS" : "FAILURE"}
                  </Badge>
                  <span className="text-sm">vs DC {lastRoll.dc}</span>
                </div>
              </div>
            </CardContent>
          </Card>
        )}
      </CardContent>
      
      <CardFooter>
        <Button onClick={handleRoll} className="w-full">
          <Dice1 className="h-4 w-4 mr-2" />
          Roll {rollType === 'check' ? 'Ability Check' : 'Saving Throw'}
        </Button>
      </CardFooter>
    </Card>
  );
}

export default DNDMechanics;
