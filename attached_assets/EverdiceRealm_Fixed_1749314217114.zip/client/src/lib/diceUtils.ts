
/**
 * Roll a single die and return the result
 * @param sides Number of sides on the die
 * @returns Random number between 1 and sides
 */
export function rollDie(sides: number): number {
  return Math.floor(Math.random() * sides) + 1;
}

/**
 * Parse a dice notation string (e.g., "2d6", "1d20+2") and roll the dice
 * @param diceNotation Dice notation in standard D&D format
 * @param additionalModifier Optional modifier to add to the result
 * @returns Object containing roll details
 */
export function rollDice(diceNotation: string, additionalModifier: number = 0): {
  rolls: number[];
  result: number;
  total: number;
  notation: string;
} {
  // Parse the dice notation
  const diceRegex = /(\d+)?d(\d+)(?:([+-])(\d+))?/i;
  const match = diceNotation.match(diceRegex);

  if (!match) {
    throw new Error(`Invalid dice notation: ${diceNotation}`);
  }

  const numDice = parseInt(match[1] || '1');
  const sides = parseInt(match[2]);
  const hasModifier = match[3] !== undefined;
  const modifierSign = match[3] === '+' ? 1 : -1;
  const modifier = hasModifier ? parseInt(match[4]) * modifierSign : 0;

  // Roll the dice
  const rolls: number[] = [];
  let result = 0;

  for (let i = 0; i < numDice; i++) {
    const roll = rollDie(sides);
    rolls.push(roll);
    result += roll;
  }

  // Add the modifier from the notation
  const totalWithModifier = result + modifier;

  // Add any additional modifier passed to the function
  const finalTotal = totalWithModifier + additionalModifier;

  // Create a string representation of the dice notation with all modifiers
  const totalModifier = modifier + additionalModifier;
  const modifierString = totalModifier === 0 ? '' : 
                          totalModifier > 0 ? `+${totalModifier}` : 
                          `${totalModifier}`;

  return {
    rolls,
    result,
    total: finalTotal,
    notation: `${numDice}d${sides}${modifierString}`
  };
}

/**
 * Calculate ability modifier from ability score
 * @param score Ability score (e.g., Strength, Dexterity)
 * @returns Calculated modifier
 */
export function getAbilityModifier(score: number): number {
  return Math.floor((score - 10) / 2);
}

/**
 * Format ability modifier for display (e.g., "+2" or "-1")
 * @param modifier Ability modifier value
 * @returns Formatted string
 */
export function formatModifier(modifier: number): string {
  return modifier >= 0 ? `+${modifier}` : `${modifier}`;
}

/**
 * Calculate D&D 5e proficiency bonus based on character level
 * @param level Character level
 * @returns Proficiency bonus
 */
export function getProficiencyBonus(level: number): number {
  return Math.floor((level - 1) / 4) + 2;
}

/**
 * Roll with advantage (roll twice, take higher)
 * @param sides Number of sides on the die
 * @returns Object with both rolls and the higher result
 */
export function rollWithAdvantage(sides: number = 20): {
  roll1: number;
  roll2: number;
  result: number;
  type: 'advantage';
} {
  const roll1 = rollDie(sides);
  const roll2 = rollDie(sides);
  return {
    roll1,
    roll2,
    result: Math.max(roll1, roll2),
    type: 'advantage'
  };
}

/**
 * Roll with disadvantage (roll twice, take lower)
 * @param sides Number of sides on the die
 * @returns Object with both rolls and the lower result
 */
export function rollWithDisadvantage(sides: number = 20): {
  roll1: number;
  roll2: number;
  result: number;
  type: 'disadvantage';
} {
  const roll1 = rollDie(sides);
  const roll2 = rollDie(sides);
  return {
    roll1,
    roll2,
    result: Math.min(roll1, roll2),
    type: 'disadvantage'
  };
}

/**
 * Make a D&D ability check
 * @param abilityScore The character's ability score
 * @param proficient Whether the character is proficient in this check
 * @param characterLevel Character level for proficiency bonus
 * @param advantage Whether to roll with advantage/disadvantage
 * @returns Complete ability check result
 */
export function makeAbilityCheck(
  abilityScore: number, 
  proficient: boolean = false, 
  characterLevel: number = 1,
  advantage: 'normal' | 'advantage' | 'disadvantage' = 'normal'
): {
  roll: number | { roll1: number; roll2: number; result: number };
  abilityModifier: number;
  proficiencyBonus: number;
  total: number;
  advantage: 'normal' | 'advantage' | 'disadvantage';
} {
  const abilityModifier = getAbilityModifier(abilityScore);
  const proficiencyBonus = proficient ? getProficiencyBonus(characterLevel) : 0;
  
  let roll: number | { roll1: number; roll2: number; result: number };
  let dieResult: number;
  
  if (advantage === 'advantage') {
    roll = rollWithAdvantage();
    dieResult = roll.result;
  } else if (advantage === 'disadvantage') {
    roll = rollWithDisadvantage();
    dieResult = roll.result;
  } else {
    dieResult = rollDie(20);
    roll = dieResult;
  }
  
  const total = dieResult + abilityModifier + proficiencyBonus;
  
  return {
    roll,
    abilityModifier,
    proficiencyBonus,
    total,
    advantage
  };
}

/**
 * Make a saving throw
 * @param abilityScore The relevant ability score
 * @param proficient Whether proficient in this saving throw
 * @param characterLevel Character level
 * @param dc Difficulty Class to beat
 * @param advantage Advantage/disadvantage state
 * @returns Saving throw result
 */
export function makeSavingThrow(
  abilityScore: number,
  proficient: boolean,
  characterLevel: number,
  dc: number,
  advantage: 'normal' | 'advantage' | 'disadvantage' = 'normal'
): {
  roll: number | { roll1: number; roll2: number; result: number };
  total: number;
  dc: number;
  success: boolean;
  abilityModifier: number;
  proficiencyBonus: number;
  advantage: 'normal' | 'advantage' | 'disadvantage';
} {
  const check = makeAbilityCheck(abilityScore, proficient, characterLevel, advantage);
  
  return {
    roll: check.roll,
    total: check.total,
    dc,
    success: check.total >= dc,
    abilityModifier: check.abilityModifier,
    proficiencyBonus: check.proficiencyBonus,
    advantage
  };
}

/**
 * Calculate attack roll with proper D&D mechanics
 * @param abilityScore Strength for melee, Dexterity for ranged
 * @param proficient Whether proficient with the weapon
 * @param characterLevel Character level
 * @param weaponBonus Any magical weapon bonus
 * @param advantage Advantage/disadvantage state
 * @returns Attack roll result
 */
export function makeAttackRoll(
  abilityScore: number,
  proficient: boolean,
  characterLevel: number,
  weaponBonus: number = 0,
  advantage: 'normal' | 'advantage' | 'disadvantage' = 'normal'
): {
  roll: number | { roll1: number; roll2: number; result: number };
  total: number;
  abilityModifier: number;
  proficiencyBonus: number;
  weaponBonus: number;
  advantage: 'normal' | 'advantage' | 'disadvantage';
  critical: boolean;
  criticalFailure: boolean;
} {
  const abilityModifier = getAbilityModifier(abilityScore);
  const proficiencyBonus = proficient ? getProficiencyBonus(characterLevel) : 0;
  
  let roll: number | { roll1: number; roll2: number; result: number };
  let dieResult: number;
  let critical = false;
  let criticalFailure = false;
  
  if (advantage === 'advantage') {
    roll = rollWithAdvantage();
    dieResult = roll.result;
    // Critical hit on natural 20 (from either die)
    critical = roll.roll1 === 20 || roll.roll2 === 20;
    // Critical failure only if both dice are 1
    criticalFailure = roll.roll1 === 1 && roll.roll2 === 1;
  } else if (advantage === 'disadvantage') {
    roll = rollWithDisadvantage();
    dieResult = roll.result;
    // Critical hit only if both dice are 20
    critical = roll.roll1 === 20 && roll.roll2 === 20;
    // Critical failure on natural 1 (from either die)
    criticalFailure = roll.roll1 === 1 || roll.roll2 === 1;
  } else {
    dieResult = rollDie(20);
    roll = dieResult;
    critical = dieResult === 20;
    criticalFailure = dieResult === 1;
  }
  
  const total = dieResult + abilityModifier + proficiencyBonus + weaponBonus;
  
  return {
    roll,
    total,
    abilityModifier,
    proficiencyBonus,
    weaponBonus,
    advantage,
    critical,
    criticalFailure
  };
}

/**
 * Roll damage dice with proper D&D mechanics
 * @param diceNotation Basic damage dice (e.g., "1d8")
 * @param abilityModifier Ability modifier to add
 * @param weaponBonus Magical weapon bonus
 * @param critical Whether this is a critical hit (double dice)
 * @returns Damage roll result
 */
export function rollDamage(
  diceNotation: string,
  abilityModifier: number = 0,
  weaponBonus: number = 0,
  critical: boolean = false
): {
  rolls: number[];
  baseDamage: number;
  totalDamage: number;
  abilityModifier: number;
  weaponBonus: number;
  critical: boolean;
  notation: string;
} {
  // Parse the base dice
  const baseDice = rollDice(diceNotation);
  let allRolls = [...baseDice.rolls];
  let baseDamage = baseDice.result;
  
  // If critical, roll the damage dice again and add them
  if (critical) {
    const criticalDice = rollDice(diceNotation);
    allRolls = [...allRolls, ...criticalDice.rolls];
    baseDamage += criticalDice.result;
  }
  
  const totalDamage = baseDamage + abilityModifier + weaponBonus;
  
  return {
    rolls: allRolls,
    baseDamage,
    totalDamage: Math.max(1, totalDamage), // Minimum 1 damage
    abilityModifier,
    weaponBonus,
    critical,
    notation: critical ? `${diceNotation} (critical)` : diceNotation
  };
}

/**
 * Get spell save DC
 * @param spellcastingAbility The spellcasting ability score
 * @param characterLevel Character level
 * @returns Spell save DC
 */
export function getSpellSaveDC(spellcastingAbility: number, characterLevel: number): number {
  return 8 + getAbilityModifier(spellcastingAbility) + getProficiencyBonus(characterLevel);
}

/**
 * Standard D&D 5e Difficulty Classes
 */
export const DifficultyClass = {
  TRIVIAL: 5,
  EASY: 10,
  MEDIUM: 15,
  HARD: 20,
  VERY_HARD: 25,
  NEARLY_IMPOSSIBLE: 30
} as const;

/**
 * D&D 5e Ability Scores
 */
export const AbilityScores = {
  STRENGTH: 'strength',
  DEXTERITY: 'dexterity', 
  CONSTITUTION: 'constitution',
  INTELLIGENCE: 'intelligence',
  WISDOM: 'wisdom',
  CHARISMA: 'charisma'
} as const;
