import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { NPCInteractionHandler } from '@/components/campaign/NPCInteractionHandler';
import { SceneManager } from '@/components/campaign/SceneManager';
// Fix the import to match the actual export
import CombatEncounterHandler from '@/components/campaign/CombatEncounterHandler';
import { InlineTip } from "@/components/learning/DnDRulesGuide";
import DNDMechanics from "@/components/ui/dnd-mechanics";
import { 
  BookOpen, 
  DiceD20, 
  Scroll, 
  Swords, 
  Shield, 
  Wand2, 
  User, 
  Map, 
  HelpCircle, 
  Users, 
  Search,
  FileText
} from "lucide-react";

export default function DemoInteractionsPage() {
  const [activeTab, setActiveTab] = useState('story');
  const [showNpcDialog, setShowNpcDialog] = useState(false);
  const [currentScene, setCurrentScene] = useState(demoScenes.forestPath);

  // State for combat display
  const [showCombat, setShowCombat] = useState(false);
  const [combatMonster, setCombatMonster] = useState<any>(null);

  // Handle advancing to next story segment
  const handleStoryAdvance = (result: any) => {
    console.log("Story advance with result:", result);
    // In this demo, we'll simulate different outcomes based on choices
    if (result.action === "Confront the Three-Headed Hound") {
      // Direct trigger for the combat when the specific action is selected
      console.log("Starting combat with the hound");
      setShowCombat(true);
      setCombatMonster(demoMonsters.threeHeadedHound);
      setActiveTab('combat');
    } else if (result.nextScene === 'tavern') {
      setShowCombat(false);
      setCurrentScene(demoScenes.tavern);
    } else if (result.nextScene === 'combat') {
      // Start actual combat with the three-headed hound
      setShowCombat(true);
      setCombatMonster(demoMonsters.threeHeadedHound);
      setActiveTab('combat');
    } else if (result.nextScene === 'npc') {
      // Show NPC interaction dialog
      setShowNpcDialog(true);
    } else {
      // Default to forest scene with a new narrative
      setShowCombat(false);
      setCurrentScene({
        ...demoScenes.forestPath,
        narrative: "You continue down the forest path. The trees seem to thin out ahead, revealing glimpses of a small village in the distance. Birds chirp overhead as the afternoon sun filters through the leaves."
      });
    }
  };

  return (
    <div className="container mx-auto py-8 px-4">
      <h1 className="text-3xl font-bold font-fantasy text-center mb-4 bg-gradient-to-r from-amber-600 to-amber-800 bg-clip-text text-transparent">
        D&D Interactive Experience Demo
      </h1>

      <div className="flex justify-center gap-4 mb-6">
        <Button 
          onClick={() => {
            setShowCombat(true);
            setCombatMonster(demoMonsters.threeHeadedHound);
            setActiveTab('combat');
          }}
          variant="outline"
          className="bg-red-100 text-red-800 hover:bg-red-200 border-red-300"
        >
          Show Combat Demo
        </Button>
        <Button 
          onClick={() => setShowNpcDialog(true)}
          variant="outline"
          className="bg-green-100 text-green-800 hover:bg-green-200 border-green-300"
        >
          Show NPC Demo
        </Button>
      </div>

      <div className="max-w-4xl mx-auto">
        <Tabs defaultValue={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="story">Story Progression</TabsTrigger>
            <TabsTrigger value="combat">Combat Encounters</TabsTrigger>
            <TabsTrigger value="npc">NPC Interactions</TabsTrigger>
          </TabsList>

          <TabsContent value="story" className="py-6">
            <Card>
              <CardHeader>
                <CardTitle>Story Progression System</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="mb-6">
                  Experience how story progression works with skill checks, meaningful choices, and D&D-authentic dice mechanics:
                </p>

                <SceneManager
                  campaignId={1} // Demo campaign ID
                  sessionId={1} // Demo session ID
                  narrative={currentScene.narrative}
                  location={currentScene.location}
                  choices={currentScene.choices}
                  onAdvance={handleStoryAdvance}
                />
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="combat" className="py-6">
            <Card>
              <CardHeader>
                <CardTitle>Combat Encounters</CardTitle>
              </CardHeader>
              <CardContent>
                {!showCombat ? (
                  <>
                    <p className="mb-6">
                      D&D-authentic combat with initiative tracking, turn-based actions, and tactical choices.
                    </p>

                    <div className="space-y-4">
                      <div className="p-6 bg-amber-50 border border-amber-200 rounded-lg">
                        <h3 className="text-xl font-bold mb-4">Combat Demo</h3>
                        <p className="mb-4">
                          Combat encounters now feature:
                        </p>
                        <ul className="list-disc pl-6 space-y-2 mb-6">
                          <li>Initiative-based turn order</li>
                          <li>Class-specific combat actions</li>
                          <li>Authentic dice rolling for attacks and damage</li>
                          <li>Monster AI with tactical decision making</li>
                          <li>Loot and XP rewards based on challenge rating</li>
                        </ul>

                        <Button 
                          onClick={() => {
                            setActiveTab('story');
                            setCurrentScene(demoScenes.combatEncounter);
                          }}
                          className="bg-red-600 hover:bg-red-700"
                        >
                          Start Combat Demo
                        </Button>
                      </div>
                    </div>
                  </>
                ) : (
                  <div className="space-y-4">
                    <div className="p-4 bg-red-50 border border-red-200 rounded-lg mb-6">
                      <h2 className="text-xl font-bold mb-2 text-red-800">Combat Encounter: {combatMonster?.name}</h2>
                      <p className="mb-4">{combatMonster?.description}</p>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                        <div className="bg-white p-4 rounded-lg shadow">
                          <h3 className="text-xl font-bold mb-3 text-gray-900">Monster Stats</h3>
                          <div className="space-y-2 text-sm text-gray-900">
                            <p className="text-base"><span className="font-bold text-red-700">HP:</span> {combatMonster?.hitPoints}/{combatMonster?.maxHitPoints}</p>
                            <p className="text-base"><span className="font-bold text-blue-700">AC:</span> {combatMonster?.armorClass}</p>
                            <p className="text-base"><span className="font-bold text-gray-800">Type:</span> {combatMonster?.type}</p>
                            <div className="grid grid-cols-3 gap-2 mt-3 bg-amber-50 p-2 rounded-md border border-amber-200">
                              <div className="text-center">
                                <p className="font-bold text-gray-900">STR</p>
                                <p className="text-gray-900 font-medium">{combatMonster?.stats.strength}</p>
                              </div>
                              <div className="text-center">
                                <p className="font-bold text-gray-900">DEX</p>
                                <p className="text-gray-900 font-medium">{combatMonster?.stats.dexterity}</p>
                              </div>
                              <div className="text-center">
                                <p className="font-bold text-gray-900">CON</p>
                                <p className="text-gray-900 font-medium">{combatMonster?.stats.constitution}</p>
                              </div>
                              <div className="text-center">
                                <p className="font-bold text-gray-900">INT</p>
                                <p className="text-gray-900 font-medium">{combatMonster?.stats.intelligence}</p>
                              </div>
                              <div className="text-center">
                                <p className="font-bold text-gray-900">WIS</p>
                                <p className="text-gray-900 font-medium">{combatMonster?.stats.wisdom}</p>
                              </div>
                              <div className="text-center">
                                <p className="font-bold text-gray-900">CHA</p>
                                <p className="text-gray-900 font-medium">{combatMonster?.stats.charisma}</p>
                              </div>
                            </div>
                          </div>
                        </div>

                        <div className="bg-white p-4 rounded-lg shadow">
                          <h3 className="text-xl font-bold mb-3 text-gray-900">Initiative Order</h3>
                          <ul className="space-y-2">
                            <li className="flex justify-between items-center p-2 bg-green-100 rounded border border-green-300">
                              <span className="font-bold text-gray-900">Player Character</span>
                              <span className="font-bold text-gray-900 bg-white px-3 py-1 rounded-full border border-green-400">18</span>
                            </li>
                            <li className="flex justify-between items-center p-2 bg-red-50 rounded border border-red-200">
                              <span className="font-bold text-gray-900">{combatMonster?.name}</span>
                              <span className="font-bold text-gray-900 bg-white px-3 py-1 rounded-full border border-red-300">{combatMonster?.initiative + 10}</span>
                            </li>
                          </ul>
                        </div>
                      </div>

                      <div className="bg-white p-4 rounded-lg shadow mb-4">
                        <h3 className="text-xl font-bold mb-3 text-gray-900">Monster Attacks</h3>
                        <ul className="space-y-3">
                          {combatMonster?.attacks.map((attack, index) => (
                            <li key={index} className="border border-amber-300 pb-2 rounded-md overflow-hidden">
                              <div className="bg-amber-100 px-3 py-2 border-b border-amber-300">
                                <p className="font-bold text-lg text-gray-900">{attack.name}</p>
                              </div>
                              <div className="flex justify-between items-start p-3 bg-white">
                                <div>
                                  <p className="text-base text-gray-900 font-medium">
                                    <span className="text-red-700 font-bold">+{attack.toHit} to hit</span>, 
                                    <span className="ml-1 text-gray-900 font-medium">{attack.damage} {attack.damageType} damage</span>
                                  </p>
                                  {attack.description && (
                                    <p className="text-sm font-medium text-gray-700 mt-1">{attack.description}</p>
                                  )}
                                </div>
                                <Button 
                                  size="sm" 
                                  variant="outline"
                                  className="text-sm font-medium border-red-400 text-red-700 hover:bg-red-50 hover:text-red-800"
                                  onClick={() => alert(`Simulated ${attack.name} attack roll!`)}
                                >
                                  Roll Attack
                                </Button>
                              </div>
                            </li>
                          ))}
                        </ul>
                      </div>

                      <div className="bg-white p-4 rounded-lg shadow">
                        <h3 className="text-xl font-bold mb-3 text-gray-900">Player Actions</h3>
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                          <Button className="bg-red-600 hover:bg-red-700 text-base font-bold">
                            <Sword className="mr-2 h-5 w-5" /> Attack with Weapon
                          </Button>
                          <Button className="bg-blue-600 hover:bg-blue-700 text-base font-bold">
                            <Sparkles className="mr-2 h-5 w-5" /> Cast Spell
                          </Button>
                          <Button className="bg-green-600 hover:bg-green-700 text-base font-bold">
                            <PocketKnife className="mr-2 h-5 w-5" /> Use Item
                          </Button>
                          <Button className="bg-amber-600 hover:bg-amber-700 text-base font-bold">
                            <Shield className="mr-2 h-5 w-5" /> Dodge
                          </Button>
                        </div>
                      </div>

                      <div className="mt-6 flex justify-between">
                        <Button variant="outline" onClick={() => setShowCombat(false)}>
                          End Combat
                        </Button>
                        <Button className="bg-purple-600 hover:bg-purple-700">
                          End Turn
                        </Button>
                      </div>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="npc" className="py-6">
            <Card>
              <CardHeader>
                <CardTitle>NPC Interactions</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="mb-6">
                  Interact with NPCs using dialogue options, skill checks, and character-specific responses.
                </p>

                <div className="space-y-4">
                  <div className="p-6 bg-amber-50 border border-amber-200 rounded-lg">
                    <h3 className="text-xl font-bold mb-4">NPC Interaction Demo</h3>
                    <p className="mb-4">
                      NPC interactions now feature:
                    </p>
                    <ul className="list-disc pl-6 space-y-2 mb-6">
                      <li>Character-specific dialogue options</li>
                      <li>Skill checks for persuasion, intimidation, insight, etc.</li>
                      <li>Reputation tracking with different NPCs</li>
                      <li>Quest opportunities from dialogue choices</li>
                    </ul>

                    <Button 
                      onClick={() => setShowNpcDialog(true)}
                      className="bg-green-600 hover:bg-green-700"
                    >
                      Talk to Bartender
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>

      {/* NPC Dialog */}
      {showNpcDialog && (
        <NPCInteractionHandler
          campaignId={1} // Demo campaign ID
          sessionId={1} // Demo session ID
          npc={demoNpcs.bartender}
          isOpen={showNpcDialog}
          onClose={() => setShowNpcDialog(false)}
          onInteractionComplete={(result) => {
            setShowNpcDialog(false);
            // Show the tavern scene after talking
            setActiveTab('story');
            setCurrentScene(demoScenes.tavern);
          }}
        />
      )}
    </div>
  );
}

// Demo data for the interactions
const demoScenes = {
  forestPath: {
    narrative: "You find yourself on a winding forest path. Towering oak trees filter the sunlight into dappled patterns on the ground. A gentle breeze carries the scent of pine and wildflowers. In the distance, you can hear the faint sound of flowing water. Suddenly, you notice a three-headed hound emerging from the underbrush, its eyes glowing with an otherworldly light.",
    location: "Whispering Woods",
    choices: [
      {
        action: "Follow the path deeper into the forest",
        description: "Try to avoid the creature and continue on your way",
        requiresDiceRoll: false
      },
      {
        action: "Head toward the sound of water",
        description: "You can hear a stream or river nearby",
        requiresDiceRoll: false
      },
      {
        action: "Search for tracks or signs of other travelers",
        description: "You might find evidence of others who passed this way",
        requiresDiceRoll: true,
        diceType: "d20",
        rollDC: 12,
        abilityType: "wisdom",
        rollModifier: 2
      },
      {
        action: "Confront the Three-Headed Hound",
        description: "Draw your weapons and engage the monstrous creature in combat",
        requiresDiceRoll: false,
        nextScene: 'combat'
      }
    ],
    nextScene: 'tavern'
  },
  tavern: {
    narrative: "You push open the weathered door of 'The Prancing Pony' tavern. The warmth inside is a welcome contrast to the cool forest air. The tavern is bustling with activity - travelers sharing stories, locals enjoying ale, and a bard playing a lively tune in the corner. Behind the bar, a stout dwarf with a bushy beard polishes mugs with a cloth.",
    location: "The Prancing Pony Tavern",
    choices: [
      {
        action: "Approach the bar and order a drink",
        description: "The dwarf bartender notices your approach",
        requiresDiceRoll: false,
        nextScene: 'npc'
      },
      {
        action: "Listen to the bard's tale",
        description: "The bard is singing about local legends",
        requiresDiceRoll: false
      },
      {
        action: "Look around for interesting patrons",
        description: "Several adventurers and locals populate the tavern",
        requiresDiceRoll: false
      },
      {
        action: "Try to eavesdrop on nearby conversations",
        description: "You might overhear something interesting",
        requiresDiceRoll: true,
        diceType: "d20",
        rollDC: 14,
        abilityType: "dexterity",
        rollModifier: 1
      }
    ]
  },
  combatEncounter: {
    narrative: "As you make your way through a clearing in the forest, you suddenly hear rustling from the underbrush. Three bandits leap out with weapons drawn! 'Hand over your valuables,' growls the leader, a scarred human with a shortsword. The other two flank him, one with a bow and the other wielding a club.",
    location: "Forest Clearing",
    choices: [
      {
        action: "Draw your weapon and prepare to fight",
        description: "Initiative will be rolled for combat",
        requiresDiceRoll: false,
        nextScene: 'combat'
      },
      {
        action: "Try to reason with the bandits",
        description: "Perhaps they can be persuaded to leave peacefully",
        requiresDiceRoll: true,
        diceType: "d20",
        rollDC: 15,
        abilityType: "charisma",
        rollModifier: 2
      },
      {
        action: "Attempt to intimidate them",
        description: "Show them you're not worth the trouble",
        requiresDiceRoll: true,
        diceType: "d20",
        rollDC: 14,
        abilityType: "strength",
        rollModifier: 3
      },
      {
        action: "Look for an escape route",
        description: "There might be a way to flee without fighting",
        requiresDiceRoll: true,
        diceType: "d20",
        rollDC: 12,
        abilityType: "dexterity",
        rollModifier: 2
      }
    ]
  }
};

// Demo monsters for combat encounters
const demoMonsters = {
  threeHeadedHound: {
    id: 1,
    name: "Cerberus, Three-Headed Hound",
    type: "fiend",
    hitPoints: 90,
    maxHitPoints: 90,
    armorClass: 15,
    initiative: 2,
    stats: {
      strength: 18,
      dexterity: 14, 
      constitution: 16,
      intelligence: 8,
      wisdom: 12,
      charisma: 10
    },
    attacks: [
      {
        name: "Bite",
        toHit: 6,
        damage: "2d6+4",
        damageType: "piercing"
      },
      {
        name: "Fire Breath",
        toHit: 4,
        damage: "3d8",
        damageType: "fire",
        description: "The center head breathes a cone of fire."
      }
    ],
    description: "A massive three-headed dog with glowing red eyes and obsidian fur. Each head snarls and drools, revealing razor-sharp teeth."
  },
  banditLeader: {
    id: 2,
    name: "Bandit Captain",
    type: "humanoid",
    hitPoints: 65,
    maxHitPoints: 65,
    armorClass: 15,
    initiative: 3,
    stats: {
      strength: 15,
      dexterity: 16,
      constitution: 14,
      intelligence: 14,
      wisdom: 11,
      charisma: 14
    },
    attacks: [
      {
        name: "Scimitar",
        toHit: 5,
        damage: "1d6+3",
        damageType: "slashing"
      },
      {
        name: "Dagger",
        toHit: 5,
        damage: "1d4+3",
        damageType: "piercing"
      }
    ],
    description: "A scarred human with a menacing grin, wearing leather armor adorned with trophies from previous victims."
  }
};

const demoNpcs = {
  bartender: {
    id: 1,
    name: "Durgan Stonebrew",
    race: "Dwarf",
    occupation: "Bartender",
    personality: "Gruff but friendly, full of local stories and rumors",
    description: "A stout dwarf with braided beard adorned with golden beads. His forearms are thick and strong from years of brewing and serving.",
    location: "The Prancing Pony Tavern",
    portraitUrl: null
  },
  ranger: {
    id: 2,
    name: "Elyndra Moonshadow",
    race: "Wood Elf",
    occupation: "Forest Ranger",
    personality: "Watchful, soft-spoken, deeply knowledgeable about the forest",
    description: "A tall, lithe elf with forest-green clothing and silver-streaked brown hair. Her eyes seem to change color with the light.",
    location: "Whispering Woods",
    portraitUrl: null
  }
};