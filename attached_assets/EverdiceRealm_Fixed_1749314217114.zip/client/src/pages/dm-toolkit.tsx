import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/use-auth";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Separator } from "@/components/ui/separator";
import { Checkbox } from "@/components/ui/checkbox";
import { 
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader, 
  DialogTitle,
  DialogTrigger 
} from "@/components/ui/dialog";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { 
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger
} from "@/components/ui/accordion";
import { 
  AlertCircle, 
  BookOpen, 
  Heart, 
  Loader2, 
  Plus, 
  Shield, 
  Target, 
  Users,
  MapPin,
  Castle,
  Trees,
  Building,
  Landmark,
  Mountain,
  Droplets,
  Compass,
  Info,
  Scroll,
  Sparkles,
  Swords,
  Star,
  Circle,
  Send,
  Globe,
  Mail,
  StickyNote,
  Brain,
  Dice6
} from "lucide-react";

// Import our new tabs
import InvitationsTab from "@/components/dm-toolkit/InvitationsTab";
import NotesTabSimple from "@/components/dm-toolkit/NotesTabSimple";
import InitiativeTracker from "@/components/dm-toolkit/InitiativeTracker";
import QuickNPCGenerator from "@/components/dm-toolkit/QuickNPCGenerator";
import EncounterGenerator from "@/components/dm-toolkit/EncounterGenerator";
import LocationsTabComponent from "@/components/dm-toolkit/LocationsTab";
import QuestsTabComponent from "@/components/dm-toolkit/QuestsTab";
import ItemsTabComponent from "@/components/dm-toolkit/ItemsTab";
import MonstersTabComponent from "@/components/dm-toolkit/MonstersTab";
import AIAssistantTab from "@/components/dm-toolkit/AIAssistantTab";
import DiceIntegrationTab from "@/components/dm-toolkit/DiceIntegrationTab";
import CampaignMapTab from "@/components/dm-toolkit/CampaignMapTab";

export default function DMToolkit() {
  const { user, isLoading: authLoading } = useAuth();
  const [activeTab, setActiveTab] = useState("companions");

  if (authLoading) {
    return (
      <div className="container flex items-center justify-center min-h-screen">
        <div className="text-center">
          <Loader2 className="h-10 w-10 animate-spin mx-auto text-primary mb-4" />
          <h2 className="text-2xl font-fantasy font-semibold">Loading DM Toolkit</h2>
          <p className="text-muted-foreground">Please wait while we prepare your tools...</p>
        </div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="container flex items-center justify-center min-h-screen">
        <div className="text-center">
          <AlertCircle className="h-10 w-10 mx-auto text-destructive mb-4" />
          <h2 className="text-2xl font-bold">Authentication Required</h2>
          <p className="text-muted-foreground mb-4">You need to be logged in to access the DM Toolkit.</p>
          <Button asChild>
            <a href="/auth">Login or Register</a>
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="container px-4 py-6 md:py-8">
      <div className="space-y-2 mb-6 md:mb-8">
        <h1 className="text-2xl md:text-3xl font-fantasy font-bold">Dungeon Master Toolkit</h1>
        <p className="text-sm md:text-base text-muted-foreground">Create and manage your campaigns with these powerful tools</p>
      </div>

      <Tabs defaultValue="companions" value={activeTab} onValueChange={setActiveTab} className="space-y-4">
        <TabsList className="grid grid-cols-3 md:grid-cols-8 lg:grid-cols-15 w-full overflow-x-auto">
          <TabsTrigger value="companions" className="text-xs md:text-sm font-medium px-2 py-1.5 md:px-3 md:py-2">
            Companions
          </TabsTrigger>
          <TabsTrigger value="locations" className="text-xs md:text-sm font-medium px-2 py-1.5 md:px-3 md:py-2">
            Locations
          </TabsTrigger>
          <TabsTrigger value="campaign-map" className="text-xs md:text-sm font-medium px-2 py-1.5 md:px-3 md:py-2">
            <MapPin className="h-3.5 w-3.5 md:h-4 md:w-4 mr-1 hidden sm:inline-block" />
            Campaign Map
          </TabsTrigger>
          <TabsTrigger value="quests" className="text-xs md:text-sm font-medium px-2 py-1.5 md:px-3 md:py-2">
            Quests
          </TabsTrigger>
          <TabsTrigger value="items" className="text-xs md:text-sm font-medium px-2 py-1.5 md:px-3 md:py-2">
            Items
          </TabsTrigger>
          <TabsTrigger value="monsters" className="text-xs md:text-sm font-medium px-2 py-1.5 md:px-3 md:py-2">
            Monsters
          </TabsTrigger>
          <TabsTrigger value="initiative" className="text-xs md:text-sm font-medium px-2 py-1.5 md:px-3 md:py-2">
            <Target className="h-3.5 w-3.5 md:h-4 md:w-4 mr-1 hidden sm:inline-block" />
            Initiative
          </TabsTrigger>
          <TabsTrigger value="encounters" className="text-xs md:text-sm font-medium px-2 py-1.5 md:px-3 md:py-2">
            <Swords className="h-3.5 w-3.5 md:h-4 md:w-4 mr-1 hidden sm:inline-block" />
            Encounters
          </TabsTrigger>
          <TabsTrigger value="npcs" className="text-xs md:text-sm font-medium px-2 py-1.5 md:px-3 md:py-2">
            <Users className="h-3.5 w-3.5 md:h-4 md:w-4 mr-1 hidden sm:inline-block" />
            Quick NPCs
          </TabsTrigger>
          <TabsTrigger value="invitations" className="text-xs md:text-sm font-medium px-2 py-1.5 md:px-3 md:py-2">
            <Mail className="h-3.5 w-3.5 md:h-4 md:w-4 mr-1 hidden sm:inline-block" />
            Invitations
          </TabsTrigger>
          <TabsTrigger value="notes" className="text-xs md:text-sm font-medium px-2 py-1.5 md:px-3 md:py-2">
            <StickyNote className="h-3.5 w-3.5 md:h-4 md:w-4 mr-1 hidden sm:inline-block" />
            Notes
          </TabsTrigger>
          <TabsTrigger value="generators" className="text-xs md:text-sm font-medium px-2 py-1.5 md:px-3 md:py-2">
            Generators
          </TabsTrigger>
          <TabsTrigger value="deploy" className="text-xs md:text-sm font-medium px-2 py-1.5 md:px-3 md:py-2">
            Deploy
          </TabsTrigger>
          <TabsTrigger value="ai-assistant" className="text-xs md:text-sm font-medium px-2 py-1.5 md:px-3 md:py-2">
            <Brain className="h-3.5 w-3.5 md:h-4 md:w-4 mr-1 hidden sm:inline-block" />
            AI Assistant
          </TabsTrigger>
          <TabsTrigger value="dice-integration" className="text-xs md:text-sm font-medium px-2 py-1.5 md:px-3 md:py-2">
            <Dice6 className="h-3.5 w-3.5 md:h-4 md:w-4 mr-1 hidden sm:inline-block" />
            Dice
          </TabsTrigger>
        </TabsList>

        <TabsContent value="companions" className="space-y-4">
          <CompanionsTab />
        </TabsContent>

        <TabsContent value="locations" className="space-y-4">
          <LocationsTabComponent />
        </TabsContent>

        <TabsContent value="quests" className="space-y-4">
          <QuestsTabComponent />
        </TabsContent>

        <TabsContent value="items" className="space-y-4">
          <ItemsTabComponent />
        </TabsContent>

        <TabsContent value="monsters" className="space-y-4">
          <MonstersTabComponent />
        </TabsContent>

        <TabsContent value="initiative" className="space-y-4">
          <InitiativeTracker />
        </TabsContent>

        <TabsContent value="encounters" className="space-y-4">
          <EncounterGenerator />
        </TabsContent>

        <TabsContent value="npcs" className="space-y-4">
          <QuickNPCGenerator />
        </TabsContent>

        <TabsContent value="invitations" className="space-y-4">
          <InvitationsTab />
        </TabsContent>

        <TabsContent value="notes" className="space-y-4">
          <NotesTabSimple />
        </TabsContent>

        <TabsContent value="generators" className="space-y-4">
          <div className="text-center py-12">
            <BookOpen className="h-12 w-12 mx-auto mb-2 text-muted-foreground" />
            <p className="text-muted-foreground">Generate content tools will be available soon</p>
          </div>
        </TabsContent>

        <TabsContent value="deploy" className="space-y-6">
          <div className="flex justify-between items-center">
            <div>
              <h2 className="text-2xl font-fantasy font-semibold flex items-center">
                <Send className="h-5 w-5 mr-2 text-primary" />
                Deploy Created Assets to Campaign
              </h2>
              <p className="text-muted-foreground">Turn your creations into a deployable campaign for players</p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Globe className="h-5 w-5 mr-2 text-primary" />
                  Create Campaign from Assets
                </CardTitle>
                <CardDescription>
                  Generate a new campaign using the companions, locations, and quests you've created
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="campaign-name">Campaign Name</Label>
                  <Input id="campaign-name" placeholder="Enter a name for your campaign" />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="campaign-description">Description</Label>
                  <Textarea id="campaign-description" placeholder="Describe your campaign to potential players" />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="difficulty">Difficulty</Label>
                    <Select>
                      <SelectTrigger>
                        <SelectValue placeholder="Select difficulty" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="beginner">Beginner</SelectItem>
                        <SelectItem value="intermediate">Intermediate</SelectItem>
                        <SelectItem value="advanced">Advanced</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="style">Style</Label>
                    <Select>
                      <SelectTrigger>
                        <SelectValue placeholder="Select style" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="heroic">Heroic</SelectItem>
                        <SelectItem value="gritty">Gritty</SelectItem>
                        <SelectItem value="mystery">Mystery</SelectItem>
                        <SelectItem value="horror">Horror</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </CardContent>
              <CardFooter>
                <Button className="w-full">
                  Create Deployable Campaign
                </Button>
              </CardFooter>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Your Created Assets</CardTitle>
                <CardDescription>Select assets to include in your campaign</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <Label>Companions</Label>
                    <Badge variant="outline">3 Selected</Badge>
                  </div>
                  <div className="border rounded-md p-2 space-y-2">
                    <div className="flex items-center space-x-2">
                      <Checkbox id="companion-1" />
                      <Label htmlFor="companion-1" className="text-sm">Grimshaw the Guardian</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Checkbox id="companion-2" />
                      <Label htmlFor="companion-2" className="text-sm">Seraphina the Sage</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Checkbox id="companion-3" checked />
                      <Label htmlFor="companion-3" className="text-sm">Thorne Ironfist</Label>
                    </div>
                  </div>
                </div>

                <div className="space-y-2">
                  <div className="flex justify-between">
                    <Label>Locations</Label>
                    <Badge variant="outline">2 Selected</Badge>
                  </div>
                  <div className="border rounded-md p-2 space-y-2">
                    <div className="flex items-center space-x-2">
                      <Checkbox id="location-1" checked />
                      <Label htmlFor="location-1" className="text-sm">Whispering Forest</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Checkbox id="location-2" checked />
                      <Label htmlFor="location-2" className="text-sm">Frostfall Mountains</Label>
                    </div>
                  </div>
                </div>

                <div className="space-y-2">
                  <div className="flex justify-between">
                    <Label>Quests</Label>
                    <Badge variant="outline">1 Selected</Badge>
                  </div>
                  <div className="border rounded-md p-2 space-y-2">
                    <div className="flex items-center space-x-2">
                      <Checkbox id="quest-1" checked />
                      <Label htmlFor="quest-1" className="text-sm">The Lost Artifact</Label>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          <Card className="mt-4 border-primary/20 bg-secondary/10">
            <CardHeader>
              <CardTitle className="flex items-center text-primary">
                <Info className="mr-2 h-5 w-5" />
                About Campaign Deployment
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground mb-4">
                Deployment allows you to create a fully playable campaign from your assets that can be:
              </p>
              <ul className="text-sm text-muted-foreground space-y-2 list-disc pl-5">
                <li>Shared with other players using a join code</li>
                <li>Run by you as the DM for a live group</li>
                <li>Set as an automated campaign that players can join and play asynchronously</li>
                <li>Made public in the campaign directory for anyone to discover</li>
                <li>Customized with your own rules, difficulty levels, and narrative styles</li>
              </ul>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="campaign-map" className="space-y-4">
          <CampaignMapTab />
        </TabsContent>

        <TabsContent value="ai-assistant" className="space-y-4">
          <AIAssistantTab />
        </TabsContent>

        <TabsContent value="dice-integration" className="space-y-4">
          <DiceIntegrationTab />
        </TabsContent>

        <TabsContent value="invitations" className="space-y-4">
          <InvitationsTab />
        </TabsContent>
      </Tabs>
    </div>
  );
}

import { CompanionDetailsDialog } from "@/components/companions/CompanionDetailsDialog";

function CompanionsTab() {
  const [activeViewTab, setActiveViewTab] = useState("stock-companions"); // "my-companions" or "stock-companions"
  const [selectedCampaignId, setSelectedCampaignId] = useState("");
  const [selectedRole, setSelectedRole] = useState("companion");
  const [selectedNpcId, setSelectedNpcId] = useState<number | null>(null);
  const [selectedCompanion, setSelectedCompanion] = useState<any>(null);
  const [showDetailsDialog, setShowDetailsDialog] = useState(false);
  const { toast } = useToast();
  const isMobile = window.innerWidth < 768;

  // Fetch user's companions
  const { data: companions = [], isLoading: isLoadingCompanions } = useQuery<any[]>({
    queryKey: ["/api/npcs/companions"],
    refetchOnWindowFocus: false,
  });

  // Fetch stock companions
  const { data: stockCompanions = [], isLoading: isLoadingStockCompanions } = useQuery<any[]>({
    queryKey: ["/api/npcs/stock-companions"],
    refetchOnWindowFocus: false,
  });

  // Fetch user's campaigns
  const { data: campaigns = [], isLoading: isLoadingCampaigns } = useQuery<any[]>({
    queryKey: ["/api/campaigns"],
    refetchOnWindowFocus: false,
  });

  // Add to campaign mutation
  const addToCampaignMutation = useMutation({
    mutationFn: async (data: { campaignId: string; npcId: number; role: string }) => {
      return await apiRequest("POST", `/api/campaigns/${data.campaignId}/npcs`, {
        npcId: data.npcId,
        role: data.role,
      });
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Companion added to campaign successfully",
      });

      // Reset selections
      setSelectedCampaignId("");
      setSelectedNpcId(null);
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleAddToCampaign = () => {
    if (!selectedCampaignId || !selectedNpcId) {
      toast({
        title: "Error",
        description: "Please select both a campaign and a companion",
        variant: "destructive",
      });
      return;
    }

    addToCampaignMutation.mutate({
      campaignId: selectedCampaignId,
      npcId: selectedNpcId,
      role: selectedRole,
    });
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-fantasy font-semibold">Companions & NPCs</h2>
          <p className="text-muted-foreground">Create and manage companions for your adventures</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" onClick={() => setActiveViewTab("my-companions")}>
            My Companions
          </Button>
          <Button variant="outline" onClick={() => setActiveViewTab("stock-companions")}>
            Ready-Made Companions
          </Button>
        </div>
      </div>

      {activeViewTab === "my-companions" && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 md:gap-4">
            {isLoadingCompanions ? (
              <div className="col-span-full flex items-center justify-center py-8 md:py-12">
                <Loader2 className="h-6 w-6 md:h-8 md:w-8 animate-spin text-muted-foreground" />
              </div>
            ) : companions.length === 0 ? (
              <div className="col-span-full text-center py-8 md:py-12">
                <Users className="h-10 w-10 md:h-12 md:w-12 mx-auto mb-2 text-muted-foreground" />
                <p className="text-sm md:text-base text-muted-foreground">You haven't created any companions yet</p>
                <Button className="mt-4 text-xs md:text-sm" size={isMobile ? "sm" : "default"}>
                  <Plus className="h-3 w-3 md:h-4 md:w-4 mr-1 md:mr-2" /> Create Companion
                </Button>
              </div>
            ) : (
              companions.map((companion: any) => (
                <Card key={companion.id} className="overflow-hidden">
                  <CardHeader className="pb-2 px-3 py-3 md:px-6 md:py-4">
                    <div className="flex justify-between items-start">
                      <CardTitle className="font-fantasy text-base md:text-lg">{companion.name}</CardTitle>
                      <Badge className="text-xs ml-1">{companion.race}</Badge>
                    </div>
                    <CardDescription className="text-xs md:text-sm">{companion.class}</CardDescription>
                  </CardHeader>
                  <CardContent className="pb-0 px-3 md:px-6">
                    <p className="text-xs md:text-sm mb-2 md:mb-3 line-clamp-3">
                      {companion.backstory?.substring(0, isMobile ? 80 : 120)}...
                    </p>
                    <div className="flex justify-between text-xs md:text-sm text-muted-foreground">
                      <span>Level {companion.level}</span>
                      <span>{companion.alignment}</span>
                    </div>
                  </CardContent>
                  <CardFooter className="pt-2 px-3 py-3 md:px-6 md:py-4">
                    <div className="flex flex-col xs:flex-row w-full gap-2">
                      <Button 
                        variant="outline" 
                        size="sm" 
                        className="text-xs w-full xs:w-auto"
                        onClick={() => {
                          setSelectedCompanion(companion);
                          setShowDetailsDialog(true);
                        }}
                      >
                        View Details
                      </Button>
                      <Dialog>
                        <DialogTrigger asChild>
                          <Button 
                            size="sm"
                            className="text-xs w-full xs:w-auto"
                            onClick={() => setSelectedNpcId(companion.id)}
                          >
                            Add to Campaign
                          </Button>
                        </DialogTrigger>
                        <DialogContent className="max-w-[90vw] w-[400px]">
                          <DialogHeader>
                            <DialogTitle>Add to Campaign</DialogTitle>
                            <DialogDescription className="text-xs md:text-sm">
                              Select a campaign to add {companion.name} to as a companion
                            </DialogDescription>
                          </DialogHeader>
                          <div className="space-y-4 py-4">
                            <div className="space-y-2">
                              <Label htmlFor="campaign" className="text-xs md:text-sm">Campaign</Label>
                              <Select
                                value={selectedCampaignId}
                                onValueChange={setSelectedCampaignId}
                              >
                                <SelectTrigger className="text-xs md:text-sm">
                                  <SelectValue placeholder="Select campaign" />
                                </SelectTrigger>
                                <SelectContent>
                                  {campaigns.map((campaign: any) => (
                                    <SelectItem key={campaign.id} value={campaign.id.toString()} className="text-xs md:text-sm">
                                      {campaign.name || campaign.title}
                                    </SelectItem>
                                  ))}
                                </SelectContent>
                              </Select>
                            </div>

                            <div className="space-y-2">
                              <Label htmlFor="role" className="text-xs md:text-sm">Role</Label>
                              <Select
                                value={selectedRole}
                                onValueChange={setSelectedRole}
                              >
                                <SelectTrigger className="text-xs md:text-sm">
                                  <SelectValue placeholder="Select role" />
                                </SelectTrigger>
                                <SelectContent>
                                  <SelectItem value="companion" className="text-xs md:text-sm">Companion</SelectItem>
                                  <SelectItem value="ally" className="text-xs md:text-sm">Ally</SelectItem>
                                  <SelectItem value="quest-giver" className="text-xs md:text-sm">Quest Giver</SelectItem>
                                  <SelectItem value="merchant" className="text-xs md:text-sm">Merchant</SelectItem>
                                  <SelectItem value="antagonist" className="text-xs md:text-sm">Antagonist</SelectItem>
                                </SelectContent>
                              </Select>
                            </div>
                          </div>
                          <DialogFooter>
                            <Button
                              onClick={handleAddToCampaign}
                              disabled={addToCampaignMutation.isPending}
                              className="text-xs md:text-sm"
                              size={isMobile ? "sm" : "default"}
                            >
                              {addToCampaignMutation.isPending && (
                                <Loader2 className="h-3 w-3 md:h-4 md:w-4 mr-1 md:mr-2 animate-spin" />
                              )}
                              Add to Campaign
                            </Button>
                          </DialogFooter>
                        </DialogContent>
                      </Dialog>
                    </div>
                  </CardFooter>
                </Card>
              ))
            )}
          </div>

          <div className="text-center">
            <Button>
              <Plus className="h-4 w-4 mr-2" /> Create New Companion
            </Button>
          </div>
        </div>
      )}

      {activeViewTab === "stock-companions" && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {isLoadingStockCompanions ? (
              <div className="col-span-full flex items-center justify-center py-12">
                <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
              </div>
            ) : stockCompanions.length === 0 ? (
              <div className="col-span-full text-center py-12">
                <Users className="h-12 w-12 mx-auto mb-2 text-muted-foreground" />
                <p className="text-muted-foreground">No stock companions available</p>
              </div>
            ) : (
              stockCompanions.map((companion: any) => (
                <Card key={companion.id} className="overflow-hidden">
                  <CardHeader className="pb-2">
                    <div className="flex justify-between">
                      <CardTitle className="font-fantasy">{companion.name}</CardTitle>
                      <Badge>{companion.race}</Badge>
                    </div>
                    <CardDescription>{companion.class}</CardDescription>
                  </CardHeader>
                  <CardContent className="pb-0">
                    <p className="text-sm mb-3">{companion.backstory?.substring(0, 120)}...</p>
                    <div className="flex justify-between text-sm text-muted-foreground">
                      <span>Level {companion.level}</span>
                      <span>{companion.alignment}</span>
                    </div>
                  </CardContent>
                  <CardFooter className="pt-2">
                    <div className="flex justify-between w-full">
                      <Button 
                        variant="outline" 
                        size="sm"
                        onClick={() => {
                          setSelectedCompanion(companion);
                          setShowDetailsDialog(true);
                        }}
                      >
                        View Details
                      </Button>
                      <Dialog>
                        <DialogTrigger asChild>
                          <Button 
                            size="sm"
                            onClick={() => setSelectedNpcId(companion.id)}
                          >
                            Add to Campaign
                          </Button>
                        </DialogTrigger>
                        <DialogContent>
                          <DialogHeader>
                            <DialogTitle>Add to Campaign</DialogTitle>
                            <DialogDescription>
                              Select a campaign to add {companion.name} to as a companion
                            </DialogDescription>
                          </DialogHeader>
                          <div className="space-y-4 py-4">
                            <div className="space-y-2">
                              <Label htmlFor="campaign">Campaign</Label>
                              <Select
                                value={selectedCampaignId}
                                onValueChange={setSelectedCampaignId}
                              >
                                <SelectTrigger>
                                  <SelectValue placeholder="Select campaign" />
                                </SelectTrigger>
                                <SelectContent>
                                  {campaigns.map((campaign: any) => (
                                    <SelectItem key={campaign.id} value={campaign.id.toString()}>
                                      {campaign.name}
                                    </SelectItem>
                                  ))}
                                </SelectContent>
                              </Select>
                            </div>

                            <div className="space-y-2">
                              <Label htmlFor="role">Role</Label>
                              <Select
                                value={selectedRole}
                                onValueChange={setSelectedRole}
                              >
                                <SelectTrigger>
                                  <SelectValue placeholder="Select role" />
                                </SelectTrigger>
                                <SelectContent>
                                  <SelectItem value="companion">Companion</SelectItem>
                                  <SelectItem value="ally">Ally</SelectItem>
                                  <SelectItem value="quest-giver">Quest Giver</SelectItem>
                                  <SelectItem value="merchant">Merchant</SelectItem>
                                  <SelectItem value="antagonist">Antagonist</SelectItem>
                                </SelectContent>
                              </Select>
                            </div>
                          </div>
                          <DialogFooter>
                            <Button
                              onClick={handleAddToCampaign}
                              disabled={addToCampaignMutation.isPending}
                            >
                              {addToCampaignMutation.isPending && (
                                <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                              )}
                              Add to Campaign
                            </Button>
                          </DialogFooter>
                        </DialogContent>
                      </Dialog>
                    </div>
                  </CardFooter>
                </Card>
              ))
            )}
          </div>
        </div>
      )}

      {/* Details Dialog */}
      {selectedCompanion && (
        <CompanionDetailsDialog
          companion={selectedCompanion}
          isOpen={showDetailsDialog}
          onOpenChange={setShowDetailsDialog}
        />
      )}
    </div>
  );
}